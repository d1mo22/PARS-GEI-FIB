#include "LSH.h"
#include <algorithm>

// LSH
std::vector<std::pair<int, int>>
LSH(const std::vector<std::vector<int>> &signatures, int bands)
{
  int n = signatures.size();
  int t = signatures[0].size();
  int r = t / bands;      

  std::vector<std::pair<int,int>> candidates = std::vector<std::pair<int, int>>();
  std::unordered_map<int, std::unordered_map<int, bool>> visited;

  //Creación de buckets para cada band
  for(int b = 0; b < bands; ++b)
  {
    std::unordered_map<std::string, std::vector<int>> bucket;

    for(int doc = 0; doc < n; ++doc)
    {
      const std::vector<int>& sig = signatures[doc];
      
      std::string key;
      for(int i = 0; i < r; ++i)
        key += std::to_string(sig[b * r + i]) + ',';

      bucket[key].push_back(doc);
    }

    //Para cada bucket, genrar candidatos
    for(const auto &bu : bucket)
    {
      const auto &id = bu.second;

      if(id.size() < 2)
        continue;

      for(size_t i = 0; i < id.size(); ++i)
      {
        for(size_t j = i + 1; j < id.size(); ++j)
        {
          int x = std::min(id[i], id[j]);
          int y = std::max(id[i], id[j]);

          if(!visited[x][y])
          {
            visited[x][y] = true;
            candidates.push_back(std::make_pair(x, y));
          }
        }
      }
    }

  }

  return candidates;
}