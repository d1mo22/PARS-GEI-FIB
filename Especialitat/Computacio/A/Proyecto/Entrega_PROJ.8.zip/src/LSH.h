#include <string>
#include <unordered_map>
#include <vector>

// LSH
std::vector<std::pair<int, int>>
LSH(const std::vector<std::vector<int>> &signatures, int bands);