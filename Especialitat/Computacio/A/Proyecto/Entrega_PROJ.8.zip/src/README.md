# A-Project

## Instrucciones para compilar el proyecto
### Usando CMake
1. Crear directorio de build:
```bash
mkdir build && cd build
```
2. Configurar el proyecto:
```bash
cmake ..
```
3. Compilar:
```bash
cmake --build .
```
o tambien se puede usar:
```bash
make
```

Los ejecutables se encontrarán en el directorio raiz.

## Instrucciones de uso
### main
**Es necesario ejecutar previamente genPerm para generar las permutaciones que usará el programa**\
**Uso:**\
**./main [book] [mode] [k] [n (o D)] [b]**\
**book:** f - frankenstein, m - moby dick, q - quijote\
**mode:** 1 - permutaciones aleatorias, 2- set de D documentos virtuales\
**k:** valor de k para los k-shingles\
**n:** numero de documentos que comparar (modo 1)\
***nota:*** n <= numero de ficheros permutados de un libro.\
**D:** numero de documentos virtuales (modo 2)\
**b:** numero de bandas para el LSH

### genPerm
**Uso:**\
**./genPerm**\
*para modificar el numero de permutaciones y el texto hay que cambiar el código (linea 52, 64 y 62, respectivamente)

## Tamaño de k-shingles
*Propuesta*: probar con **k** = 5,6,7,8 y 9 o **k** = 5, 7 y 9

*Experimentación:* k= 3, 4 y 5. Con valores mayores la similitud entre documentos decrementa de manera significante

## Datos
Hemos decidido empezar usando fragmentos de textos como **Moby Dick** o **Frankenstein** y les hemos eliminado los stopwords antes de hacer ningún cálculo de similitudes. Los fragmentos *limpios* se encuentran en text-fragments y las permutaciones par el primer conjunto de experimentos están en **permutations-1**

## Repositiorios Usados
**stopwords-iso:** para obtener los *stopwords* en español.
