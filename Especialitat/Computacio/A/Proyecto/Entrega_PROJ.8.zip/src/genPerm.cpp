#include <algorithm>
#include <chrono>
#include <climits>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include <random>
#include <filesystem>

using namespace std;

string fileToString(const string &filename) {
	ifstream file(filename);
	stringstream buffer;

	if (file.is_open()) {
		buffer << file.rdbuf();
		file.close();
		return buffer.str();
	}
	return ""; // Retorna string vacío si falla la apertura
}

vector<string> splitIntoWords(const string &text) {
	vector<string> words;
	stringstream ss(text);
	string word;

	while (ss >> word) {
		words.push_back(word);
	}

	return words;
}

string generatePermutation(const std::vector<std::string>& words, std::mt19937& gen) {
	vector<std::string> permutedWords = words;
	shuffle(permutedWords.begin(), permutedWords.end(), gen);
	string result;
	for (const auto& word : permutedWords) {
		result += word + " ";  // Added space after each word
	}
	
	return result;
}

int main()
{
    string path1 = "sample-text/quijote-ch1_filtered.txt";
    const string doc1 = fileToString(path1);
	// creacion de >= 20 docs permutados de texto base en path1
	vector<string> words = splitIntoWords(doc1);
    for(size_t i = 0; i < words.size(); ++i) {
        cout << "w: " << words[i] << endl;
	}
	unsigned seed = chrono::system_clock::now().time_since_epoch().count();
	mt19937 gen(seed);

	for (int i = 0; i < 25; i++) {
		string permutedText = generatePermutation(words, gen);
        //cout << "I: " << permutedText << endl;
		string permutedFileName = "./permutations-1/quijote_" + to_string(i+1) + ".txt";
		ofstream permutedFile(permutedFileName);
		permutedFile << permutedText;
		permutedFile.close();
		cout << permutedFileName << " done" << endl;
	}
}