#include "hash_functions.h"
#include <algorithm>
#include <climits>

std::set<std::string> generateKShingles(const std::string &text, int k) {
  std::set<std::string> shingles;
  std::string processedText;

  // Remove spaces and punctuation, convert to lowercase
  for (char c : text) {
    if (isalnum(c)) {
      processedText += tolower(c);
    }
  }
  int sizeText = processedText.length();
  // Generate all possible k-length substrings
  if (sizeText >= k) {
    for (int i = 0; i <= sizeText - k; i++) {
      shingles.insert(processedText.substr(i, k));
    }
  }

  return shingles;
}
std::vector<int> generateMinhashSignature(const std::set<std::string> &shingles,
                                          int t) {
  std::vector<int> signature(t, INT_MAX);

  const int p = 2147483647; // Primo Mersenne 2^31-1

  // Generamos t funciones hash diferentes
  for (int i = 0; i < t; ++i) {
    std::hash<std::string> hasher;
    int a = 31415 + i * 17;
    int b = 27183 + i * 23; // Numero primo grande

    for (const auto &shingle : shingles) {
      // Funcion hash universal de la forma (ax+b) mod p
      size_t h = hasher(shingle);
      long long hashValue = (static_cast<long long>(a) * h + b) % p;
      signature[i] = std::min(signature[i], static_cast<int>(hashValue));
    }
  }
  return signature;
}
double jaccardSimilarity(const std::set<std::string> &setA,
                         const std::set<std::string> &setB) {
  std::set<std::string> setIntersection, setUnion;
  // Hacemos la intersección de los dos conjuntos de k-shingles
  set_intersection(setA.begin(), setA.end(), setB.begin(), setB.end(),
                   inserter(setIntersection, setIntersection.begin()));

  // Hacemos la union de los dos conjuntos de k-shingles
  set_union(setA.begin(), setA.end(), setB.begin(), setB.end(),
            inserter(setUnion, setUnion.begin()));

  return static_cast<double>(setIntersection.size()) / setUnion.size();
}

double minhashSimilarity(const std::vector<int> &signatureA,
                         const std::vector<int> &signatureB) {
  // Implementación de la similitud de minhash
  if (signatureA.size() != signatureB.size() || signatureA.empty())
    return 0.0;

  int matches = 0;
  int t = signatureA.size();

  for (int i = 0; i < t; ++i) {
    if (signatureA[i] == signatureB[i])
      ++matches;
  }
  return static_cast<double>(matches) / t;
}