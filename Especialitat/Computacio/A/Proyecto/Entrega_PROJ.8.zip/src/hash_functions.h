#pragma once
#include <set>
#include <string>
#include <vector>

std::set<std::string> generateKShingles(const std::string &text, int k);
std::vector<int> generateMinhashSignature(const std::set<std::string> &shingles,
                                          int t);
double jaccardSimilarity(const std::set<std::string> &setA,
                         const std::set<std::string> &setB);

double minhashSimilarity(const std::vector<int> &signatureA,
                         const std::vector<int> &signatureB);