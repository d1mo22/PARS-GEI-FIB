#include "LSH.h"
#include "hash_functions.h"
#include "modes.h"
#include "utils.h"
#include <chrono>
#include <iostream>

void Usage() {
  std::cerr << "Usage: ./main [book] [mode] [k] [n](o [D] para mode 2) [t] \n";
  std::cerr << "book: f para frankenstein, m para mobydick, q para quijote \n";
  std::cerr << "Example modo 1: ./main f 1 3 25 20 \n";
  std::cerr << "Example modo 2: ./main m 2 3 25 20 \n";
}

int main(int argc, char *argv[]) {
  if (argc != 6) {
    Usage();
    return 1;
  } else {
    std::string book;
    switch (argv[1][0]) {
    case 'f':
      book = "frankenstein";
      break;
    case 'm':
      book = "mobydick";
      break;
    case 'q':
      book = "quijote";
      break;
    default:
      Usage();
      return 1;
    }
    // modo 1
    if (atoi(argv[2]) == 1) {
      std::vector<std::string> files = getInputFiles(atoi(argv[4]), book);

      std::vector<std::set<std::string>> shingles = {};
      std::vector<std::vector<int>> signatures = {};
      auto start = std::chrono::high_resolution_clock::now();
      for (size_t i = 0; i < files.size(); i++) {
        std::string doc = fileToString(files[i]);
        std::set<std::string> shingle = generateKShingles(doc, atoi(argv[3]));
        shingles.push_back(shingle);
        std::vector<int> signature =
            generateMinhashSignature(shingles[i], atoi(argv[5]));
        signatures.push_back(signature);
      }
      std::cout << "number of " << atoi(argv[3])
                << "-shingles: " << shingles[0].size() << std::endl;

      int bands = 20;
      mode1(atoi(argv[3]), atoi(argv[4]), bands, shingles, signatures, files,
            argv[1][0]);
      auto end = std::chrono::high_resolution_clock::now();
      std::chrono::duration<double> elapsed = end - start;
      std::cout << "Total time (KShingle + Signature + Mode1): "
                << elapsed.count() + elapsed.count() << " seconds" << std::endl;
    }
    // modo 2
    else if (atoi(argv[2]) == 2) {
      std::string doc =
          fileToString("text-fragments/" + book + "_filtered.txt");
      auto start = std::chrono::high_resolution_clock::now();
      std::set<std::string> shingles = generateKShingles(doc, atoi(argv[3]));
      std::vector<int> signature =
          generateMinhashSignature(shingles, atoi(argv[5]));
      mode2(atoi(argv[3]), atoi(argv[4]), shingles, 'j', argv[1][0]);
      mode2(atoi(argv[3]), atoi(argv[4]), shingles, 'm', argv[1][0]);
      mode2(atoi(argv[3]), atoi(argv[4]), shingles, 'l', argv[1][0]);
      auto end = std::chrono::high_resolution_clock::now();
      std::chrono::duration<double> elapsed = end - start;
      std::cout << "Total time (KShingle + Signature + Mode2): "
                << elapsed.count() + elapsed.count() << " seconds" << std::endl;
    } else {
      Usage();
      return 1;
    }
  }
  return 0;
}
