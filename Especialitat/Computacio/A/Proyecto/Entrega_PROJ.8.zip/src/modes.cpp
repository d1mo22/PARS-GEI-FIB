#include "modes.h"
#include "LSH.h"
#include "hash_functions.h"
#include "utils.h"
#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>

namespace fs = std::filesystem;

double theoreticalSimilarity(double p_i, double p_j) {
  return (p_i * p_j) / (p_i + p_j - p_i * p_j);
}

void mode1(int k, int n, int bands,
           std::vector<std::set<std::string>> &shingles,
           std::vector<std::vector<int>> &signatures,
           std::vector<std::string> &files, char book) {

  std::string oFilePath = "resultados-1-" + std::to_string(k) + "-" +
                          std::string(1, book) + "-" + std::to_string(n) +
                          ".csv";
  std::ofstream csvFile(oFilePath);
  if (!csvFile.is_open()) {
    std::cerr << "Error: Could not create output CSV file." << std::endl;
  }
  csvFile << "Filename1,Filename2,Jaccard,Minhash,Difference" << std::endl;

  for (std::size_t i = 0; i < shingles.size(); i++) {
    for (std::size_t j = i + 1; j < shingles.size(); j++) {
      try {
        if (shingles[i].empty() || shingles[j].empty()) {
          std::cerr
              << "Error: One or both documents have no shingles. Skipping pair."
              << std::endl;
          continue;
        }

        double jaccardSim = jaccardSimilarity(shingles[i], shingles[j]);
        double minhashSim = minhashSimilarity(signatures[i], signatures[j]);

        csvFile << fs::path(files[i]).filename().string() << ","
                << fs::path(files[j]).filename().string() << "," << jaccardSim
                << "," << minhashSim << "," << std::abs(jaccardSim - minhashSim)
                << std::endl;
      } catch (const std::exception &e) {
        std::cerr << "Error processing pair " << files[i] << " and " << files[j]
                  << ": " << e.what() << std::endl;
      }
    }
  }
  csvFile.close();

  std::string lshFilePath = "resultados-1-lsh-" + std::to_string(k) + "-" +
                            std::string(1, book) + "-" + std::to_string(n) +
                            ".csv";
  std::ofstream lshFile(lshFilePath);
  if (!lshFile.is_open()) {
    std::cerr << "Error: Could not create LSH output file." << std::endl;
    return;
  }

  lshFile << "Doc1,Doc2" << std::endl;
  std::vector<std::pair<int, int>> candidates = LSH(signatures, bands);
  for (const auto &c : candidates) {
    lshFile << fs::path(files[c.first]).filename().string() << ","
            << fs::path(files[c.second]).filename().string() << std::endl;
  }
  lshFile.close();
}

void mode2(int k, int D, std::set<std::string> &shingles, char sim, char book) {
  // generamos D >= documentos virtuales formados por conjuntos de k-shingles
  // de un documento base
  std::vector<std::set<std::string>> virtualDocs;
  std::vector<int> shingleCounts;
  int shinglesSize = shingles.size();

  for (int i = 0; i < D; i++) {
    shingleCounts.push_back(50 + i * 10);
  }

  for (int i = 0; i < D; i++) {
    int n_i = std::min(shingleCounts[i], shinglesSize);
    virtualDocs.push_back(randomSample(shingles, n_i));
  }

  // generamos la matriz de similitud para todos los pares de documentos
  // virtuales en CSV
  std::string oFilePath = "resultados-2-" + std::to_string(k) + "-" +
                          std::string(1, book) + "-" + std::to_string(D) + "-" +
                          std::string(1, sim) + ".csv";
  std::ofstream csvFile(oFilePath);
  if (!csvFile.is_open()) {
    std::cerr << "Error: Could not create output CSV file." << std::endl;
    return;
  }

  if (sim != 'l') {
    csvFile << "Doc ID";
    for (int i = 0; i < D; i++) {
      csvFile << "," << i + 1;
    }
    csvFile << std::endl;
  } else {
    csvFile << "Doc ID 1,Doc ID 2" << std::endl;
  }

  std::vector<std::vector<int>> signatures;
  if (sim == 'm' || sim == 'l') {
    for (int i = 0; i < D; i++) {
      std::vector<int> signature =
          generateMinhashSignature(virtualDocs[i], 600);
      signatures.push_back(signature);
    }
  }

  if (sim != 'l') {
    // Matriz de similitud
    for (int i = 0; i < D; i++) {
      csvFile << i + 1;
      for (int j = 0; j < D; j++) {
        if (sim == 'j') {
          double similarity = jaccardSimilarity(virtualDocs[i], virtualDocs[j]);
          csvFile << "," << std::fixed << std::setprecision(2) << similarity;

          double p_i =
              static_cast<double>(virtualDocs[i].size()) / shingles.size();
          double p_j =
              static_cast<double>(virtualDocs[j].size()) / shingles.size();
          double expectedSimilarity = theoreticalSimilarity(p_i, p_j);

          std::string diffFilePath = "resultados-2-diff-" + std::to_string(k) +
                                     "-" + std::string(1, book) + "-" +
                                     std::to_string(D) + ".csv";
          static bool headerWritten = false;
          std::ofstream diffFile(diffFilePath,
                                 headerWritten ? std::ios::app : std::ios::out);

          if (!diffFile.is_open()) {
            std::cerr << "Error: Could not create difference file."
                      << std::endl;
            return;
          }

          if (!headerWritten) {
            diffFile << "Doc1,Doc2,Actual,Theoretical,Difference\n";
            headerWritten = true;
          }

          diffFile << i + 1 << "," << j + 1 << "," << std::fixed
                   << std::setprecision(4) << similarity << ","
                   << expectedSimilarity << ","
                   << similarity - expectedSimilarity << "\n";
          diffFile.close();
        } else if (sim == 'm') {
          double similarity = minhashSimilarity(signatures[i], signatures[j]);
          csvFile << "," << std::fixed << std::setprecision(2) << similarity;
        }
      }
      csvFile << std::endl;
    }
  } else {
    // candidatos LSH
    std::vector<std::pair<int, int>> candidates = LSH(signatures, 20);
    for (const auto &c : candidates) {
      csvFile << c.first + 1 << "," << c.second + 1 << std::endl;
    }
  }

  csvFile.close();
}