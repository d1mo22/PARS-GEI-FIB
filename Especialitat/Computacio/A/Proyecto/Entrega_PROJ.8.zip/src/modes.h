#pragma once
#include <set>
#include <string>
#include <vector>

void mode1(int k, int n, int bands,
           std::vector<std::set<std::string>> &shingles,
           std::vector<std::vector<int>> &signatures,
           std::vector<std::string> &files, char book);

void mode2(int k, int D, std::set<std::string> &shingles, char sim, char book);