#include "utils.h"
#include <algorithm>  // Para shuffle
#include <filesystem> // Para fs::exists
#include <fstream>    // Para ifstream
#include <iostream>   // Para cout, cerr
#include <random>     // Para mt19937, random_device
#include <sstream>    // Para stringstream

namespace fs = std::filesystem;

std::string fileToString(const std::string &filename) {
  std::ifstream file(filename);
  std::stringstream buffer;

  if (file.is_open()) {
    buffer << file.rdbuf();
    file.close();
    return buffer.str();
  }
  return ""; // Retorna string vacío si falla la apertura
}

std::vector<std::string> splitIntoWords(const std::string &text) {
  std::vector<std::string> words;
  std::stringstream ss(text);
  std::string word;

  while (ss >> word) {
    words.push_back(word);
  }
  return words;
}

std::string generatePermutation(const std::vector<std::string> &words,
                                std::mt19937 &gen) {
  std::vector<std::string> permutedWords = words;
  std::shuffle(permutedWords.begin(), permutedWords.end(), gen);
  std::string result;
  for (const auto &word : permutedWords) {
    result += word;
  }
  return result;
}

std::vector<std::string> getInputFiles(const int n, const std::string &text) {
  std::string baseFilename = "permutations-1/" + text;
  std::string fileExtension = ".txt";
  int startNumber = 1;
  int endNumber = n;

  std::vector<std::string> inputFiles;

  for (int i = startNumber; i <= endNumber; i++) {
    std::string filename =
        baseFilename + "_" + std::to_string(i) + fileExtension;
    if (fs::exists(filename)) {
      inputFiles.push_back(filename);
    } else {
      std::cout << "Warning: File " << filename << " does not exist. Skipping."
                << std::endl;
    }
  }

  if (inputFiles.empty()) {
    std::cerr << "Error: No valid input files found." << std::endl;
    return {};
  }
  return inputFiles;
}

std::set<std::string> randomSample(const std::set<std::string> &sourceSet,
                                   size_t n) {
  std::set<std::string> result;
  std::vector<std::string> sourceVector(sourceSet.begin(), sourceSet.end());

  if (n >= sourceSet.size()) {
    return sourceSet;
  }

  std::random_device rd;
  std::mt19937 gen(rd());
  std::shuffle(sourceVector.begin(), sourceVector.end(), gen);

  for (size_t i = 0; i < n; i++) {
    result.insert(sourceVector[i]);
  }
  return result;
}