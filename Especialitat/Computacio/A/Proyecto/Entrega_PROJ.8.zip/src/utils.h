#pragma once
#include <random>
#include <set>
#include <string>
#include <vector>

std::string fileToString(const std::string &filename);

std::vector<std::string> splitIntoWords(const std::string &text);

std::string generatePermutation(const std::vector<std::string> &words,
                                std::mt19937 &gen);

std::vector<std::string> getInputFiles(const int n, const std::string &text);

std::set<std::string> randomSample(const std::set<std::string> &sourceSet,
                                   size_t n);