# Predicción de Partidas VCT (Valorant Champions Tour)

Proyecto de Machine Learning para predecir resultados de partidas competitivas de Valorant Champions Tour usando múltiples modelos de clasificación.

## Requisitos

- Python 3.8+
- Jupyter Notebook

## Instalación

```bash
pip install -r requirements.txt
```

## Ejecución

### Con dataset pre-generado

Si ya tienes los archivos CSV del dataset:

```bash
jupyter notebook vct21-25.ipynb
```

Luego ejecutar las celdas secuencialmente.

### Generar dataset desde cero

Para crear el dataset desde los datos de Kaggle:

1. Configurar Kaggle API:
   - Descargar `kaggle.json` desde [tu cuenta de Kaggle](https://www.kaggle.com/settings)
   - Colocarlo en `~/.kaggle/` (Linux/Mac) o `C:\Users\<Usuario>\.kaggle\` (Windows)

2. Ejecutar:
   ```bash
   python create_dataset.py
   ```

3. Abrir el notebook:
   ```bash
   jupyter notebook vct21-25.ipynb
   ```

## Contenido del Análisis

El notebook `vct21-25.ipynb` incluye:

1. **Exploración de datos**: Análisis estadístico, valores perdidos, outliers, correlaciones
2. **Visualizaciones**: Distribuciones, PCA, t-SNE
3. **Modelos**: Logistic Regression, LDA, Linear SVM, Random Forest, Gradient Boosting, MLP
4. **Optimización**: Hiperparámetros con Optuna
5. **Evaluación**: Métricas, matrices de confusión, ROC curves, feature importance

## Dataset

- **Fuente**: [VCT 2021-2023 Kaggle](https://www.kaggle.com/datasets/ryanluong1/valorant-champion-tour-2021-2023-data)
- **Muestras**: ~30,000 partidas
- **Features**: 36 características (estadísticas históricas, win rates, head-to-head, etc.)
- **Target**: `winner` (0 o 1)

---

**Nota**: Proyecto académico del curso APA.
