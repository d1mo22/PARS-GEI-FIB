"""
VCT Match Prediction Dataset Generator
======================================
Generates a balanced dataset for predicting Valorant Champions Tour match outcomes.

Key Features:
- Temporal integrity: Uses Match ID ordering to prevent data leakage
- Historical statistics: Rolling 5-match averages with proper shift
- Advanced features: Agent diversity, head-to-head history, tournament tier
- Data balancing: Random team swap to eliminate side bias

Output Files:
- vct_match_prediction_dataset.csv: Full dataset with metadata
- vct_match_prediction_dataset_ML.csv: Features + target only
"""

import os
import pandas as pd
import numpy as np
import kagglehub


def download_dataset():
    """Download VCT dataset from Kaggle."""
    print("Downloading dataset from Kaggle...")
    data_path = kagglehub.dataset_download("ryanluong1/valorant-champion-tour-2021-2023-data")
    print(f"Dataset downloaded to: {data_path}\n")
    return data_path


def load_overview_data(data_path):
    """Load granular player statistics from overview.csv files."""
    print("Loading player statistics...")
    all_overview = []
    
    for year in ['2021', '2022', '2023', '2024', '2025']:
        overview_path = os.path.join(data_path, f'vct_{year}', 'matches', 'overview.csv')
        
        if os.path.exists(overview_path):
            df_year = pd.read_csv(overview_path)
            df_year['year'] = year
            all_overview.append(df_year)
            print(f"  {year}: {len(df_year)} records loaded")
    
    if not all_overview:
        raise FileNotFoundError("No overview.csv files found")
    
    df_overview = pd.concat(all_overview, ignore_index=True)
    
    # Filter for complete match statistics (Side='both' contains aggregated stats for entire match)
    if 'Side' in df_overview.columns:
        df_overview = df_overview[df_overview['Side'] == 'both'].copy()
    
    print(f"Total records: {len(df_overview)}\n")
    return df_overview


def load_match_ids(data_path):
    """Load Match IDs for temporal ordering."""
    print("Loading Match IDs for temporal ordering...")
    ids_path = os.path.join(data_path, 'all_ids', 'all_matches_games_ids.csv')
    
    if not os.path.exists(ids_path):
        raise FileNotFoundError(f"Match IDs file not found: {ids_path}")
    
    df_ids = pd.read_csv(ids_path)
    df_ids['Year'] = df_ids['Year'].astype(str)
    
    match_ids_unique = df_ids[['Match Name', 'Match ID', 'Year']].drop_duplicates()
    print(f"Loaded {len(match_ids_unique)} unique matches\n")
    
    return df_ids, match_ids_unique


def aggregate_team_stats(df_overview, match_ids_unique):
    """Aggregate player statistics by team and match."""
    print("Aggregating team statistics per match...")
    
    # Process headshot percentage
    df_overview['Headshot_Pct'] = pd.to_numeric(
        df_overview['Headshot %'].str.rstrip('%'), errors='coerce'
    ).fillna(0)
    
    # Aggregate by team and match
    team_stats = df_overview.groupby(['Match Name', 'Team', 'year']).agg({
        'Rating': ['mean', 'std', 'max', 'min'],
        'Average Combat Score': 'mean',
        'Average Damage Per Round': 'mean',
        'Kills': 'sum',
        'Deaths': 'sum',
        'Assists': 'sum',
        'First Kills': 'sum',
        'First Deaths': 'sum',
        'Headshot_Pct': 'mean',
        'Player': 'count'
    }).reset_index()
    
    team_stats.columns = ['_'.join(col).strip('_') if col[1] else col[0] 
                          for col in team_stats.columns]
    
    # Calculate derived ratios
    team_stats['KD_Ratio'] = team_stats['Kills_sum'] / team_stats['Deaths_sum'].replace(0, 1)
    team_stats['FK_Ratio'] = team_stats['First Kills_sum'] / team_stats['First Deaths_sum'].replace(0, 1)
    
    # Merge with Match IDs
    team_stats = team_stats.merge(
        match_ids_unique,
        left_on=['Match Name', 'year'],
        right_on=['Match Name', 'Year'],
        how='left'
    )
    
    team_stats = team_stats[team_stats['Match ID'].notna()]
    team_stats = team_stats.sort_values(['Team', 'year', 'Match ID']).reset_index(drop=True)
    
    print(f"Aggregated stats for {len(team_stats)} team-match records\n")
    return team_stats


def calculate_historical_stats(team_stats):
    """Calculate rolling 5-match historical statistics with shift to prevent leakage."""
    print("Calculating historical statistics (rolling 5 matches)...")
    
    stat_cols = {
        'rating_mean': 'Rating_mean',
        'rating_std': 'Rating_std',
        'rating_max': 'Rating_max',
        'rating_min': 'Rating_min',
        'acs_mean': 'Average Combat Score_mean',
        'adr_mean': 'Average Damage Per Round_mean',
        'kd_ratio': 'KD_Ratio',
        'fk_ratio': 'FK_Ratio',
        'headshot_pct': 'Headshot_Pct_mean'
    }
    
    for short_name, col_name in stat_cols.items():
        team_stats[f"{short_name}_rolling5"] = (
            team_stats.groupby('Team')[col_name]
            .transform(lambda s: s.shift(1).rolling(5, min_periods=1).mean())
        )
    
    print("Historical statistics calculated\n")
    return team_stats


def load_match_results(data_path, match_ids_unique):
    """Load match results and determine winners."""
    print("Loading match results...")
    all_scores = []
    
    for year in ['2021', '2022', '2023', '2024', '2025']:
        scores_path = os.path.join(data_path, f'vct_{year}', 'matches', 'scores.csv')
        
        if os.path.exists(scores_path):
            df_year = pd.read_csv(scores_path)
            df_year['year'] = year
            
            # Determine winner: 1 = Team A, 0 = Team B
            def determine_winner(row):
                result = str(row['Match Result']).strip()
                team_a = str(row['Team A']).strip()
                team_b = str(row['Team B']).strip()
                
                if result.startswith(team_a) and result.endswith('won'):
                    return 1
                elif result.startswith(team_b) and result.endswith('won'):
                    return 0
                elif team_a in result and team_b not in result:
                    return 1
                elif team_b in result and team_a not in result:
                    return 0
                return None
            
            df_year['winner'] = df_year.apply(determine_winner, axis=1)
            df_year = df_year[df_year['winner'].notna()]
            all_scores.append(df_year)
            print(f"  {year}: {len(df_year)} matches loaded")
    
    if not all_scores:
        raise FileNotFoundError("No match result files found")
    
    df_scores = pd.concat(all_scores, ignore_index=True)
    
    # Merge with Match IDs
    df_scores = df_scores.merge(
        match_ids_unique,
        left_on=['Match Name', 'year'],
        right_on=['Match Name', 'Year'],
        how='left'
    )
    
    df_scores = df_scores[df_scores['Match ID'].notna()]
    df_scores = df_scores.sort_values(['year', 'Match ID']).reset_index(drop=True)
    
    print(f"Total matches: {len(df_scores)}\n")
    return df_scores


def merge_stats_with_matches(df_scores, team_stats):
    """Merge historical team statistics with match results."""
    print("Merging historical statistics with matches...")
    
    hist_cols = [col for col in team_stats.columns if '_rolling5' in col]
    team_hist = team_stats[['Match Name', 'Team', 'year', 'Match ID'] + hist_cols]
    
    # Merge Team A stats
    matches = df_scores.merge(
        team_hist.add_prefix('teamA_'),
        left_on=['Match Name', 'Team A', 'year'],
        right_on=['teamA_Match Name', 'teamA_Team', 'teamA_year'],
        how='left'
    )
    
    # Merge Team B stats
    matches = matches.merge(
        team_hist.add_prefix('teamB_'),
        left_on=['Match Name', 'Team B', 'year'],
        right_on=['teamB_Match Name', 'teamB_Team', 'teamB_year'],
        how='left'
    )
    
    # Clean duplicate columns
    matches.drop(columns=[
        'teamA_Match Name', 'teamA_Team', 'teamA_year', 'teamA_Match ID',
        'teamB_Match Name', 'teamB_Team', 'teamB_year', 'teamB_Match ID'
    ], inplace=True)
    
    # Keep only matches with complete stats
    matches = matches[
        matches['teamA_rating_mean_rolling5'].notna() & 
        matches['teamB_rating_mean_rolling5'].notna()
    ]
    
    print(f"Matches with complete statistics: {len(matches)}\n")
    return matches


def calculate_recent_winrate(team, current_match_id, df_scores, window=5):
    """Calculate team win rate in previous 'window' matches."""
    previous_matches = df_scores[
        (df_scores['Match ID'] < current_match_id) & 
        ((df_scores['Team A'] == team) | (df_scores['Team B'] == team))
    ].tail(window)
    
    if len(previous_matches) == 0:
        return 0.5, 0
    
    wins = sum(
        1 for _, match in previous_matches.iterrows()
        if (match['Team A'] == team and match['winner'] == 1) or
           (match['Team B'] == team and match['winner'] == 0)
    )
    
    return wins / len(previous_matches), len(previous_matches)


def add_recent_winrates(matches, df_scores):
    """Add recent win rate features for both teams."""
    print("Calculating recent win rates...")
    
    winrates_a, winrates_b = [], []
    matches_a, matches_b = [], []
    
    for idx, row in matches.iterrows():
        if idx % 1000 == 0:
            print(f"  Processing match {idx}/{len(matches)}...")
        
        wr_a, nm_a = calculate_recent_winrate(row['Team A'], row['Match ID'], df_scores)
        wr_b, nm_b = calculate_recent_winrate(row['Team B'], row['Match ID'], df_scores)
        
        winrates_a.append(wr_a)
        winrates_b.append(wr_b)
        matches_a.append(nm_a)
        matches_b.append(nm_b)
    
    matches['teamA_recent_winrate'] = winrates_a
    matches['teamB_recent_winrate'] = winrates_b
    matches['teamA_recent_matches'] = matches_a
    matches['teamB_recent_matches'] = matches_b
    
    print("Recent win rates calculated\n")
    return matches


def load_map_data(data_path, df_ids):
    """Load map-level results and calculate map win rates."""
    print("Loading map statistics...")
    all_maps = []
    
    for year in ['2021', '2022', '2023', '2024', '2025']:
        maps_path = os.path.join(data_path, f'vct_{year}', 'matches', 'maps_scores.csv')
        
        if os.path.exists(maps_path):
            df_maps = pd.read_csv(maps_path)
            df_maps['year'] = year
            all_maps.append(df_maps)
    
    df_maps = pd.concat(all_maps, ignore_index=True)
    
    # Determine map winner
    def get_map_winner(row):
        try:
            score_a = int(row['Team A Score'])
            score_b = int(row['Team B Score'])
            return 'Team A' if score_a > score_b else 'Team B'
        except:
            return None
    
    df_maps['map_winner'] = df_maps.apply(get_map_winner, axis=1)
    df_maps = df_maps[df_maps['map_winner'].notna()]
    
    # Merge with Match IDs
    df_maps = df_maps.merge(
        df_ids[['Match Name', 'Match ID', 'Map', 'Year']],
        left_on=['Match Name', 'Map', 'year'],
        right_on=['Match Name', 'Map', 'Year'],
        how='left'
    )
    
    df_maps = df_maps[df_maps['Match ID'].notna()]
    df_maps = df_maps.sort_values(['year', 'Match ID']).reset_index(drop=True)
    
    # Get first map of each match
    match_first_maps = df_maps.groupby('Match Name').first()[['Map', 'Match ID']].reset_index()
    
    print(f"Loaded {len(df_maps)} map results\n")
    return df_maps, match_first_maps


def calculate_map_winrate(team, map_name, current_match_id, df_maps):
    """Calculate team win rate on specific map before current match."""
    team_maps = df_maps[
        ((df_maps['Team A'] == team) | (df_maps['Team B'] == team)) &
        (df_maps['Map'] == map_name) &
        (df_maps['Match ID'] < current_match_id)
    ]
    
    if len(team_maps) == 0:
        return 0.5
    
    wins = sum(
        1 for _, map_row in team_maps.iterrows()
        if (map_row['Team A'] == team and map_row['map_winner'] == 'Team A') or
           (map_row['Team B'] == team and map_row['map_winner'] == 'Team B')
    )
    
    return wins / len(team_maps)


def add_map_winrates(matches, df_maps, match_first_maps):
    """Add map-specific win rate features."""
    print("Calculating map win rates...")
    
    # Add map information to matches
    matches = matches.merge(
        match_first_maps[['Match Name', 'Map']],
        on='Match Name',
        how='left'
    )
    
    map_winrates_a, map_winrates_b = [], []
    
    for idx, row in matches.iterrows():
        if idx % 1000 == 0:
            print(f"  Processing match {idx}/{len(matches)}...")
        
        wr_a = calculate_map_winrate(row['Team A'], row['Map'], row['Match ID'], df_maps)
        wr_b = calculate_map_winrate(row['Team B'], row['Map'], row['Match ID'], df_maps)
        
        map_winrates_a.append(wr_a)
        map_winrates_b.append(wr_b)
    
    matches['teamA_map_winrate'] = map_winrates_a
    matches['teamB_map_winrate'] = map_winrates_b
    
    print("Map win rates calculated\n")
    return matches


def calculate_current_streak(team, current_match_id, df_scores):
    """Calculate current winning/losing streak for team."""
    team_matches = df_scores[
        ((df_scores['Team A'] == team) | (df_scores['Team B'] == team)) &
        (df_scores['Match ID'] < current_match_id)
    ].tail(5)
    
    if len(team_matches) == 0:
        return 0
    
    streak = 0
    last_result = None
    
    for _, match in team_matches[::-1].iterrows():
        won = (match['Team A'] == team and match['winner'] == 1) or \
              (match['Team B'] == team and match['winner'] == 0)
        
        if last_result is None or last_result == won:
            streak = streak + 1 if won else streak - 1
            last_result = won
        else:
            break
    
    return streak


def add_streaks(matches, df_scores):
    """Add current streak features."""
    print("Calculating current streaks...")
    
    streaks_a, streaks_b = [], []
    
    for idx, row in matches.iterrows():
        if idx % 1000 == 0:
            print(f"  Processing match {idx}/{len(matches)}...")
        
        streak_a = calculate_current_streak(row['Team A'], row['Match ID'], df_scores)
        streak_b = calculate_current_streak(row['Team B'], row['Match ID'], df_scores)
        
        streaks_a.append(streak_a)
        streaks_b.append(streak_b)
    
    matches['teamA_streak'] = streaks_a
    matches['teamB_streak'] = streaks_b
    
    print("Streaks calculated\n")
    return matches


def calculate_h2h_winrate(team_a, team_b, current_match_id, df_scores, window=10):
    """Calculate head-to-head win rate (Team A vs Team B)."""
    h2h_matches = df_scores[
        ((df_scores['Team A'] == team_a) & (df_scores['Team B'] == team_b) |
         (df_scores['Team A'] == team_b) & (df_scores['Team B'] == team_a)) &
        (df_scores['Match ID'] < current_match_id)
    ].tail(window)
    
    if len(h2h_matches) == 0:
        return 0.5
    
    wins_a = sum(
        1 for _, match in h2h_matches.iterrows()
        if (match['Team A'] == team_a and match['winner'] == 1) or
           (match['Team B'] == team_a and match['winner'] == 0)
    )
    
    return wins_a / len(h2h_matches)


def add_head_to_head(matches, df_scores):
    """Add head-to-head history features."""
    print("Calculating head-to-head history...")
    
    h2h_rates = []
    
    for idx, row in matches.iterrows():
        if idx % 1000 == 0:
            print(f"  Processing match {idx}/{len(matches)}...")
        
        h2h_rate = calculate_h2h_winrate(row['Team A'], row['Team B'], row['Match ID'], df_scores)
        h2h_rates.append(h2h_rate)
    
    matches['teamA_h2h_winrate'] = h2h_rates
    
    print("Head-to-head history calculated\n")
    return matches


def calculate_agent_diversity(team, current_match_id, df_overview, window=5):
    """Calculate agent pool diversity (number of unique agents used)."""
    team_previous = df_overview[
        (df_overview['Team'] == team) &
        (df_overview['Match ID'] < current_match_id)
    ].sort_values('Match ID').tail(window * 5)
    
    if len(team_previous) == 0:
        return 5.0
    
    unique_agents = team_previous['Agents'].dropna().unique()
    return len(unique_agents)


def add_agent_diversity(matches, df_overview, match_ids_unique):
    """Add agent pool diversity features."""
    print("Calculating agent pool diversity...")
    
    # Add Match ID to overview if missing
    if 'Match ID' not in df_overview.columns:
        df_overview = df_overview.merge(
            match_ids_unique,
            left_on=['Match Name', 'year'],
            right_on=['Match Name', 'Year'],
            how='left'
        )
    
    # Calculate for sample to speed up processing
    sample_size = min(1000, len(matches))
    diversity_cache = {}
    
    for idx in matches.head(sample_size).index:
        row = matches.loc[idx]
        
        if idx % 200 == 0:
            print(f"  Calculating sample {idx}/{sample_size}...")
        
        key_a = (row['Team A'], row['Match ID'])
        if key_a not in diversity_cache:
            diversity_cache[key_a] = calculate_agent_diversity(
                row['Team A'], row['Match ID'], df_overview
            )
        
        key_b = (row['Team B'], row['Match ID'])
        if key_b not in diversity_cache:
            diversity_cache[key_b] = calculate_agent_diversity(
                row['Team B'], row['Match ID'], df_overview
            )
    
    # Calculate mean for default value
    mean_diversity = np.mean(list(diversity_cache.values())) if diversity_cache else 5.0
    
    # Assign to all matches
    agent_div_a, agent_div_b = [], []
    
    for _, row in matches.iterrows():
        key_a = (row['Team A'], row['Match ID'])
        key_b = (row['Team B'], row['Match ID'])
        
        agent_div_a.append(diversity_cache.get(key_a, mean_diversity))
        agent_div_b.append(diversity_cache.get(key_b, mean_diversity))
    
    matches['teamA_agent_diversity'] = agent_div_a
    matches['teamB_agent_diversity'] = agent_div_b
    
    print(f"Agent diversity calculated (range: {min(agent_div_a + agent_div_b):.1f}-{max(agent_div_a + agent_div_b):.1f})\n")
    return matches


def get_tournament_tier(tournament_name):
    """Assign tournament importance tier."""
    name_lower = str(tournament_name).lower()
    
    # Check specific tournament types first (higher priority)
    if 'last chance' in name_lower:
        return 2
    elif 'masters' in name_lower:
        return 3
    elif 'champions' in name_lower and any(year in name_lower for year in ['2021', '2022', '2023']):
        return 4
    elif 'champions' in name_lower or 'international' in name_lower:
        return 3.5
    else:
        return 1


def add_tournament_context(matches):
    """Add tournament-level context features."""
    print("Adding tournament context...")
    
    matches['tournament_tier'] = matches['Tournament'].apply(get_tournament_tier)
    
    matches['is_playoff'] = matches['Stage'].str.contains(
        'Playoff|Knockout|Bracket|Elimination|Quarter|Semi',
        case=False, na=False
    ).astype(int)
    
    matches['is_grand_final'] = matches['Stage'].str.contains(
        'Grand Final|Final|Championship',
        case=False, na=False
    ).astype(int)
    
    matches['is_international'] = matches['Tournament'].str.contains(
        'Masters|Champions|International|VCT',
        case=False, na=False
    ).astype(int)
    
    print("Tournament context added\n")
    return matches


def create_comparative_features(df):
    """Create difference-based comparative features."""
    print("Creating comparative features...")
    
    # Fill NaN values
    hist_cols = [c for c in df.columns if '_rolling5' in c]
    df[hist_cols] = df[hist_cols].fillna(0)
    df['teamA_agent_diversity'] = df.get('teamA_agent_diversity', 5.0).fillna(5.0)
    df['teamB_agent_diversity'] = df.get('teamB_agent_diversity', 5.0).fillna(5.0)
    df['teamA_h2h_winrate'] = df['teamA_h2h_winrate'].fillna(0.5)
    df['tournament_tier'] = df['tournament_tier'].fillna(1)
    
    # Statistical differences
    df['diff_rating'] = df['teamA_rating_mean_rolling5'] - df['teamB_rating_mean_rolling5']
    df['diff_acs'] = df['teamA_acs_mean_rolling5'] - df['teamB_acs_mean_rolling5']
    df['diff_adr'] = df['teamA_adr_mean_rolling5'] - df['teamB_adr_mean_rolling5']
    df['diff_kd'] = df['teamA_kd_ratio_rolling5'] - df['teamB_kd_ratio_rolling5']
    df['diff_fk'] = df['teamA_fk_ratio_rolling5'] - df['teamB_fk_ratio_rolling5']
    df['diff_headshot'] = df['teamA_headshot_pct_rolling5'] - df['teamB_headshot_pct_rolling5']
    
    # Star power and consistency
    df['diff_star_power'] = df['teamA_rating_max_rolling5'] - df['teamB_rating_max_rolling5']
    df['teamA_consistency'] = df['teamA_rating_max_rolling5'] - df['teamA_rating_min_rolling5']
    df['teamB_consistency'] = df['teamB_rating_max_rolling5'] - df['teamB_rating_min_rolling5']
    df['diff_consistency'] = df['teamA_consistency'] - df['teamB_consistency']
    
    # Win rates
    df['diff_recent_winrate'] = df['teamA_recent_winrate'] - df['teamB_recent_winrate']
    df['diff_map_winrate'] = df['teamA_map_winrate'] - df['teamB_map_winrate']
    
    # Advanced features
    df['diff_agent_diversity'] = df['teamA_agent_diversity'] - df['teamB_agent_diversity']
    df['h2h_advantage'] = df['teamA_h2h_winrate'] - 0.5
    
    # Momentum and streaks
    df['diff_streak'] = df['teamA_streak'] - df['teamB_streak']
    df['recent_form_momentum'] = df['diff_recent_winrate'].abs() * np.sign(df['diff_streak'])
    
    # Interaction features
    df['rating_form_interaction'] = df['diff_rating'] * df['diff_recent_winrate']
    df['star_h2h_interaction'] = df['diff_star_power'] * df['h2h_advantage']
    df['agent_map_interaction'] = df['diff_agent_diversity'] * df['diff_map_winrate']
    
    # Ratios
    df['rating_ratio'] = np.where(
        df['teamB_rating_mean_rolling5'] != 0,
        df['teamA_rating_mean_rolling5'] / df['teamB_rating_mean_rolling5'],
        1.0
    )
    
    print("Comparative features created\n")
    return df


def add_categorical_features(df):
    """Add one-hot encoded categorical features."""
    print("Adding categorical features...")
    
    # Map encoding
    df['Map'] = df['Map'].fillna('Unknown')
    top_maps = df['Map'].value_counts().head(10).index.tolist()
    
    for map_name in top_maps:
        if map_name != 'Unknown':
            col_name = f'map_{map_name.replace(" ", "_")}'
            df[col_name] = (df['Map'] == map_name).astype(int)
    
    map_cols = [col for col in df.columns if col.startswith('map_')]
    
    # Year encoding
    year_dummies = pd.get_dummies(df['year'], prefix='year', drop_first=False, dtype=int)
    df = pd.concat([df, year_dummies], axis=1)
    
    print(f"  Map features: {len(map_cols)}")
    print(f"  Year features: {len(year_dummies.columns)}\n")
    
    return df, map_cols, year_dummies.columns.tolist()


def prepare_final_dataset(df, map_cols, year_cols):
    """Prepare final feature set and metadata."""
    print("Preparing final dataset...")
    
    feature_cols = [
        # Statistical differences
        'diff_rating', 'diff_acs', 'diff_adr', 'diff_kd', 'diff_fk', 'diff_headshot',
        
        # Star power and consistency
        'diff_star_power', 'diff_consistency',
        
        # Win rates
        'diff_recent_winrate', 'diff_map_winrate',
        
        # Advanced features
        'diff_agent_diversity', 'h2h_advantage', 'tournament_tier',
        
        # Momentum
        'diff_streak', 'recent_form_momentum',
        
        # Interactions
        'rating_form_interaction', 'star_h2h_interaction', 'agent_map_interaction',
        
        # Ratios
        'rating_ratio',
        
        # Context
        'is_playoff', 'is_grand_final', 'is_international'
    ] + map_cols + year_cols
    
    # Remove duplicates
    feature_cols = list(dict.fromkeys(feature_cols))
    
    df['winner'] = df['winner'].astype(int)
    
    metadata_cols = ['Match Name', 'Tournament', 'Team A', 'Team B', 'year']
    cols_to_keep = metadata_cols + feature_cols + ['winner']
    
    df_final = df[cols_to_keep].copy()
    
    print(f"Final shape: {df_final.shape}")
    print(f"Total features: {len(feature_cols)}\n")
    
    return df_final, feature_cols


def balance_dataset(df, feature_cols):
    """Balance dataset by randomly swapping teams."""
    print("Balancing dataset...")
    print(f"Original balance: {(df['winner'] == 1).sum()} Team A wins / {(df['winner'] == 0).sum()} Team B wins")
    
    np.random.seed(42)
    rows_to_flip = np.random.choice(len(df), size=len(df) // 2, replace=False)
    
    df_flipped = df.loc[rows_to_flip].copy()
    
    # Swap teams
    df_flipped['Team A'], df_flipped['Team B'] = df.loc[rows_to_flip, 'Team B'].values, df.loc[rows_to_flip, 'Team A'].values
    
    # Flip winner
    df_flipped['winner'] = 1 - df.loc[rows_to_flip, 'winner'].values
    
    # Invert differences and interactions
    diff_features = [col for col in feature_cols if col.startswith('diff_') or col.endswith('_interaction')]
    for col in diff_features:
        if col in df_flipped.columns:
            df_flipped[col] = -df.loc[rows_to_flip, col].values
    
    # Invert ratios
    if 'rating_ratio' in df_flipped.columns:
        df_flipped['rating_ratio'] = np.where(
            df.loc[rows_to_flip, 'rating_ratio'] != 0,
            1.0 / df.loc[rows_to_flip, 'rating_ratio'],
            1.0
        )
    
    # Invert h2h advantage
    if 'h2h_advantage' in df_flipped.columns:
        df_flipped['h2h_advantage'] = -df.loc[rows_to_flip, 'h2h_advantage'].values
    
    df.loc[rows_to_flip] = df_flipped
    
    print(f"Balanced: {(df['winner'] == 1).sum()} Team A wins / {(df['winner'] == 0).sum()} Team B wins")
    
    # Remove duplicates
    len_before = len(df)
    df = df.drop_duplicates(subset=feature_cols + ['winner'], keep='first')
    len_after = len(df)
    
    if len_before > len_after:
        print(f"Removed {len_before - len_after} duplicates")
    
    print(f"Final unique matches: {len_after}\n")
    return df


def save_datasets(df, feature_cols):
    """Save complete and ML-only datasets."""
    print("Saving datasets...")
    
    # Remove any remaining duplicates
    len_before = len(df)
    df = df.drop_duplicates(keep='first')
    len_after = len(df)
    
    if len_before > len_after:
        print(f"Removed {len_before - len_after} duplicate rows")
    
    # Save complete dataset
    output_full = 'vct_match_prediction_dataset.csv'
    df.to_csv(output_full, index=False)
    print(f"Complete dataset saved: {output_full}")
    
    # Save ML dataset (features only)
    output_ml = 'vct_match_prediction_dataset_ML.csv'
    df_ml = df[feature_cols + ['winner']].copy()
    
    if df_ml.columns.duplicated().any():
        df_ml = df_ml.loc[:, ~df_ml.columns.duplicated()]
    
    df_ml.to_csv(output_ml, index=False)
    print(f"ML dataset saved: {output_ml}\n")
    
    return output_ml


def print_summary(df, feature_cols, output_ml):
    """Print final summary statistics."""
    print("=" * 80)
    print("DATASET GENERATION COMPLETE")
    print("=" * 80)
    print(f"\nSummary:")
    print(f"  Total matches: {len(df)}")
    print(f"  Total features: {len(feature_cols)}")
    print(f"  Balance: {(df['winner'] == 1).sum()} Team A wins / {(df['winner'] == 0).sum()} Team B wins")
    print(f"\nKey Features:")
    print(f"  - Historical statistics (rolling 5 matches)")
    print(f"  - Recent win rates and map performance")
    print(f"  - Head-to-head history")
    print(f"  - Agent pool diversity")
    print(f"  - Tournament context")
    print(f"  - Momentum and streaks")
    print(f"\nData Integrity:")
    print(f"  - Temporal ordering via Match ID")
    print(f"  - Historical features use shift(1) to prevent leakage")
    print(f"  - All calculations respect match chronology")
    print(f"\nNext step: Train models using '{output_ml}'")


def main():
    """Main execution pipeline."""
    # Data loading
    data_path = download_dataset()
    df_overview = load_overview_data(data_path)
    df_ids, match_ids_unique = load_match_ids(data_path)
    
    # Team statistics
    team_stats = aggregate_team_stats(df_overview, match_ids_unique)
    team_stats = calculate_historical_stats(team_stats)
    
    # Match results
    df_scores = load_match_results(data_path, match_ids_unique)
    
    # Merge statistics with matches
    matches = merge_stats_with_matches(df_scores, team_stats)
    
    # Add advanced features
    matches = add_recent_winrates(matches, df_scores)
    
    df_maps, match_first_maps = load_map_data(data_path, df_ids)
    matches = add_map_winrates(matches, df_maps, match_first_maps)
    
    matches = add_streaks(matches, df_scores)
    matches = add_head_to_head(matches, df_scores)
    matches = add_agent_diversity(matches, df_overview, match_ids_unique)
    matches = add_tournament_context(matches)
    
    # Feature engineering
    matches = create_comparative_features(matches)
    matches, map_cols, year_cols = add_categorical_features(matches)
    
    # Final preparation
    df_final, feature_cols = prepare_final_dataset(matches, map_cols, year_cols)
    df_final = balance_dataset(df_final, feature_cols)
    
    # Save and summarize
    output_ml = save_datasets(df_final, feature_cols)
    print_summary(df_final, feature_cols, output_ml)


if __name__ == "__main__":
    main()
