package data;

import java.util.*;
import domain.Product.Product;
import domain.Product.ProductsList;
import domain.Rack.Rack;
import domain.User.User;

/**
 * DataController class that stores
 * 
 * @author Sergi Metcalf
 */
public class DataController {
  /**
   * Stores for each user its password
   */
  private HashMap<String, String> userData;

  /**
   * Stores for each user an array list with its list names
   */
  private HashMap<String, HashSet<String>> listData;

  /**
   * Stores for each user a list name and its products
   */
  private HashMap<String, HashMap<String, HashSet<String>>> listProductData;

  /**
   * Stores for each user a hashmap with its list name and a hashmap with the
   * product name and its similarities
   */
  private HashMap<String, HashMap<String, HashMap<String, HashMap<String, Integer>>>> productData;

  /**
   * Stores the last calculated rack matrix
   */
  private String[][] rackMatrix;
  /**
   * Stores the user for the last calculated rack
   */
  private String rackUser;
  /**
   * Stores the list name for the last calculated rack
   */
  private String rackList;

  /**
   * Constructor for the DataController class.
   */
  public DataController() {
    userData = new HashMap<String, String>();
    listData = new HashMap<String, HashSet<String>>();
    listProductData = new HashMap<String, HashMap<String, HashSet<String>>>();
    productData = new HashMap<String, HashMap<String, HashMap<String, HashMap<String, Integer>>>>();
    rackMatrix = new String[0][0];
    rackUser = "";
    rackList = "";
  }

  // METHODS FOR USER DATA

  /**
   * Adds a user to the data Stub
   * 
   * @param username Username of the user to be added
   * @param password Password of the user to be added
   */
  public void addUser(String username, String password) {
    userData.put(username, password);
  }

  /**
   * Gets a user from the data Stub
   * 
   * @param username Username of the user to be retrieved
   * @return User instance with the username and password of the user or null if
   *         it does not exist
   */
  public User getUser(String username) {
    if (userData.containsKey(username)) {
      return new User(username, userData.get(username));
    }
    return null;
  }

  /**
   * Checks if a user exists in the data Stub
   * 
   * @param username Username of the user to check if it exists
   * @return True if the user exists, false otherwise
   */
  public boolean checkUserByUsername(String username) {
    return userData.containsKey(username);
  }

  // METHODS FOR LIST DATA

  /**
   * Adds a list to the data Stub
   * 
   * @param username Username of the user to add the list to
   * @param listName Name of the list to be added
   */
  public void addList(String username, String listName) {
    if (listData.containsKey(username)) {
      listData.get(username).add(listName);
    } else {
      listData.put(username, new HashSet<String>());
      listData.get(username).add(listName);
    }

    if (!listProductData.containsKey(username)) {
      listProductData.put(username, new HashMap<String, HashSet<String>>());
    }
    if (!listProductData.get(username).containsKey(listName)) {
      listProductData.get(username).put(listName, new HashSet<String>());
    }
  }

  /**
   * Gets a list of list names for username from the data Stub or null if it has
   * no lists
   * 
   * @param username Username of the user to get the list from
   * @return List of list names for the user or null if it has no lists
   */
  public HashSet<String> getLists(String username) {
    if (listData.containsKey(username)) {
      return listData.get(username);
    }
    return new HashSet<String>();
  }

  /**
   * Checks if a list exists for a user
   * 
   * @param username Username of the user to check the list from
   * @param listName Name of the list to check if it exists
   * @return True if the list exists, false otherwise
   */
  public boolean checkListByName(String username, String listName) {
    if (listData.containsKey(username)) {
      return listData.get(username).contains(listName);
    }
    return false;
  }

  // METHODS FOR PRODUCT LIST DATA

  /**
   * Gets an instance of productList for username and listName from the data Stub
   * or null if it does not exist
   * 
   * @param username Username of the user to get the list from
   * @param listName Name of the list to get the products from
   * @return Instance of productList for username and listName from the data Stub
   *         or null if it does not exist
   */
  public ProductsList getList(String username, String listName) {
    if (listProductData.containsKey(username)) {
      if (listProductData.get(username).containsKey(listName)) {
        ProductsList list = new ProductsList(listName, username);
        for (String product : listProductData.get(username).get(listName)) {
          list.addProduct(getProduct(product, username, listName));
        }
        return list;
      }
    }
    return null;
  } 

  /**
   * Stores a list of products from a productList instance to the data Stub
   * 
   * @param productList Instance of productList to store in the data Stub
   */

  public void storeList(ProductsList productList) {
    String username = productList.getUser();
    if (!listProductData.containsKey(username)) {
      listProductData.put(username, new HashMap<String, HashSet<String>>());
    }
    if (!productData.containsKey(username)) {
      productData.put(username, new HashMap<String, HashMap<String, HashMap<String, Integer>>>());
      productData.get(username).put(productList.getName(), new HashMap<String, HashMap<String, Integer>>());
    }
    else if (!productData.get(username).containsKey(productList.getName())) {
      productData.get(username).put(productList.getName(), new HashMap<String, HashMap<String, Integer>>());
    }

    listProductData.get(username).put(productList.getName(), new HashSet<String>());
    for (Product product : productList.getProducts()) {
      listProductData.get(username).get(productList.getName()).add(product.getName());
      if (!productData.get(username).get(productList.getName()).containsKey(product.getName())) {
        productData.get(username).get(productList.getName()).put(product.getName(), new HashMap<String, Integer>());
      }
      for (String product_name : product.getSimilarities().keySet()) {
        productData.get(username).get(productList.getName()).get(product.getName()).put(product_name,
            product.getSimilarities().get(product_name));
      }
    }
  }

  // METHODS FOR PRODUCT DATA

  /**
   * Checks if a product exists in the data Stub
   * 
   * @param productName Name of the product to check if it exists
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   * @return True if the product exists, false otherwise
   */
  public boolean checkProductByName(String productName, String username, String listName) {
    if (productData.containsKey(username)) {
      if (productData.get(username).containsKey(listName)) {
        return productData.get(username).get(listName).containsKey(productName);
      }
    }
    return false;
  }

  /**
   * Gets a product instance by identifier from the data Stub or null if it does
   * not exist
   * 
   * @param productName Name of the product to get from the data Stub
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product *
   * @return Product instance from the data Stub or null if it does not exist
   */
  public Product getProduct(String productName, String username, String listName) {
    if (productData.containsKey(username)) {
      if (productData.get(username).containsKey(listName)) {
        if (productData.get(username).get(listName).containsKey(productName)) {
          Product product = new Product(productName, listName, username);
          for (String product_name : productData.get(username).get(listName).get(productName).keySet()) {
            product.addSimilarity(product_name,
                productData.get(username).get(listName).get(productName).get(product_name));
          }
          return product;
        }
      }
    }
    return null;
  }

  /**
   * Stores a product instance to the data Stub
   * 
   * @param product Instance of product to store in the data Stub
   */
  public void storeProduct(Product product) {
    if (productData.containsKey(product.getUser())) {
      if (productData.get(product.getUser()).containsKey(product.getListName())) {
        productData.get(product.getUser()).get(product.getListName()).put(product.getName(),
            new HashMap<String, Integer>());
        for (String product_name : product.getSimilarities().keySet()) {
          productData.get(product.getUser()).get(product.getListName()).get(product.getName()).put(product_name,
              product.getSimilarities().get(product_name));
        }
      } else {
        productData.get(product.getUser()).put(product.getListName(), new HashMap<String, HashMap<String, Integer>>());
        productData.get(product.getUser()).get(product.getListName()).put(product.getName(),
            new HashMap<String, Integer>());
        for (String product_name : product.getSimilarities().keySet()) {
          productData.get(product.getUser()).get(product.getListName()).get(product.getName()).put(product_name,
              product.getSimilarities().get(product_name));
        }
      }
    } else {
      productData.put(product.getUser(), new HashMap<String, HashMap<String, HashMap<String, Integer>>>());
      productData.get(product.getUser()).put(product.getListName(), new HashMap<String, HashMap<String, Integer>>());
      productData.get(product.getUser()).get(product.getListName()).put(product.getName(),
          new HashMap<String, Integer>());
      for (String product_name : product.getSimilarities().keySet()) {
        productData.get(product.getUser()).get(product.getListName()).get(product.getName()).put(product_name,
            product.getSimilarities().get(product_name));
      }
    }
  }

  // METHODS FOR REMOVING DATA

  /**
   * Removes a list from the data Stub
   * 
   * @param username Username of the user to remove the list from
   * @param listName Name of the list to remove
   */
  public void removeList(String username, String listName) {
    if (listData.containsKey(username)) {
      listData.get(username).remove(listName);
    }
    if (listProductData.containsKey(username)) {
      listProductData.get(username).remove(listName);
    }
    if (productData.containsKey(username)) {
      productData.get(username).remove(listName);
    }
  }

  /**
   * Removes a product from the data Stub
   * 
   * @param productName Name of the product to remove
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   */
  public void removeProduct(String productName, String username, String listName) {
    if (productData.containsKey(username)) {
      if (productData.get(username).containsKey(listName)) {
        productData.get(username).get(listName).remove(productName);
      }
    }
    if (listProductData.containsKey(username)) {
      if (listProductData.get(username).containsKey(listName)) {
        listProductData.get(username).get(listName).remove(productName);
      }
    }
  }

  // METHODS FOR STORED RACK

  /**
   * Gets the last saved rack matrix from the data Stub
   * 
   * @return The last saved rack matrix
   */
  public String[][] getLastSavedRackMatrix() {
    return rackMatrix;
  }

  /**
   * Gets the user for the last saved rack
   * 
   * @return The user for the last saved rack
   */
  public String getLastSavedRackUser() {
    return rackUser;
  }

  /**
   * Gets the list name for the last saved rack
   * 
   * @return The list name for the last saved rack
   */
  public String getLastSavedRackList() {
    return rackList;
  }

  /**
   * Stores a rack matrix to the data Stub
   * 
   * @param rack Instance of the rack to store
   */
  public void storeRack(Rack rack) {
    rackMatrix = rack.getRackMatrix();
    rackUser = rack.getUser();
    rackList = rack.getListName();
  }

  /**
   * Change the stored rack product list name
   * 
   * @param listName New list name for the stored rack
   */
  public void changeRackListName(String listName) {
    rackList = listName;
  }

  /**
   * Removes the stored rack
   */
  public void invalidateStoredRack() {
    rackMatrix = new String[0][0];
    rackUser = "";
    rackList = "";
  }
}
