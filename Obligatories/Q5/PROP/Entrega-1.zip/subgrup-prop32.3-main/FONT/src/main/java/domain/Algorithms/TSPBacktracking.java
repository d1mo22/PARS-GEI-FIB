package domain.Algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * Implements the backtracking algorithm for the Traveling Salesman Problem (TSP).
 * @author Marc Escribano
 */
public class TSPBacktracking {

    /**
     * The maximum cost calculated.
     */
    private int maxCost;
    /**
     * The path with the maximum cost calculated.
     */
    private List<Integer> maxPath;
    /**
     * The minimum cost calculated.
     */
    private int minCost;
    /**
     * The path with the minimum cost calculated.
     */
    private List<Integer> minPath;

    /**
     * Constructor for the TSPBacktracking class.
     */
    public TSPBacktracking() {
        this.maxCost = Integer.MIN_VALUE;
        this.maxPath = new ArrayList<>();
        this.minCost = Integer.MAX_VALUE;
        this.minPath = new ArrayList<>();
    }

    /** Function to find the minimum weight TSP path
     * @param graph: the graph to be traversed
     * @param visited: the array of visited nodes
     * @param currPos: the current position
     * @param n: the number of nodes
     * @param count: the number of nodes visited
     * @param cost: the cost of the path
     * @param currentPath: the current path
     * @param maxLength: the maximum length of the path
     * @param result: the result
     */
    private void tspUtilWithLength(int[][] graph, boolean[] visited, int currPos, int n, int count, int cost, List<Integer> currentPath, int maxLength, List<Integer> result) {
        int maxCost = result.get(0);
        List<Integer> bestPath;

        if (maxLength == 1) {
            return;
        }

        if (count == maxLength && graph[currPos][0] > 0) {
            if (cost + graph[currPos][0] > maxCost) {
                maxCost = cost + graph[currPos][0];
                bestPath = new ArrayList<>(currentPath);
                bestPath.add(0);
                result.set(0, maxCost);
                result.clear();
                result.add(maxCost);
                result.addAll(bestPath);
            }
            return;
        }

        for (int i = 0; i < n; i++) {
            if (!visited[i] && graph[currPos][i] > 0) {
                visited[i] = true;
                currentPath.add(i);
                tspUtilWithLength(graph, visited, i, n, count + 1, cost + graph[currPos][i], currentPath, maxLength, result);
                currentPath.remove(currentPath.size() - 1);
                visited[i] = false;
            }
        }
    }

    /** Function to find the maximum weight TSP path
     * @param graph the graph to be traversed
     * @param maxLength the maximum length of the path
     * @return the path with the maximum cost
     */
    public List<Integer> tspWithLengthMax(int[][] graph, int maxLength) {
        if (maxLength == 1) {
            this.maxCost = 0;
            this.maxPath = new ArrayList<>(Collections.nCopies(2, 0));
            return this.maxPath;
        }
        int n = graph.length;
        boolean[] visited = new boolean[n];
        List<Integer> currentPath = new ArrayList<>();
        visited[0] = true;
        currentPath.add(0);
        List<Integer> result = new ArrayList<>();
        result.add(Integer.MIN_VALUE);
        tspUtilWithLength(graph, visited, 0, n, 1, 0, currentPath, Math.min(maxLength, graph.length), result);
        this.maxCost = result.get(0);
        this.maxPath = new ArrayList<>(result.subList(1, result.size()));
        return this.maxPath;
    }

    /** Function to find the minimum weight TSP path
     * @param graph: the graph to be traversed
     * @param visited: the array of visited nodes
     * @param currPos: the current position
     * @param n: the number of nodes
     * @param count: the number of nodes visited
     * @param cost: the cost of the path
     * @param currentPath: the current path
     * @param maxLength: the maximum length of the path
     * @param result: the result
     */
    private void tspUtilWithLengthMin(int[][] graph, boolean[] visited, int currPos, int n, int count, int cost, List<Integer> currentPath, int maxLength, List<Integer> result) {
        int minCost = result.get(0);
        List<Integer> bestPath;

        if (maxLength == 1) {
            return;
        }

        if (count == maxLength && graph[currPos][0] > 0) {
            if (cost + graph[currPos][0] < minCost) {
                minCost = cost + graph[currPos][0];
                bestPath = new ArrayList<>(currentPath);
                bestPath.add(0);
                result.set(0, minCost);
                result.clear();
                result.add(minCost);
                result.addAll(bestPath);
            }
            return;
        }

        for (int i = 0; i < n; i++) {
            if (!visited[i] && graph[currPos][i] > 0) {
                visited[i] = true;
                currentPath.add(i);
                tspUtilWithLengthMin(graph, visited, i, n, count + 1, cost + graph[currPos][i], currentPath, maxLength, result);
                currentPath.remove(currentPath.size() - 1);
                visited[i] = false;
            }
        }
    }

    /**  Function to find the minimum weight TSP path
     * @param graph: the graph to be traversed
     * @param maxLength: the maximum length of the path
     * @return the path with the minimum cost
     */
    public List<Integer> tspWithLengthMin(int[][] graph, int maxLength) {
        if (maxLength == 1) {
            this.minCost = 0;
            this.minPath = new ArrayList<>(Collections.nCopies(2, 0));
            return this.minPath;
        }
        int n = graph.length;
        boolean[] visited = new boolean[n];
        List<Integer> currentPath = new ArrayList<>();
        visited[0] = true;
        currentPath.add(0);
        List<Integer> result = new ArrayList<>();
        result.add(Integer.MAX_VALUE);
        tspUtilWithLengthMin(graph, visited, 0, n, 1, 0, currentPath, Math.min(maxLength, graph.length), result);
        this.minCost = result.get(0);
        this.minPath = new ArrayList<>(result.subList(1, result.size()));
        return this.minPath;
    }

    /**
     * This function returns the maximum cost calculated.
     * @return The maximum cost.
     */
    public int getMaxCost() {
        return maxCost;
    }

    /**
     * This function returns the path with the maximum cost calculated.
     * @return A list of vertices representing the path with the maximum cost.
     */
    public List<Integer> getMaxPath() {
        return maxPath;
    }

    /**
     * This function returns the minimum cost calculated.
     * @return The minimum cost.
     */
    public int getMinCost() {
        return minCost;
    }

    /**
     * This function returns the path with the minimum cost calculated.
     * @return A list of vertices representing the path with the minimum cost.
     */
    public List<Integer> getMinPath() {
        return minPath;
    }
}