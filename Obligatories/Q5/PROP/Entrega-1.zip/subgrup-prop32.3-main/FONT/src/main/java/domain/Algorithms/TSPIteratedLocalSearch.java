package domain.Algorithms;

import java.util.ArrayList;
import java.util.List;

//Possible 4to algoritmo

/**
 * Implements the iterated local search algorithm for the Traveling Salesman Problem (TSP).
 * 
 * @author David Morais
 */
public class TSPIteratedLocalSearch {
  /**
   * The Hill Climbing algorithm to be used.
   */
  private final TSPHillClimbing hillClimbing;
  /**
   * The maximum number of iterations.
   */
  private final int maxIterations;
  /**
   * The perturbation rate.
   */
  private final double perturbationRate;
    /**
     * The best solution found.
     */
  private List<Integer> bestSolution;
    /**
     * The cost of the best solution found.
     */
  private int bestCost;

  /**
   * Constructor for the TSPIteratedLocalSearch class.
   *
   * @param hillClimbing The Hill Climbing algorithm to be used
   */
  public TSPIteratedLocalSearch(TSPHillClimbing hillClimbing) {
    this.hillClimbing = hillClimbing;
    this.maxIterations = 100;
    this.perturbationRate = 0.2;
    this.bestSolution = new ArrayList<>();
    this.bestCost = Integer.MAX_VALUE;
  }

  /**
   * Solves the TSP problem with the Iterated Local Search algorithm.
   */
  public void solveMin() {
    // Execute Hill Climbing initially
    hillClimbing.solveMin();
    bestSolution = new ArrayList<>(hillClimbing.getSolution());
    bestCost = hillClimbing.getCost();

    for (int i = 1; i < maxIterations; i++) {
      // Perturb the current best solution
      List<Integer> perturbedSolution = perturb(bestSolution);

      // Set the perturbed solution as initial in Hill Climbing
      hillClimbing.setInitialSolution(perturbedSolution);

      // Execute Hill Climbing
      hillClimbing.solveMin();
      List<Integer> currentSolution = hillClimbing.getSolution();
      int currentCost = hillClimbing.getCost();

      // Check if the new solution is better
      if (currentCost < bestCost) {
        bestSolution = new ArrayList<>(currentSolution);
        bestCost = currentCost;
      }
    }
  }

  /**
   * Solves the TSP problem with the Iterated Local Search algorithm.
   */
  public void solveMax() {
    // Execute Hill Climbing initially
    hillClimbing.solveMax();
    bestSolution = new ArrayList<>(hillClimbing.getSolution());
    bestCost = hillClimbing.getCost();

    for (int i = 1; i < maxIterations; i++) {
      // Perturb the current best solution
      List<Integer> perturbedSolution = perturb(bestSolution);

      // Set the perturbed solution as initial in Hill Climbing
      hillClimbing.setInitialSolution(perturbedSolution);

      // Execute Hill Climbing
      hillClimbing.solveMax();
      List<Integer> currentSolution = hillClimbing.getSolution();
      int currentCost = hillClimbing.getCost();

      // Check if the new solution is better
      if (currentCost > bestCost) {
        bestSolution = new ArrayList<>(currentSolution);
        bestCost = currentCost;
      }
    }
  }

  /**
   * Perturbs a solution by swapping two random elements.
   *
   * @param solution The solution to be perturbed
   * @return The perturbed solution
   */
  private List<Integer> perturb(List<Integer> solution) {
    List<Integer> perturbed = new ArrayList<>(solution);
    int size = perturbed.size();
    int numPerturbations = (int) (size * perturbationRate);

    for (int i = 0; i < numPerturbations; i++) {
      int index1 = (int) (Math.random() * size);
      int index2 = (int) (Math.random() * size);
      // Swap two elements
      int temp = perturbed.get(index1);
      perturbed.set(index1, perturbed.get(index2));
      perturbed.set(index2, temp);
    }

    return perturbed;
  }

  /**
   * Getter for the best solution.
   *
   * @return The best solution
   */
  public List<Integer> getBestSolution() {
    return bestSolution;
  }

  /**
   * Getter for the best cost.
   *
   * @return The best cost
   */
  public int getBestCost() {
    return bestCost;
  }
}
