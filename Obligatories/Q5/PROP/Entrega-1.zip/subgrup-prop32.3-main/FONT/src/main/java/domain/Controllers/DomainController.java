package domain.Controllers;

import domain.User.User;
import domain.Product.Product;
import domain.Product.ProductsList;
import domain.Rack.Rack;
import data.DataController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 * Domain controller class that manages the interaction between the UI and the
 * data.
 */
public class DomainController {

  /**
   * The instance of the domain controller.
   */
  private static DomainController instance = null;
  /**
   * The user controller.
   */
  private final UserController userController;
  /**
   * The rack controller.
   */
  private final RackController rackController;
  /**
   * The data controller.
   */
  private final DataController dataController;
  /**
   * The product controller.
   */
  private final ProductController productController;
  /**
   * The products list controller.
   */
  private final ProductsListController productsListController;
  /**
   * The currently authenticated user.
   */
  private String currentUser;
  /**
   * The active list for the current user.
   */
  private String activeList;

  /**
   * Constructor for the domain controller.
   */
  public DomainController() {
    this.dataController = new DataController();
    this.userController = new UserController();
    this.rackController = new RackController();
    this.productController = new ProductController();
    this.productsListController = new ProductsListController();
  }

  /**
   * Testing only constructor.
   * 
   * @param dataController         The data controller.
   * @param userController         The user controller.
   * @param rackController         The rack controller.
   * @param productController      The product controller.
   * @param productsListController The products list controller.
   */
  public DomainController(DataController dataController, UserController userController, RackController rackController,
      ProductController productController, ProductsListController productsListController) {
    this.dataController = dataController;
    this.userController = userController;
    this.rackController = rackController;
    this.productController = productController;
    this.productsListController = productsListController;
  }

  /**
   * Gets the instance of the domain controller.
   * 
   * @return The domain controller instance.
   */
  public static DomainController getInstance() {
    if (instance == null) {
      instance = new DomainController();
    }
    return instance;
  }

  // PRODUCTS LIST METHODS

  /**
   * Gets all product lists for the current user.
   * 
   * @return A list of product lists.
   * @throws IllegalArgumentException if there is no authenticated user is already
   *                                  authenticated.
   */
  public HashSet<String> getActiveUserProductLists() {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    }
    return dataController.getLists(currentUser);
  }

  /**
   * Exports a list from the current user to a file.
   *
   * @param listName The name of the list.
   * @param path     The path to the file.
   * @throws IllegalArgumentException if the list does not exist or there is no
   *                                  authenticated user.
   */
  public void exportList(String listName, String path) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    }
    ProductsList list = dataController.getList(currentUser, listName);
    if (list == null) {
      throw new IllegalArgumentException("The list does not exist");
    }
    productsListController.setProductsList(list);

    productsListController.export(path);
  }

  /**
   * Imports a list to the current user from a file.
   * @param listName The name of the list.
   * @param path The path to the file.
   */
  public void importList(String listName, String path) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    }

    productsListController.createProductsList(listName, currentUser);
    dataController.addList(currentUser, listName);

    productsListController.importProductsList(path);
    dataController.storeList(productsListController.getProductsList());
  }

  /**
   * Sets the active list for the current user.
   * 
   * @param listName The name of the list.
   * 
   * @throws IllegalArgumentException if the list does not exist or there is no
   *                                  authenticated user.
   */
  public void setActiveList(String listName) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    } else if (!dataController.checkListByName(currentUser, listName)) {
      throw new IllegalArgumentException("The list does not exist");
    }
    this.activeList = listName;
  }

  /**
   * Gets the active list for the current user.
   * 
   * @return The name of the active list.
   * 
   * @throws IllegalArgumentException if there is no authenticated user.
   * @throws IllegalArgumentException if there is no active list.
   */
  public String getActiveList() {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    } else if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }
    return activeList;
  }

  /**
   * Checks if there is an active list for the current user.
   * 
   * @return True if there is an active list, otherwise false.
   */
  public boolean hasActiveList() {
    return activeList != null;
  }

  /**
   * Adds a product list to the current user.
   * 
   * @param listName The name of the list.
   * @throws IllegalArgumentException if the list already exists
   *                                  or there is no authenticated user.
   */
  public void addProductList(String listName) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    } else if (dataController.checkListByName(currentUser, listName)) {
      throw new IllegalArgumentException("The list already exists");
    }
    dataController.addList(currentUser, listName);
  }

  /**
   * Removes a list from the active user.
   * 
   * @param listName The name of the list.
   * @throws IllegalArgumentException if the list does not exist
   *                                  or there is no authenticated user.
   */
  public void removeProductList(String listName) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    } else if (!dataController.checkListByName(currentUser, listName)) {
      throw new IllegalArgumentException("The list does not exist");
    }
    if (activeList != null && activeList.equals(listName)) {
      activeList = null;
    }
    dataController.removeList(currentUser, listName);

    if (dataController.getLastSavedRackList().equals(listName)) {
      dataController.invalidateStoredRack();
    }
  }

  /**
   * Modify a list name from the active user.
   * 
   * @param oldListName The name of the list to be modified.
   * @param newListName The new name of the list.
   * @throws IllegalArgumentException if the old list does not exist
   *                                  or there is no authenticated user.
   */
  public void modifyProductListName(String oldListName, String newListName) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    } else if (!dataController.checkListByName(currentUser, oldListName)) {
      throw new IllegalArgumentException("The list does not exist");
    } else if (dataController.checkListByName(currentUser, newListName)) {
      throw new IllegalArgumentException("A list with that name already exists");
    }

    productsListController.setProductsList(dataController.getList(currentUser, oldListName));
    productsListController.changeName(newListName);

    dataController.addList(currentUser, newListName);
    dataController.storeList(productsListController.getProductsList());

    for (Product product : productsListController.getProducts()) {
      productController.setProduct(product);
      productController.changeListName(newListName);
      dataController.storeProduct(productController.getProduct());
    }

    dataController.removeList(currentUser, oldListName);

    if (dataController.getLastSavedRackList().equals(oldListName)) {
      dataController.changeRackListName(newListName);
    }
    activeList = newListName;
  }

  // RACK METHODS

  /**
   * Checks if the active user has a calculated rack.
   * 
   * @param username The username of the user.
   * @return True if the user has a rack, otherwise false.
   */
  public boolean checkUserHasSavedRack(String username) {
    String savedUser = dataController.getLastSavedRackUser();
    return savedUser.equals(username);
  }

  /**
   * Prints the active rack.
   *
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void printRack() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    rackController.printRack();
  }

  /**
   * Gets the current stored rack and sets its list to active.
   * 
   * @return The saved rack instance.
   * @throws IllegalArgumentException if the saved rack does not match the active
   *                                  user.
   */
  public Rack getSavedRack() {
    String savedUser = dataController.getLastSavedRackUser();
    if (savedUser == null || !savedUser.equals(currentUser)) {
      throw new IllegalArgumentException("The saved rack does not match the active user");
    }

    String[][] rackMatrix = dataController.getLastSavedRackMatrix();
    ProductsList list = dataController.getList(dataController.getLastSavedRackUser(),
        dataController.getLastSavedRackList());
    rackController.createRack(list, rackMatrix.length, rackMatrix[0].length);
    rackController.setRackMatrix(dataController.getLastSavedRackMatrix());
    return rackController.getActiveRack();
  }

  /**
   * Gets the current active rack matrix.
   * 
   * @return The rack matrix.
   * @throws IllegalArgumentException if there is no active rack.
   */
  public String[][] getRackMatrix() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    return rackController.getRackMatrix();
  }

  /**
   * Creates a rack for the current user and active list.
   * 
   * @param rows    The number of rows.
   * @param columns The number of columns.
   * @throws IllegalArgumentException if there is no authenticated user or the
   *                                  list is not set.
   */
  public void createRack(int rows, int columns) {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    } else if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }
    else if (rows <= 0 || columns <= 0) {
      throw new IllegalArgumentException("Rows and columns must be greater than 0");
    }
    ProductsList products = dataController.getList(currentUser, activeList);

    rackController.createRack(products, rows, columns);
    dataController.storeRack(rackController.getActiveRack());
  }

  /**
   * Calculates the rack matrix with hill climbing algorithm and stores it.
   * 
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void solveHillClimbing() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    rackController.solveTSPHillClimbing();
    dataController.storeRack(rackController.getActiveRack());
  }

  /**
   * Calculates the rack matrix with hill climbing algorithm and stores it.
   * 
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void solveAproximation() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    rackController.solveTSPApproximation();
    dataController.storeRack(rackController.getActiveRack());
  }

  /**
   * Calculates the rack matrix with hill climbing algorithm and stores it.
   * 
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void solveBacktracking() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    rackController.solveTSPBacktracking();
    dataController.storeRack(rackController.getActiveRack());
  }

  /**
   * Calculates the rack matrix with iterated local search algorithm and stores it.
   * 
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void solveIteratedLocalSearch() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    rackController.solveTSPIteratedLocalSearch();
    dataController.storeRack(rackController.getActiveRack());
  }

  /**
   * Sets the rows and columns for the rack.
   * 
   * @param rows    The number of rows.
   * @param columns The number of columns.
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void setRowsAndColumns(int rows, int columns) {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    else if (rows <= 0 || columns <= 0) {
      throw new IllegalArgumentException("Rows and columns must be greater than 0");
    }
    rackController.setRowsAndColumns(rows, columns);
  }

  /**
   * Gets the number of rows for the active rack.
   * 
   * @return The number of rows.
   * @throws IllegalArgumentException if there is no active rack.
   */
  public int getRackRows() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    return rackController.getActiveRack().getRows();
  }

  /**
   * Gets the number of columns for the active rack.
   * 
   * @return The number of columns.
   * @throws IllegalArgumentException if there is no active rack.
   */
  public int getRackColumns() {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    return rackController.getActiveRack().getColumns();
  }

  /** Swaps 2 products in the rack.
   *
   * @param row1 The row of the first product.
   * @param col1 The column of the first product.
   * @param row2 The row of the second product.
   * @param col2 The column of the second product.
   * @throws IllegalArgumentException if there is no active rack.
   */
  public void moveProduct(int row1, int col1, int row2, int col2) {
    if (rackController.rackNotSet()) {
      throw new IllegalArgumentException("There is no active rack");
    }
    rackController.moveProduct(row1, col1, row2, col2);
    dataController.storeRack(rackController.getActiveRack());
  }

  // USER METHODS

  /**
   * Creates a new user if the username does not exist.
   *
   * @param username Username.
   * @param password Password.
   * @return The created user.
   * @throws IllegalArgumentException if the username already exists or if the
   *                                  fields are invalid.
   */
  public User createUser(String username, String password) {
    if (dataController.checkUserByUsername(username)) {
      throw new IllegalArgumentException("The username already exists");
    }
    if (username == null || password == null) {
      throw new IllegalArgumentException("Username and password cannot be null");
    } else if (username.isEmpty() || password.isEmpty()) {
      throw new IllegalArgumentException("Username and password cannot be empty");
    }

    User newUser = userController.createUser(username, password);
    dataController.addUser(username, password);
    return newUser;
  }

  /**
   * Logs in a user by validating the credentials.
   *
   * @param username Username.
   * @param password Password.
   * @return The authenticated user.
   * @throws IllegalArgumentException if the credentials are invalid or if a user
   *                                  is already authenticated.
   */
  public User loginUser(String username, String password) {
    if (currentUser != null) {
      throw new IllegalArgumentException("A user is already authenticated");
    }

    if (!dataController.checkUserByUsername(username)) {
      throw new IllegalArgumentException("Invalid username");
    }

    User user = dataController.getUser(username);
    userController.setActiveUser(user);

    if (!userController.verifyPassword(password)) {
      userController.removeActiveUser();
      throw new IllegalArgumentException("Invalid password");
    }
    currentUser = username;
    return user;
  }

  /**
   * Logs out the currently authenticated user.
   *
   * @throws IllegalArgumentException if there is no authenticated user.
   */
  public void logoutUser() {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    }
    currentUser = null;
    userController.removeActiveUser();
  }

  /**
   * Checks if there is a currently authenticated user.
   *
   * @return True if there is an authenticated user, otherwise false.
   */
  public boolean isUserLoggedIn() {
    return currentUser != null;
  }

  /**
   * Gets the currently authenticated user.
   *
   * @return The authenticated user.
   * @throws IllegalArgumentException if there is no authenticated user.
   */
  public User getCurrentUser() {
    if (currentUser == null) {
      throw new IllegalArgumentException("No user is currently authenticated");
    }
    return dataController.getUser(currentUser);
  }

  /**
   * Changes the password of a user.
   * 
   * @param username    Username of the user.
   * @param newPassword New password.
   * @throws IllegalArgumentException if the user does not exist.
   */
  public void changeUserPassword(String username, String newPassword) {
    if (!dataController.checkUserByUsername(username)) {
      throw new IllegalArgumentException("The user does not exist");
    }
    User user = dataController.getUser(username);
    userController.setActiveUser(user);
    userController.changePassword(newPassword);
    dataController.addUser(username, newPassword);
  }

  // PRODUCT METHODS

  /**
   * Gets all products from the active list.
   * 
   * @return A list of products.
   * @throws IllegalArgumentException if there is no active list.
   */
  public List<String> getActiveListProducts() {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }

    ProductsList list = dataController.getList(currentUser, activeList);
    productsListController.setProductsList(list);

    List<String> products = new ArrayList<>();
    for (Product product : productsListController.getProducts()) {
      products.add(product.getName());
    }

    return products;
  }

  /**
   * Gets all similarities for a product in the active list.
   * 
   * @param productName The name of the product.
   * @return A list of similarities.
   * @throws IllegalArgumentException if there is no active list ot the product does not exist.
   */
  public HashMap<String, Integer> getProductSimilarities(String productName) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }

    Product product = dataController.getProduct(productName, currentUser, activeList);
    if (product == null) {
      throw new IllegalArgumentException("The product does not exist");
    }

    productController.setProduct(product);
    return productController.getSimilarities();
  }

  /**
   * Adds a product to the active list.
   * 
   * @param productName The name of the product.
   * @return True if the product was added, otherwise false.
   * @throws IllegalArgumentException if there is no active list.
   *                                  or the product name is invalid.
   */
  public boolean addProduct(String productName) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }

    if (productName == null || productName.isEmpty()) {
      throw new IllegalArgumentException("Product name cannot be null or empty");
    }

    ProductsList list = dataController.getList(currentUser, activeList);

    if (dataController.checkProductByName(productName, currentUser, activeList)) {
      return false;
    }

    Product product = productController.createProduct(productName, activeList, currentUser);
    list.addProduct(product);
    dataController.storeProduct(product);
    dataController.storeList(list);

    if (dataController.getLastSavedRackList().equals(activeList)) {
      dataController.invalidateStoredRack();
    }

    return true;
  }

  /**
   * Removes a product from the active list.
   * 
   * @param productName The name of the product.
   * @return True if the product was removed, otherwise false.
   * @throws IllegalArgumentException if there is no active list.
   */
  public boolean removeProduct(String productName) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }

    ProductsList list = dataController.getList(currentUser, activeList);

    if (!dataController.checkProductByName(productName, currentUser, activeList)) {
      return false;
    }

    Product product = dataController.getProduct(productName, currentUser, activeList);
    productController.setProduct(product);
    HashMap<String, Integer> similarities = productController.getSimilarities();
    for (String similarProduct : similarities.keySet()) {
      Product similar = dataController.getProduct(similarProduct, currentUser, activeList);
      productController.setProduct(similar);
      productController.removeSimilarity(productName);
      dataController.storeProduct(productController.getProduct());
    }

    list.removeProduct(productName);
    dataController.removeProduct(productName, currentUser, activeList);
    dataController.storeList(list);

    if (dataController.getLastSavedRackList().equals(activeList)) {
      dataController.invalidateStoredRack();
    }

    return true;
  }

  // PRODUCT SIMILARITY METHODS

  /**
   * Adds a similarity between two products in the active list.
   * 
   * @param productName        The name of the first product.
   * @param similarProductName The name of the second product.
   * @param similarity         The similarity value.
   * @throws IllegalArgumentException if there is no active list, the products
   *                                  do not exist or if the products are the same.
   */
  public void addProductSimilarity(String productName, String similarProductName, int similarity) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }

    if (productName.equals(similarProductName)) {
      throw new IllegalArgumentException("The products cannot be the same");
    }

    Product product = dataController.getProduct(productName, currentUser, activeList);
    if (product == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }
    Product similarProduct = dataController.getProduct(similarProductName, currentUser, activeList);
    if (similarProduct == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }

    productController.setProduct(product);
    productController.addSimilarity(similarProductName, similarity);
    dataController.storeProduct(productController.getProduct());

    
    productController.setProduct(similarProduct);
    productController.addSimilarity(productName, similarity);
    dataController.storeProduct(productController.getProduct());
  }

  /**
   * Removes a similarity between two products in the active list.
   * 
   * @param productName        The name of the first product.
   * @param similarProductName The name of the second product.
   * @throws IllegalArgumentException if there is no active list, the products
   *                                  do not exist or if the products are the same.
   */
  public void removeProductSimilarity(String productName, String similarProductName) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }
    if (productName.equals(similarProductName)) {
      throw new IllegalArgumentException("The products cannot be the same");
    }

    Product product = dataController.getProduct(productName, currentUser, activeList);
    if (product == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }
    Product similarProduct = dataController.getProduct(similarProductName, currentUser, activeList);
    if (similarProduct == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }

    productController.setProduct(product);
    productController.removeSimilarity(similarProductName);
    dataController.storeProduct(productController.getProduct());

    productController.setProduct(similarProduct);
    productController.removeSimilarity(productName);
    dataController.storeProduct(productController.getProduct());
  }

  // PRODUCT RESTRICTION METHODS

  /**
   * Adds a restriction between two products in the active list.
   * 
   * @param productName           The name of the first product.
   * @param restrictedProductName The name of the second product.
   * @throws IllegalArgumentException if there is no active list, the products
   *                                  do not exist or both products are the same.
   */
  public void addProductRestriction(String productName, String restrictedProductName) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }
    if (productName.equals(restrictedProductName)) {
      throw new IllegalArgumentException("The products cannot be the same");
    }

    Product product = dataController.getProduct(productName, currentUser, activeList);
    if (product == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }
    Product restrictedProduct = dataController.getProduct(restrictedProductName, currentUser, activeList);
    if (restrictedProduct == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }

    productController.setProduct(product);
    productController.addRestriction(restrictedProductName);
    dataController.storeProduct(productController.getProduct());

    productController.setProduct(restrictedProduct);
    productController.addRestriction(productName);
    dataController.storeProduct(productController.getProduct());
  }

  /**
   * Removes a restriction between two products in the active list.
   * 
   * @param productName           The name of the first product.
   * @param restrictedProductName The name of the second product.
   * @throws IllegalArgumentException if there is no active list, the products
   *                                  do not exist or both products are the same.
   */
  public void removeProductRestriction(String productName, String restrictedProductName) {
    if (activeList == null) {
      throw new IllegalArgumentException("No list is currently set");
    }
    if (productName.equals(restrictedProductName)) {
      throw new IllegalArgumentException("The products cannot be the same");
    }

    Product product = dataController.getProduct(productName, currentUser, activeList);
    if (product == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }
    Product restrictedProduct = dataController.getProduct(restrictedProductName, currentUser, activeList);
    if (restrictedProduct == null) {
      throw new IllegalArgumentException("One of the products does not exist");
    }

    productController.setProduct(product);
    productController.removeRestriction(restrictedProductName);
    dataController.storeProduct(productController.getProduct());

    productController.setProduct(restrictedProduct);
    productController.removeRestriction(productName);
    dataController.storeProduct(productController.getProduct());
  }
}
