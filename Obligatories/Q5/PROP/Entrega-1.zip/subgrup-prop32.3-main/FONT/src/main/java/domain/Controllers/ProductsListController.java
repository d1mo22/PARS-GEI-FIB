package domain.Controllers;

import domain.Product.ProductsList;
import domain.Product.Product;
import java.util.List;

/**
 * Controller for ProductsList.
 * @author Edgar Bosque
 */
public class ProductsListController {
    /**
     * ProductsList object to be used in the controller.
     */
    private ProductsList productsList;

    /**
     * Constructor for ProductsListController.
     */
    public ProductsListController() {
        productsList = null;
    }

    /**
     * Checks if the products list has not been set.
     *
     * @return True if the products list has not been set, false otherwise.
     */
    public boolean productsListNotSet() {
        return productsList == null;
    }

    /**
     * Creates a new instance of ProductsList.
     *
     * @param name Name of the product list.
     * @param user User associated with the product list.
     * @return New ProductsList object.
     * @throws IllegalArgumentException if the parameters are invalid.
     */
    public ProductsList createProductsList(String name, String user) {
        if (name == null || user == null) {
            throw new IllegalArgumentException("Name and user cannot be null");
        } else if (name.isEmpty() || user.isEmpty()) {
            throw new IllegalArgumentException("Name and user cannot be empty");
        }
        productsList = new ProductsList(name, user);
        return productsList;
    }

    /**
     * Adds a product to the products list.
     *
     * @param productName Name of the product to add.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public void addProduct(String productName) {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        productsList.addProduct(new Product(productName, productsList.getName(), productsList.getUser()));
    }

    /**
     * Removes a product from the products list.
     *
     * @param productName Name of the product to remove.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public void removeProduct(String productName) {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        productsList.removeProduct(productName);
    }

    /**
     * Clears all products from the products list.
     *
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public void clearProducts() {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        productsList.clearProducts();
    }

    /**
     * Changes the products list name.
     * 
     * @param name New name for the products list.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public void changeName(String name) {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        productsList.setName(name);
    }

    /**
     * Gets the list of products.
     *
     * @return List of products.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public List<Product> getProducts() {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        return productsList.getProducts();
    }

    /**
     * Gets a product by index.
     *
     * @param index Index of the product.
     * @return Product at the specified index.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public Product getProduct(int index) {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        return productsList.getProductByIndex(index);
    }

    /**
     * Gets the size of the products list.
     *
     * @return Size of the products list.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public int size() {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        return productsList.size();
    }

    /**
     * Exports the products list to a JSON file.
     *
     * @param path Path to the JSON file.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public void export(String path) {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        productsList.export(path);
    }

    /**
     * Imports a products list from a JSON file.
     *
     * @param path Path to the JSON file.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public void importProductsList(String path) {
        if (productsListNotSet()) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        productsList.importList(path);
    }

    /**
     * Returns the products list being used in the controller.
     *
     * @return ProductsList being used.
     * @throws IllegalArgumentException if the products list has not been set.
     */
    public ProductsList getProductsList() {
        if (productsList == null) {
            throw new IllegalArgumentException("ProductsList has not been set");
        }
        return productsList;
    }

    /**
     * Sets the products list to be used in the controller.
     *
     * @param productsList ProductsList to be set.
     */
    public void setProductsList(ProductsList productsList) {
        this.productsList = productsList;
    }
}