package domain.Controllers;

import domain.Product.ProductsList;
import domain.Rack.Rack;

/**
 * Controller for the rack in the system.
 * 
 * @author David Morais
 */
public class RackController {
    /** The rack object to be used in the controller. */
    private Rack rack;

    /**
     * Constructor for the RackController class.
     */
    public RackController() {
        rack = null;
    }

    /**
     * Creates a new rack with the given parameters.
     *
     * @param products The list of products
     * @param rows     The number of rows in the rack
     * @param columns  The number of columns in the rack
     */
    public void createRack(ProductsList products, int rows, int columns) {
        rack = new Rack(products, rows, columns);
    }

    /**
     * Calculates the best product arrangement in the rack with the hill climbing
     * algorithm.
     */
    public void solveTSPHillClimbing() {
        if (rackNotSet()) {
            throw new IllegalStateException("The rack has not been created");
        }
        rack.solveTSPHillClimbing();
    }

    /** Gets the rack matrix with approximation. */
    public void solveTSPApproximation() {
        if (rackNotSet()) {
            throw new IllegalStateException("The rack has not been created");
        }
        rack.solveTSPApproximation();
    }

    /** Gets the rack matrix with backtracking. */
    public void solveTSPBacktracking() {
        if (rackNotSet()) {
            throw new IllegalStateException("The rack has not been created");
        }
        rack.solveTSPBacktracking();
    }

    /**
     * Solves the TSP using the Iterated Local Search algorithm.
     * 
     * @throws IllegalStateException If the rack has not been created.
     */
    public void solveTSPIteratedLocalSearch() {
        if (rackNotSet()) {
            throw new IllegalStateException("The rack has not been created");
        }
        rack.solveTSPIteratedLocalSearch();
    }

    /** Prints the rack matrix. */
    public void printRack() {
        rack.printRack();
    }

    /**
     * Checks if the rack has been set.
     *
     * @return True if the rack has not been set, false otherwise.
     */
    public boolean rackNotSet() {
        return rack == null;
    }

    /**
     * Gets the rack matrix.
     *
     * @return The rack matrix.
     */
    public String[][] getRackMatrix() {
        return rack.getRackMatrix();
    }

    /**
     * Sets the number of rows and columns in the rack.
     *
     * @param rows    The number of rows in the rack.
     * @param columns The number of columns in the rack.
     */
    public void setRowsAndColumns(int rows, int columns) {
        rack.setRows(rows);
        rack.setColumns(columns);
    }

    /**
     * Sets the products in the rack.
     *
     * @param products The list of products to set.
     */
    public void setProducts(ProductsList products) {
        rack.setProducts(products);
    }

    /**
     * Sets a rack instance as the active rack.
     * 
     * @param rack The rack instance to set as active.
     */
    public void setActiveRack(Rack rack) {
        this.rack = rack;
    }

    /**
     * Sets the rack matrix.
     *
     * @param rackMatrix The rack matrix to set.
     * @throws IllegalArgumentException If the rack has not been set.
     */
    public void setRackMatrix(String[][] rackMatrix) {
        if (rackNotSet()) {
            throw new IllegalArgumentException("The rack has not been created");
        }
        rack.setRackMatrix(rackMatrix);
    }

    /**
     * Gets the active rack instance.
     * 
     * @return The active rack instance.
     * @throws IllegalStateException If the rack has not been set.
     */
    public Rack getActiveRack() {
        if (rackNotSet()) {
            throw new IllegalStateException("The rack has not been created");
        }
        return rack;
    }

    /** Swaps two products in the rack.
     * @param row The row of the first product.
     * @param column The column of the first product.
     * @param newRow The row of the second product.
     * @param newColumn The column of the second product.
     * */
    public void moveProduct(int row, int column, int newRow, int newColumn) {
        rack.swapProducts(row, column, newRow, newColumn);
    }
}
