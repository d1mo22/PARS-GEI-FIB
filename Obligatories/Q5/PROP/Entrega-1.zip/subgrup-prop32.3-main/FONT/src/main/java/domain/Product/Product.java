// src/main/java/domain/Product/Product.java
package domain.Product;

import java.util.HashMap;
/**
 * Represents a product in the system.
 * @author Edgar Bosque
 */
public class Product {
    /**
     * Name of the product
     */
    private String name;
    /**
     * Similarities with other products
     */
    private HashMap<String, Integer> similarities;
    /**
     * Name of the list the product belongs to
     */
    private String listName;
    /**
     * Name of the user that owns the product
     */
    private final String user;

    /**
     * Constructor for the product.
     *
     * @param name     Name of the product
     * @param listName Name of the list the product belongs to
     * @param username Name of the user that owns the product
     */
    public Product(String name, String listName, String username) {
        this.name = name;
        this.listName = listName;
        this.user = username;
        this.similarities = new HashMap<>();
    }

    /**
     * Getter for the name
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for the user
     *
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * Getter for the similarities
     *
     * @return the similarities
     */
    public HashMap<String, Integer> getSimilarities() {
        return similarities;
    }

    /**
     * Getter for the list name
     *
     * @return the list name
     */
    public String getListName() {
        return listName;
    }

    /**
     * Setter for the name
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /** Setter for the list name
     *
     * @param listName the list name to set
     */
    public void setListName(String listName) {
        this.listName = listName;
    }

    /**
     * Adds a similarity with another product
     *
     * @param productName Name of the product being compared
     * @param similarity  similarity value
     * @return true if the similarity was added
     */
    public boolean addSimilarity(String productName, int similarity) {
        if (similarities.containsKey(productName ) && similarities.get(productName) > -1) {
            return false;
        }
        similarities.put(productName, similarity);
        return true;
    }

    /**
     * Removes a similarity with another product
     *
     * @param productName product being compared
     * @return true if the similarity was removed
     */
    public boolean removeSimilarity(String productName) {
        if (!similarities.containsKey(productName) || similarities.get(productName) == -1) {
            return false;
        }
        similarities.remove(productName);
        return true;
    }

    /**
     * Returns the similarity with the product productName
     *
     * @param productName Name of the product being compared
     * @return similarity with the product productName
     */
    public int getSimilarity(String productName) {
        return similarities.getOrDefault(productName, 1);
    }

    /**
     * Adds a restriction with another product
     *
     * @param productName Name of the product being compared
     * @return true if the restriction was added
     */
    public boolean addRestriction(String productName) {
        if (similarities.containsKey(productName) && similarities.get(productName) == -1) {
            return false;
        }
        similarities.put(productName, -1);
        return true;
    }

    /**
     * Removes a restriction with another product
     *
     * @param productName product being compared
     * @return true if the restriction was removed
     */
    public boolean removeRestriction(String productName) {
        if (!similarities.containsKey(productName) || similarities.get(productName) != -1) {
            return false;
        }
        similarities.remove(productName);
        return true;
    }

    /**
     * Returns if the product has a restriction with the product productName
     *
     * @param productName Name of the product being compared
     * @return true if the product has a restriction with the product productName
     */
    public boolean hasRestriction(String productName) {
        return similarities.getOrDefault(productName, 0) == -1;
    }

}