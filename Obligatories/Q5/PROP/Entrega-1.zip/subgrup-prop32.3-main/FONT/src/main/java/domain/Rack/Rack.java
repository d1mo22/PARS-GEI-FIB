package domain.Rack;

import java.util.List;

import domain.Algorithms.*;
import domain.Product.*;

/**
 * Represents a rack in the system.
 * 
 * @author David Morais
 */
public class Rack {
  /**
   * Number of columns in the rack
   */
  private int columns;
  /**
   * Number of rows in the rack
   */
  private int rows;
  /**
   * The rack matrix
   */
  private String[][] rackMatrix;
  /**
   * The current cost of the rack
   */
  private int currentCost;
  /**
   * The list of products
   */
  private ProductsList products;

  /**
   * Constructor for the Rack class.
   * 
   * @param products The list of products
   * @param rows     The number of rows in the rack
   * @param columns  The number of columns in the rack
   */
  public Rack(ProductsList products, int rows, int columns) {
    this.rows = rows;
    this.columns = columns;
    this.rackMatrix = initializeRackMatrix();
    this.products = products;
    this.currentCost = 0;
  }

  /**
   * Alternate constructor for the Rack class.
   * 
   * @param rackMatrix The rack matrix
   * @param user       The user of the product list
   * @param listName   The name of the product list
   */
  public Rack(String[][] rackMatrix, String user, String listName) {
    this.products = new ProductsList(listName, user);
    this.rackMatrix = rackMatrix;
    this.rows = rackMatrix.length;
    this.columns = rackMatrix[0].length;
  }

  /**
   * Returns the number of spaces in the rack
   * 
   * @return The number of spaces in the rack
   */
  public int getRackSpaces() {
    return columns * rows;
  }

  /**
   * Returns the rackMatrix
   *
   * @return The rack matrix
   */
  public String[][] getRackMatrix() {
    return rackMatrix;
  }

  /**
   * Returns the number of columns in the rack
   *
   * @return The number of columns in the rack
   */
  public int getColumns() {
    return columns;
  }

  /**
   * Returns the number of rows in the rack
   *
   * @return The number of rows in the rack
   */
  public int getRows() {
    return rows;
  }

  /**
   * Returns the list of products
   *
   * @return The list of products
   */
  public List<Product> getProducts() {
    return products.getProducts();
  }

  /**
   * Getter for the product list user
   * 
   * @return The user of the product list
   */
  public String getUser() {
    return products.getUser();
  }

  /**
   * Getter for the product list name
   * 
   * @return The name of the product list
   */
  public String getListName() {
    return products.getName();
  }

  /**
   * Set the number of columns in the rack
   * 
   * @param columns The number of columns
   */
  public void setColumns(int columns) {
    this.columns = columns;
    this.rackMatrix = initializeRackMatrix();
  }

  /**
   * Set the number of rows in the rack
   * 
   * @param rows The number of rows
   */
  public void setRows(int rows) {
    this.rows = rows;
    this.rackMatrix = initializeRackMatrix();
  }

  /**
   * This function initializes the rack matrix with X's
   * 
   * @return The initialized rack matrix
   */
  private String[][] initializeRackMatrix() {
    String[][] rackMatrix = new String[rows][columns];
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        rackMatrix[i][j] = "X";
      }
    }
    return rackMatrix;
  }

  /**
   * This function generates a distance matrix based on the similarities between
   * products.
   * 
   * @return A 3D array representing the distance matrix.
   */
  private int[][] generateDistanceMatrix() {
    int size = products.size();
    int[][] distanceMatrix = new int[size][size];

    for (int i = 0; i < size; i++) {
      for (int j = 0; j < size; j++) {
        if (i == j) {
          distanceMatrix[i][j] = 0;
        } else {
          Product p1 = products.getProductByIndex(i);
          Product p2 = products.getProductByIndex(j);
          int similarity = p1.getSimilarity(p2.getName());
          distanceMatrix[i][j] = similarity;
        }
      }
    }
    return distanceMatrix;
  }

  /**
   * This function solves the Traveling Salesman Problem (TSP) using the Hill
   * Climbing algorithm.
   * It generates a distance matrix, solves the TSP, and arranges the products in
   * the rack matrix.
   */
  public void solveTSPHillClimbing() {
    int[][] distanceMatrix = generateDistanceMatrix();
    TSPHillClimbing tsp = new TSPHillClimbing(distanceMatrix, columns * rows, false);
    currentCost = tsp.solveMax();

    if (currentCost == Integer.MIN_VALUE) {
      // Handle the case without a solution
      throw new IllegalStateException("No valid solution found.");
      // Optional: throw an exception or keep rackMatrix unchanged
    } else {
      // Update rackMatrix with the found solution
      this.rackMatrix = convertSolutionToRackMatrix(tsp.getSolution());
    }
  }

  /**
   * This function solves the Traveling Salesman Problem (TSP) using the
   * 2-Approximation algorithm.
   * It generates a distance matrix, solves the TSP, and arranges the products in
   * the rack matrix.
   */
  public void solveTSPApproximation() {
    int[][] distanceMatrix = generateDistanceMatrix();
    TSP2Approximation tsp = new TSP2Approximation();
    currentCost = tsp.calculateTSP2ApproximationMax(distanceMatrix, columns * rows);
    List<Integer> solution = tsp.getLastPath();
    if (currentCost == Integer.MIN_VALUE || solution == null || solution.isEmpty()) {
      // Handle the case without a solution
      throw new IllegalStateException("No valid solution found with 2-Approximation.");
    } else {
      // Remove the last element from the solution
      solution = solution.subList(0, solution.size() - 1);
      // Update rackMatrix with the found solution
      this.rackMatrix = convertSolutionToRackMatrix(solution);
    }
  }

  /**
   * This function solves the Traveling Salesman Problem (TSP) using the
   * Backtracking algorithm.
   * It generates a distance matrix, solves the TSP, and arranges the products in
   * the rack matrix.
   */
  public void solveTSPBacktracking() {
    int[][] distanceMatrix = generateDistanceMatrix();
    TSPBacktracking tsp = new TSPBacktracking();
    List<Integer> solution = tsp.tspWithLengthMax(distanceMatrix, rows * columns);
    currentCost = tsp.getMaxCost();
    if (currentCost == Integer.MIN_VALUE || solution == null || solution.isEmpty()) {
      // Handle the case without a solution
      throw new IllegalStateException("No valid solution found with Backtracking.");
    } else {
      // Remove the last element from the solution
      solution = solution.subList(0, solution.size() - 1);
      // Update rackMatrix with the found solution
      this.rackMatrix = convertSolutionToRackMatrix(solution);
    }
  }

  /**
   * This function solves the Traveling Salesman Problem (TSP) using the
   * Iterated Local Search algorithm.
   * It generates a distance matrix, solves the TSP, and arranges the products in
   * the rack matrix.
   */
  public void solveTSPIteratedLocalSearch() {
    int[][] distanceMatrix = generateDistanceMatrix();
    TSPIteratedLocalSearch ils = new TSPIteratedLocalSearch(new TSPHillClimbing(distanceMatrix, columns * rows, true));
    ils.solveMax();
    this.currentCost = ils.getBestCost();
    this.rackMatrix = convertSolutionToRackMatrix(ils.getBestSolution());
  }

  /**
   * This function converts a solution to a rack matrix.
   *
   * @param solution The solution to be converted
   * @return A 3D array representing the rack matrix
   */
  private String[][] convertSolutionToRackMatrix(List<Integer> solution) {
    String[][] matrix = initializeRackMatrix();
    for (int i = 0; i < solution.size(); i++) {
      matrix[i / columns][i % columns] = products.getProductByIndex(solution.get(i)).getName();
    }
    return matrix;
  }

  /**
   * This function prints the rack matrix.
   */
  public void printRack() {
    int cellWidth = 15; // Fixed width for each cell
    StringBuilder horizontalBorder = new StringBuilder("+");
    for (int i = 0; i < columns; i++) {
      horizontalBorder.append("-".repeat(cellWidth)).append("+");
    }
    horizontalBorder.append("\n");

    for (int i = 0; i < rows; i++) {
      System.out.print(horizontalBorder);
      for (int j = 0; j < columns; j++) {
        String item = rackMatrix[i][j];
        if (item == null) {
          item = "X";
        }
        System.out.print("|" + centerString(item, cellWidth));
      }
      System.out.println("|");
    }
    System.out.print(horizontalBorder);
  }

  /**
   * Centers a string within a specific width.
   *
   * @param s     The string to center
   * @param width The width of the cell
   * @return The string centered with spaces
   */
  private String centerString(String s, int width) {
    if (s.length() >= width) {
      return s.substring(0, width);
    } else {
      int padding = (width - s.length()) / 2;
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < padding; i++) {
        sb.append(" ");
      }
      sb.append(s);
      while (sb.length() < width) {
        sb.append(" ");
      }
      return sb.toString();
    }
  }

  /**
   * This function sets the products list and initializes the rack matrix.
   * 
   * @param products The list of products to be set.
   */
  public void setProducts(ProductsList products) {
    this.products = products;
    this.rackMatrix = initializeRackMatrix();
  }

  /**
   * This function sets the rack matrix.
   *
   * @param rackMatrix The rack matrix to be set.
   */
  public void setRackMatrix(String[][] rackMatrix) {
    this.rackMatrix = rackMatrix;
  }

  /**
   * Swaps two products in the rack matrix
   * 
   * @param row1 Row of first product
   * @param col1 Column of first product
   * @param row2 Row of second product
   * @param col2 Column of second product
   */
  public void swapProducts(int row1, int col1, int row2, int col2) {
    // Validate coordinates
    if (row1 < 0 || row1 >= rows || col1 < 0 || col1 >= columns ||
        row2 < 0 || row2 >= rows || col2 < 0 || col2 >= columns) {
      throw new IllegalArgumentException("Invalid coordinates");
    }

    // Swap products
    String temp = rackMatrix[row1][col1];
    rackMatrix[row1][col1] = rackMatrix[row2][col2];
    rackMatrix[row2][col2] = temp;
  }
}
