package domain.User;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * Represents a user in the system.
 *
 * @author David Morais
 */
public class User {
    /**
     * Username.
     */
    private final String username;
    /**
     * Password (stored as encrypted password).
     */
    private String password; // Stored as encrypted password

    /**
     * BCrypt password encoder.
     */
    private static final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /**
     * Constructor for the User class.
     *
     * @param username Username.
     * @param password Password (will be encrypted).
     */
    public User(String username, String password) {
        this.username = username;
        this.password = hashPassword(password);
    }

    /**
     * Encrypts the password using BCrypt.
     *
     * @param rawPassword The raw password.
     * @return The encrypted password.
     */
    private String hashPassword(String rawPassword) {
        return passwordEncoder.encode(rawPassword);
    }

    /**
     * Verifies if the provided password matches the stored one.
     *
     * @param rawPassword The raw password to verify.
     * @return True if it matches, otherwise false.
     */
    public boolean verifyPassword(String rawPassword) {
        return passwordEncoder.matches(rawPassword, this.password);
    }

    /**
     * Setter to update the password.
     *
     * @param newPassword The new raw password.
     */
    public void setPassword(String newPassword) {
        this.password = hashPassword(newPassword);
    }

    /**
     * Getter for the username.
     *
     * @return Username.
     */
    public String getUsername() {
        return username;
    }
    
}
