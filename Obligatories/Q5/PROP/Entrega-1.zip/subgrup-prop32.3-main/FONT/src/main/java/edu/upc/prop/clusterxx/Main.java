package edu.upc.prop.clusterxx;

import domain.Controllers.DomainController;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Main class for the application.
 */
public class Main {
  /**
   * Constructor for the Main class.
   */
  public Main() {
  }

  private static final DomainController domainController = DomainController.getInstance();
  private static final Scanner scanner = new Scanner(System.in);

  /**
   * Main method for the application.
   *
   * @param args Command line arguments.
   */
  public static void main(String[] args) {
    clearConsole();

    while (true) {

      if (!domainController.isUserLoggedIn()) {
        // Show login menu if no user is authenticated
        printLoginMenu();
        int choice = getValidIntInput("Select an option: ");

        switch (choice) {
          case 1:
            createUser();
            break;
          case 2:
            loginUser();
            break;
          case 3:
            changePassword();
            break;
          case 4:
            System.out.println("Exiting...");
            return;
          default:
            System.out.println("Invalid option. Please try again.");
        }
      } else {
        if (!domainController.hasActiveList()) {
          // Show menu to create a new list if no active list exists
          printCreateListMenu();
          int choice = getValidIntInput("Select an option: ");

          switch (choice) {
            case 1:
              createEmptyProductList();
              break;
            case 2:
              importProducts();
              break;
            case 3:
              logoutUser();
              break;
            case 4:
              System.out.println("Exiting...");
              return;
            default:
              System.out.println("Invalid option. Please try again.");
          }
        } else if (domainController.getActiveListProducts().isEmpty()) {
          // Show menu to add products if the active list is empty
          printNoRackMenu();
          int choice = getValidIntInput("Select an option: ");

          switch (choice) {
            case 1:
              clearConsole();
              manageProductList();
              break;
            case 2:
              clearConsole();
              manageProductLists();
              break;
            case 3:
              logoutUser();
              break;
            case 4:
              System.out.println("Exiting...");
              return;
            default:
              System.out.println("Invalid option. Please try again.");
          }
        } else {
          // Show main menu if a user is authenticated
          printMainMenu();
          int choice = getValidIntInput("Select an option: ");

          switch (choice) {
            case 1:
              clearConsole();
              manageProductList();
              break;
            case 2:
              clearConsole();
              manageProductLists();
              break;
            case 3:
              clearConsole();
              manageRack();
              break;
            case 4:
              exportCurrentList();
              break;
            case 5:
              logoutUser();
              break;
            case 6:
              System.out.println("Exiting...");
              return;
            default:
              System.out.println("Invalid option. Please try again.");
          }
        }
      }
    }
  }

  // Clear the console
  private static void clearConsole() {
    try {
      if (System.getProperty("os.name").contains("Windows")) {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
      } else {
        System.out.print("\033[H\033[2J");
        System.out.flush();
      }
    } catch (Exception e) {
      System.out.println("Error clearing console: " + e.getMessage());
    }
  }

  // Print the login menu
  private static void printLoginMenu() {
    System.out.println("\nLogin Menu:");
    System.out.println("1. Create user");
    System.out.println("2. Login");
    System.out.println("3. Change password");
    System.out.println("4. Exit");
    System.out.print("Select an option: ");
  }

  // Print the create list menu
  private static void printCreateListMenu() {
    System.out.println("\nCreate List Menu:");
    System.out.println("1. Create a new empty product list");
    System.out.println("2. Import products from a file");
    System.out.println("3. Logout");
    System.out.println("4. Exit");
    System.out.print("Select an option: ");
  }

  // Print the main menu
  private static void printNoRackMenu() {
    System.out.println("\nMain Menu:");
    System.out.println("1. Manage actual list");
    System.out.println("2. Manage product lists");
    System.out.println("3. Logout");
    System.out.println("4. Exit");
    System.out.print("Select an option: ");
  }

  // Print the main menu
  private static void printMainMenu() {
    System.out.println("\nMain Menu:");
    System.out.println("1. Manage actual list");
    System.out.println("2. Manage product lists");
    System.out.println("3. Manage rack");
    System.out.println("4. Export current list to file");
    System.out.println("5. Logout");
    System.out.println("6. Exit");
    System.out.print("Select an option: ");
  }

  // Print the product lists management menu
  private static void printProductListsMenu() {
    System.out.println("\nProduct Lists Management Menu:");
    System.out.println("1. Add new product list");
    System.out.println("2. Modify product list name");
    System.out.println("3. Remove product list");
    System.out.println("4. View product lists");
    System.out.println("5. Change active list");
    System.out.println("6. Return to main menu");
    System.out.print("Select an option: ");
  }

  // Print the rack management menu
  private static void printRackManagementMenu() {
    System.out.println("\nRack Management Menu:");
    System.out.println("1. Organize products");
    System.out.println("2. Move product on rack");
    System.out.println("3. Visualize rack");
    System.out.println("4. Return to main menu");
    System.out.print("Select an option: ");
  }

  // Print the manage products only menu
  private static void printManageProductsOnlyMenu() {
    System.out.println("\nManage Products Menu:");
    System.out.println("1. Add product");
    System.out.println("2. Return to main menu");
    System.out.print("Select an option: ");
  }

  // Print the product list management menu
  private static void printProductListMenu() {
    System.out.println("\nProduct List Management Menu:");
    System.out.println("1. Manage products");
    System.out.println("2. Manage similarities");
    System.out.println("3. Manage restrictions");
    System.out.println("4. View product details");
    System.out.println("5. View details of all products");
    System.out.println("6. View products in the current list");
    System.out.println("7. Return to main menu");
    System.out.print("Select an option: ");
  }

  // Print the manage products menu
  private static void printManageProductsMenu() {
    System.out.println("\nManage Products Menu:");
    System.out.println("1. Add product");
    System.out.println("2. Remove product");
    System.out.println("3. View products in the current list");
    System.out.println("4. Return to product list management menu");
    System.out.print("Select an option: ");
  }

  // Print the manage similarities menu
  private static void printManageSimilaritiesMenu() {
    System.out.println("\nManage Similarities Menu:");
    System.out.println("1. Add similarity between products");
    System.out.println("2. Remove similarity between products");
    System.out.println("3. Modify similarity between products");
    System.out.println("4. View product similarities");
    System.out.println("5. View similarities of all products");
    System.out.println("6. View products in the current list");
    System.out.println("7. Return to product list management menu");
    System.out.print("Select an option: ");
  }

  // Print the manage restrictions menu
  private static void printManageRestrictionsMenu() {
    System.out.println("\nManage Restrictions Menu:");
    System.out.println("1. Add restriction between products");
    System.out.println("2. Remove restriction between products");
    System.out.println("3. View product restrictions");
    System.out.println("4. View restrictions of all products");
    System.out.println("5. View products in the current list");
    System.out.println("6. Return to product list management menu");
    System.out.print("Select an option: ");
  }

  // Manage the product lists
  private static void manageProductLists() {
    while (true) {
      printProductListsMenu();
      int choice = getValidIntInput("Select an option: ");

      switch (choice) {
        case 1:
          addProductList();
          break;
        case 2:
          modifyProductListName();
          break;
        case 3:
          removeProductList();
          break;
        case 4:
          viewProductLists();
          break;
        case 5:
          changeActiveList();
          break;
        case 6:
          clearConsole();
          return;
        default:
          System.out.println("Invalid option. Please try again.");
      }
    }
  }

  // Manage the rack
  private static void manageRack() {
    while (true) {
      printRackManagementMenu();
      int choice = getValidIntInput("Select an option: ");

      switch (choice) {
        case 1:
          organizeProducts();
          break;
        case 2:
          moveProduct();
          break;
        case 3:
          visualizeRack();
          break;
        case 4:
          clearConsole();
          return;
        default:
          System.out.println("Invalid option. Please try again.");
      }
    }
  }

  // Manage the product list
  private static void manageProductList() {
    while (true) {
      if (domainController.getActiveListProducts().isEmpty()) {
        printManageProductsOnlyMenu();
        int choice = getValidIntInput("Select an option: ");
        switch (choice) {
          case 1:
            addProduct();
            break;
          case 2:
            clearConsole();
            return;
          default:
            System.out.println("Invalid option. Please try again.");
        }
      } else {
        printProductListMenu();
        int choice = getValidIntInput("Select an option: ");
        switch (choice) {
          case 1:
            clearConsole();
            manageProducts();
            break;
          case 2:
            clearConsole();
            manageSimilarities();
            break;
          case 3:
            clearConsole();
            manageRestrictions();
            break;
          case 4:
            viewProductDetails();
            break;
          case 5:
            viewDetailsOfAllProducts();
            break;
          case 6:
            viewProductsInCurrentList();
            break;
          case 7:
            clearConsole();
            return;
          default:
            System.out.println("Invalid option. Please try again.");
        }
      }
    }
  }

  // Manage products
  private static void manageProducts() {
    while (true) {
      printManageProductsMenu();
      int choice = getValidIntInput("Select an option: ");

      switch (choice) {
        case 1:
          addProduct();
          break;
        case 2:
          viewProductsInCurrentList();
          removeProduct();
          break;
        case 3:
          viewProductsInCurrentList();
          break;
        case 4:
          clearConsole();
          return;
        default:
          System.out.println("Invalid option. Please try again.");
      }
    }
  }

  // Manage similarities
  private static void manageSimilarities() {
    while (true) {
      printManageSimilaritiesMenu();
      int choice = getValidIntInput("Select an option: ");

      switch (choice) {
        case 1:
          viewProductsInCurrentList();
          addProductSimilarity();
          break;
        case 2:
          viewSimilaritiesOfAllProducts();
          removeProductSimilarity();
          break;
        case 3:
          viewSimilaritiesOfAllProducts();
          modifyProductSimilarity();
          break;
        case 4:
          viewProductSimilarities();
          break;
        case 5:
          viewSimilaritiesOfAllProducts();
          break;
        case 6:
          viewProductsInCurrentList();
          break;
        case 7:
          clearConsole();
          return;
        default:
          System.out.println("Invalid option. Please try again.");
      }
    }
  }

  // Manage restrictions
  private static void manageRestrictions() {
    while (true) {
      printManageRestrictionsMenu();
      int choice = getValidIntInput("Select an option: ");

      switch (choice) {
        case 1:
          viewProductsInCurrentList();
          addProductRestriction();
          break;
        case 2:
          viewRestrictionsOfAllProducts();
          removeProductRestriction();
          break;
        case 3:
          viewProductRestrictions();
          break;
        case 4:
          viewRestrictionsOfAllProducts();
          break;
        case 5:
          viewProductsInCurrentList();
          break;
        case 6:
          clearConsole();
          return;
        default:
          System.out.println("Invalid option. Please try again.");
      }
    }
  }

  // Create a new user
  private static void createUser() {
    System.out.print("Enter username: ");
    String username = getNonEmptyInput("Enter username: ");
    System.out.print("Enter password: ");
    String password = getNonEmptyInput("Enter password: ");
    try {
      clearConsole();
      domainController.createUser(username, password);
      System.out.println("User created successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error creating user: " + e.getMessage());
    }
  }

  // Login an existing user
  private static void loginUser() {
    System.out.print("Enter username: ");
    String username = getNonEmptyInput("Enter username: ");
    System.out.print("Enter password: ");
    String password = getNonEmptyInput("Enter password: ");
    try {
      clearConsole();
      domainController.loginUser(username, password);
      System.out.println("Login successful.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error logging in: " + e.getMessage());
    }
  }

  // Change the password of an existing user
  private static void changePassword() {
    System.out.print("Enter username: ");
    String username = getNonEmptyInput("Enter username: ");
    System.out.print("Enter new password: ");
    String newPassword = getNonEmptyInput("Enter password: ");
    try {
      clearConsole();
      domainController.changeUserPassword(username, newPassword);
      System.out.println("Password changed successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error changing password: " + e.getMessage());
    }
  }

  // Export the current list to a file
  private static void exportCurrentList() {
    System.out.print("Enter the path to export the list: ");
    String path = getNonEmptyInput("Enter the path to export the list: ");
    try {
      clearConsole();
      String activeList = domainController.getActiveList();
      domainController.exportList(activeList, path);
      System.out.println("List exported successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error exporting list: " + e.getMessage());
    } catch (RuntimeException e) {
      System.out.println("Error exporting list: " + e.getMessage());
    }
  }

  // Add a new product list
  private static void addProductList() {
    clearConsole();
    System.out.println("Choose an option to create a new product list:");
    System.out.println("1. Create a new empty product list");
    System.out.println("2. Import products from a file");
    System.out.print("Select an option: ");
    int choice = getValidIntInput("Select an option: ");

    switch (choice) {
      case 1:
        createEmptyProductList();
        break;
      case 2:
        importProducts();
        break;
      default:
        System.out.println("Invalid option. Please try again.");
    }
  }

  // Create a new empty product list
  private static void createEmptyProductList() {
    System.out.print("Enter list name: ");
    String listName = getNonEmptyInput("Enter list name: ");
    try {
      clearConsole();
      domainController.addProductList(listName);
      domainController.setActiveList(listName);
      System.out.println("Product list created successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error creating product list: " + e.getMessage());
    }
  }

  // Import products from a file
  private static void importProducts() {
    System.out.print("Enter the path of the file to import: ");
    String path = getNonEmptyInput("Enter the path of the file to import: ");
    System.out.print("Enter the name of the new list to import the products to: ");
    String listName = getNonEmptyInput("Enter the name of the new list to import the products to: ");
    try {
      clearConsole();
      domainController.importList(listName, path);
      domainController.setActiveList(listName);
      System.out.println("Products imported successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error importing products: " + e.getMessage());
    } catch (RuntimeException e) {
      System.out.println("Error importing products: " + e.getMessage());
    }
  }

  // Add a product to the current list
  private static void addProduct() {
    System.out.print("Enter product name: ");
    String productName = getNonEmptyInput("Enter product name: ");
    try {
      clearConsole();
      if (!domainController.addProduct(productName)) {
        System.out.println("Product already exists in the list.");
        return;
      }
      System.out.println("Product added successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error adding product: " + e.getMessage());
    }
  }

  // Remove a product from the current list
  private static void removeProduct() {
    System.out.print("Enter product name: ");
    String productName = getNonEmptyInput("Enter product name: ");
    try {
      clearConsole();
      if (!domainController.removeProduct(productName)) {
        System.out.println("Product does not exist in the list.");
        return;
      }
      System.out.println("Product removed successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error removing product: " + e.getMessage());
    }
  }

  // Add a similarity between two products
  private static void addProductSimilarity() {
    System.out.print("Enter the name of the first product: ");
    String productName1 = getNonEmptyInput("Enter the name of the first product: ");
    System.out.print("Enter the name of the second product: ");
    String productName2 = getNonEmptyInput("Enter the name of the second product: ");
    System.out.print("Enter similarity value: ");
    int similarity = getValidIntInput("Enter similarity value: ");
    try {
      clearConsole();
      domainController.addProductSimilarity(productName1, productName2, similarity);
      System.out.println("Similarity added successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error adding similarity: " + e.getMessage());
    }
  }

  // Remove a similarity between two products
  private static void removeProductSimilarity() {
    System.out.print("Enter the name of the first product: ");
    String productName1 = getNonEmptyInput("Enter the name of the first product: ");
    System.out.print("Enter the name of the second product: ");
    String productName2 = getNonEmptyInput("Enter the name of the second product: ");
    try {
      clearConsole();
      domainController.removeProductSimilarity(productName1, productName2);
      System.out.println("Similarity removed successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error removing similarity: " + e.getMessage());
    }
  }

  // Modify a similarity between two products
  private static void modifyProductSimilarity() {
    System.out.print("Enter the name of the first product: ");
    String productName1 = getNonEmptyInput("Enter the name of the first product: ");
    System.out.print("Enter the name of the second product: ");
    String productName2 = getNonEmptyInput("Enter the name of the second product: ");
    System.out.print("Enter new similarity value: ");
    int similarity = getValidIntInput("Enter new similarity value: ");
    try {
      clearConsole();
      domainController.addProductSimilarity(productName1, productName2, similarity);
      System.out.println("Similarity modified successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error modifying similarity: " + e.getMessage());
    }
  }

  // Add a restriction between two products
  private static void addProductRestriction() {
    System.out.print("Enter the name of the first product: ");
    String productName1 = getNonEmptyInput("Enter the name of the first product: ");
    System.out.print("Enter the name of the second product: ");
    String productName2 = getNonEmptyInput("Enter the name of the second product: ");
    try {
      clearConsole();
      domainController.addProductRestriction(productName1, productName2);
      System.out.println("Restriction added successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error adding restriction: " + e.getMessage());
    }
  }

  // Remove a restriction between two products
  private static void removeProductRestriction() {
    System.out.print("Enter the name of the first product: ");
    String productName1 = getNonEmptyInput("Enter the name of the first product: ");
    System.out.print("Enter the name of the second product: ");
    String productName2 = getNonEmptyInput("Enter the name of the second product: ");
    try {
      clearConsole();
      domainController.removeProductRestriction(productName1, productName2);
      System.out.println("Restriction removed successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error removing restriction: " + e.getMessage());
    }
  }

  // View all products in the current list
  private static void viewProductsInCurrentList() {
    try {
      clearConsole();
      List<String> products = domainController.getActiveListProducts();
      System.out.println("Products in the current list:");
      for (String product : products) {
        System.out.println("- " + product);
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving products from the current list: " + e.getMessage());
    }
  }

  // View similarities of a product
  private static void viewProductSimilarities() {
    System.out.print("Enter product name: ");
    String productName = getNonEmptyInput("Enter product name: ");
    try {
      clearConsole();
      HashMap<String, Integer> similarities = domainController.getProductSimilarities(productName);
      if (similarities.isEmpty()) {
        System.out.println("No similarities found for product " + productName);
        return;
      }
      System.out.println("Similarities of product " + productName + ":");
      boolean hasSimilarities = false;
      for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
        if (entry.getValue() > 0) {
          System.out.println("- " + entry.getKey() + ": " + entry.getValue());
          hasSimilarities = true;
        }
      }
      if (!hasSimilarities) {
        System.out.println("No similarities found for product " + productName);
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product similarities: " + e.getMessage());
    }
  }

  // View restrictions of a product
  private static void viewProductRestrictions() {
    System.out.print("Enter product name: ");
    String productName = getNonEmptyInput("Enter product name: ");
    try {
      clearConsole();
      HashMap<String, Integer> similarities = domainController.getProductSimilarities(productName);
      if (similarities.isEmpty()) {
        System.out.println("No restrictions found for product " + productName);
        return;
      }
      System.out.println("Restrictions of product " + productName + ":");
      boolean hasRestrictions = false;
      for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
        if (entry.getValue() == -1) {
          System.out.println("- " + entry.getKey());
          hasRestrictions = true;
        }
      }
      if (!hasRestrictions) {
        System.out.println("No restrictions found for product " + productName);
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product restrictions: " + e.getMessage());
    }
  }

  // View details of a product (similarities and restrictions)
  private static void viewProductDetails() {
    System.out.print("Enter product name: ");
    String productName = getNonEmptyInput("Enter product name: ");

    try {
      clearConsole();
      HashMap<String, Integer> similarities = domainController.getProductSimilarities(productName);
      System.out.println("Details of product " + productName + ":");
      System.out.println("Similarities:");
      boolean hasSimilarities = false;
      for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
        if (entry.getValue() > 0) {
          System.out.println("- " + entry.getKey() + ": " + entry.getValue());
          hasSimilarities = true;
        }
      }
      if (!hasSimilarities) {
        System.out.println("No similarities found for product " + productName);
      }
      System.out.println("Restrictions:");
      boolean hasRestrictions = false;
      for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
        if (entry.getValue() == -1) {
          System.out.println("- " + entry.getKey());
          hasRestrictions = true;
        }
      }
      if (!hasRestrictions) {
        System.out.println("No restrictions found for product " + productName);
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product details: " + e.getMessage());
    }
  }

  // View details of all products in the current list
  private static void viewDetailsOfAllProducts() {
    try {
      clearConsole();
      List<String> products = domainController.getActiveListProducts();
      for (String product : products) {
        System.out.println("Details of product " + product + ":");
        HashMap<String, Integer> similarities = domainController.getProductSimilarities(product);
        System.out.println("Similarities:");
        boolean hasSimilarities = false;
        for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
          if (entry.getValue() > 0) {
            System.out.println("- " + entry.getKey() + ": " + entry.getValue());
            hasSimilarities = true;
          }
        }
        if (!hasSimilarities) {
          System.out.println("No similarities found for product " + product);
        }
        System.out.println("Restrictions:");
        boolean hasRestrictions = false;
        for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
          if (entry.getValue() == -1) {
            System.out.println("- " + entry.getKey());
            hasRestrictions = true;
          }
        }
        if (!hasRestrictions) {
          System.out.println("No restrictions found for product " + product);
        }
        System.out.println(); // Add a newline between products
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product details: " + e.getMessage());
    }
  }

  // View similarities of all products in the current list
  private static void viewSimilaritiesOfAllProducts() {
    try {
      clearConsole();
      List<String> products = domainController.getActiveListProducts();
      for (String product : products) {
        System.out.println("Similarities of product " + product + ":");
        HashMap<String, Integer> similarities = domainController.getProductSimilarities(product);
        boolean hasSimilarities = false;
        for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
          if (entry.getValue() > 0) {
            System.out.println("- " + entry.getKey() + ": " + entry.getValue());
            hasSimilarities = true;
          }
        }
        if (!hasSimilarities) {
          System.out.println("No similarities found for product " + product);
        }
        System.out.println(); // Add a newline between products
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product similarities: " + e.getMessage());
    }
  }

  // View restrictions of all products in the current list
  private static void viewRestrictionsOfAllProducts() {
    try {
      clearConsole();
      List<String> products = domainController.getActiveListProducts();
      for (String product : products) {
        System.out.println("Restrictions of product " + product + ":");
        HashMap<String, Integer> similarities = domainController.getProductSimilarities(product);
        boolean hasRestrictions = false;
        for (Map.Entry<String, Integer> entry : similarities.entrySet()) {
          if (entry.getValue() == -1) {
            System.out.println("- " + entry.getKey());
            hasRestrictions = true;
          }
        }
        if (!hasRestrictions) {
          System.out.println("No restrictions found for product " + product);
        }
        System.out.println(); // Add a newline between products
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product restrictions: " + e.getMessage());
    }
  }

  // View all product lists of the current user
  private static void viewProductLists() {
    try {
      clearConsole();
      HashSet<String> productLists = domainController.getActiveUserProductLists();
      System.out.println("Product lists:");
      for (String list : productLists) {
        System.out.println("- " + list);
      }
    } catch (IllegalArgumentException e) {
      System.out.println("Error retrieving product lists: " + e.getMessage());
    }
  }

  // Remove a product list
  private static void removeProductList() {
    System.out.print("Enter the name of the list to remove: ");
    String listName = getNonEmptyInput("Enter the name of the list to remove: ");
    try {
      clearConsole();
      domainController.removeProductList(listName);
      System.out.println("Product list removed successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error removing product list: " + e.getMessage());
    }
  }

  // Modify the name of a product list
  private static void modifyProductListName() {
    HashSet<String> productLists = domainController.getActiveUserProductLists();
    if (productLists.isEmpty()) {
      clearConsole();
      System.out.println("No product lists found.");
      return;
    }
    System.out.println("Product lists:");
    for (String list : productLists) {
      System.out.println("- " + list);
    }
    System.out.println("");

    System.out.print("Enter the current name of the list: ");
    String currentName = getNonEmptyInput("Enter the current name of the list: ");
    System.out.print("Enter the new name of the list: ");
    String newName = getNonEmptyInput("Enter the new name of the list: ");
    try {
      clearConsole();
      domainController.modifyProductListName(currentName, newName);
      System.out.println("Product list name modified successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error modifying product list name: " + e.getMessage());
    }
  }

  // Organize products using the selected algorithm
  private static void organizeProducts() {
    clearConsole();
    System.out.println("Select the algorithm to organize products:");
    System.out.println("1. Backtracking");
    System.out.println("2. 2-Approximation");
    System.out.println("3. Hill Climbing");
    System.out.println("4. Iterated Local Search");
    System.out.print("Select an option: ");
    int choice = getValidIntInput("Select an option: ");
    try {
      System.out.println("");
      System.out.print("Enter number of rows: ");
      int rows = getValidIntInput("Enter number of rows: ");
      System.out.print("Enter number of columns: ");
      int columns = getValidIntInput("Enter number of columns: ");
      clearConsole();
      domainController.createRack(rows, columns);
      switch (choice) {
        case 1:
          domainController.solveBacktracking();
          break;
        case 2:
          domainController.solveAproximation();
          break;
        case 3:
          domainController.solveHillClimbing();
          break;
        case 4:
          domainController.solveIteratedLocalSearch();
          break;
        default:
          System.out.println("Invalid option. Please try again.");
          return;
      }
      System.out.println("Products organized successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error organizing products: " + e.getMessage());
    } catch (IllegalStateException e) {
      System.out.println("Error organizing products: " + e.getMessage());
    }
  }

  // Visualize the rack
  private static void visualizeRack() {
    try {
      clearConsole();
      System.out.println("Rack visualization:");
      domainController.printRack();
    } catch (IllegalArgumentException e) {
      System.out.println("Error visualizing rack: " + e.getMessage());
    }
  }

  // Change the active product list
  private static void changeActiveList() {
    HashSet<String> productLists = domainController.getActiveUserProductLists();
    if (productLists.isEmpty()) {
      clearConsole();
      System.out.println("No product lists found.");
      return;
    }
    System.out.println("Product lists:");
    for (String list : productLists) {
      System.out.println("- " + list);
    }
    System.out.println("");

    System.out.print("Enter the name of the list to activate: ");
    String listName = getNonEmptyInput("Enter the name of the list to activate: ");
    try {
      clearConsole();
      domainController.setActiveList(listName);
      System.out.println("Active list changed successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error changing active list: " + e.getMessage());
    }
  }

  // Move a product within the rack
  private static void moveProduct() {
    try {
      visualizeRack();
      System.out.print("Enter the current row of the product: ");
      int currentRow = getValidIntInput("Enter the current row of the product: ");
      System.out.print("Enter the current column of the product: ");
      int currentColumn = getValidIntInput("Enter the current column of the product: ");
      System.out.print("Enter the new row of the product: ");
      int newRow = getValidIntInput("Enter the new row of the product: ");
      System.out.print("Enter the new column of the product: ");
      int newColumn = getValidIntInput("Enter the new column of the product: ");
      clearConsole();
      domainController.moveProduct(currentRow, currentColumn, newRow, newColumn);
      System.out.println("Product moved successfully.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error moving the product: " + e.getMessage());
    }
  }

  // Logout the current user
  private static void logoutUser() {
    try {
      clearConsole();
      domainController.logoutUser();
      System.out.println("Logout successful.");
    } catch (IllegalArgumentException e) {
      System.out.println("Error logging out: " + e.getMessage());
    }
  }

  // Get non-empty input from the user
  private static String getNonEmptyInput(String prompt) {
    String input;
    while (true) {
      input = scanner.nextLine().trim();
      if (!input.isEmpty()) {
        break;
      }
      System.out.println("Input cannot be empty. Please try again.");
      System.out.print(prompt);
    }
    return input;
  }

  // Get a valid integer input from the user
  private static int getValidIntInput(String prompt) {
    int input;
    while (true) {
      try {
        input = Integer.parseInt(getNonEmptyInput(prompt));
        break;
      } catch (NumberFormatException e) {
        System.out.println("Invalid input. Please enter a valid number.");
        System.out.print(prompt);
      }
    }
    return input;
  }
}