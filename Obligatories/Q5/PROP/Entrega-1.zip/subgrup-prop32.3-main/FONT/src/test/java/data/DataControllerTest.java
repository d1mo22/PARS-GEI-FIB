package data;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import domain.Rack.Rack;
import domain.Product.ProductsList;
import domain.Product.Product;
import domain.User.User;
import java.util.*;

public class DataControllerTest {

    /** Data controller instance to be tested */
    private DataController dataController;
    

    @Before
    public void setUp() {
        dataController = new DataController();
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte UserData)

    /**
     * Ensure that a User can be added and returned correctly
     */
    @Test
    public void testAddUserSuccess() {
        dataController.addUser("testUser", "testPassword");
        User user = dataController.getUser("testUser");
        assertEquals("testUser", user.getUsername());
        assertTrue(user.verifyPassword("testPassword"));
    }

    /**
     * Ensure that a null user is returned if it does not exist
     */
    @Test
    public void testGetUserNull() {
        User user = dataController.getUser("testUser");
        assertNull(user);
    }

    /**
     * Ensure that a check for a User that exists returns true
     */
    @Test
    public void testUserExistsTrue() {
        dataController.addUser("testUser", "testPassword");
        assertTrue(dataController.checkUserByUsername("testUser"));
    }

    /**
     * Ensure that a check for a User that does not exist returns false
     */
    @Test
    public void testUserExistsFalse() {
        assertFalse(dataController.checkUserByUsername("testUser"));
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte ListData)

    /**
     * Ensure that a list can be added and returned correctly
     */
    @Test
    public void testAddListSuccess() {
        dataController.addList("testUser", "testList");
        
        HashSet<String> lists = dataController.getLists("testUser");
        assertEquals("testList", lists.iterator().next());
    }

    /**
     * Ensure that a check for a list that exists returns true
     */
    @Test
    public void testListExistsTrue() {
        dataController.addList("testList", "testUser");
        assertTrue(dataController.checkListByName("testList", "testUser"));
    }

    /**
     * Ensure that a check for a list that does not exist returns false
     */
    @Test
    public void testListExistsFalse() {
        assertFalse(dataController.checkListByName("testList", "testUser"));
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte ProductListData)

    /**
     * Ensure that a lists products can be added and returned correctly
     */
    @Test
    public void testAddProductToListSuccess() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));
        productsList.addProduct(new Product("testProduct2", "testList", "testUser"));

        dataController.storeList(productsList);
        
        ProductsList list = dataController.getList("testUser", "testList");
        assertNotNull(list);
        assertEquals("testProduct", list.getProducts().get(0).getName());
        assertEquals("testProduct2", list.getProducts().get(1).getName());
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte ProductData)

    /**
     * Ensure that a product in a list is checked correctly
     */
    @Test
    public void testProductExistsTrue() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));
        productsList.addProduct(new Product("testProduct2", "testList", "testUser"));

        dataController.storeList(productsList);

        assertTrue(dataController.checkProductByName("testProduct", "testUser", "testList"));
    }

    /**
     * Ensure that a product in a list is checked correctly if it does not exist
     */
    @Test
    public void testProductExistsFalse() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));
        
        dataController.storeList(productsList);

        assertFalse(dataController.checkProductByName("testProduct2", "testList", "testUser"));
    }

    /**
     * Ensure that a product can be retrieved correctly
     */
    @Test
    public void testGetProductSuccess() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));
        
        dataController.storeList(productsList);

        assertEquals("testProduct", dataController.getProduct("testProduct", "testUser", "testList").getName());
    }

    /**
     * Ensure that a product can be stored correctly
     */
    @Test
    public void testStoreProductSuccess() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        dataController.storeList(productsList);

        Product product = new Product("testProduct", "testList", "testUser");
        product.addRestriction("restrictedProduct");
        product.addSimilarity("similarProduct", 100);
        dataController.storeProduct(product);

        Product storedProduct = dataController.getProduct("testProduct", "testUser", "testList");
        assertEquals("testProduct", storedProduct.getName());

        HashMap<String, Integer> similarities = storedProduct.getSimilarities();
        assertEquals(100, similarities.get("similarProduct").intValue());
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte Borrar Datos)

    /**
     * Ensure that a list is removed correctly
     */
    @Test
    public void testRemoveListSuccess() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        dataController.storeList(productsList);

        dataController.removeList("testUser", "testList");

        assertNull(dataController.getList("testUser", "testList"));
    }

    /**
     * Ensure that a product is removed correctly
     */
    @Test
    public void testRemoveProductSuccess() {
        dataController.addUser("testUser", "testPassword");

        ProductsList productsList = new ProductsList("testList", "testUser");
        Product product = new Product("testProduct", "testList", "testUser");
        productsList.addProduct(product);
        dataController.storeList(productsList);

        dataController.removeProduct("testProduct", "testUser", "testList");

        assertNull(dataController.getProduct("testProduct", "testUser", "testList"));
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte RackData)

    /**
     * Ensure that a rack can be added and returned correctly
     */
    @Test
    public void testAddRackSuccess() {
        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));

        Rack rack = new Rack(productsList, 2, 2);
        dataController.storeRack(rack);
        
        String[][] rackMatrix = dataController.getLastSavedRackMatrix();
        assertArrayEquals(rack.getRackMatrix(), rackMatrix);
        
        assertEquals("testUser", dataController.getLastSavedRackUser());
        assertEquals("testList", dataController.getLastSavedRackList());
    }

    /**
     * Ensure that rack data can be changed correctly
     */
    @Test
    public void testChangeRackDataSuccess() {
        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));

        Rack rack = new Rack(productsList, 2, 2);
        dataController.storeRack(rack);
        
        assertEquals("testUser", dataController.getLastSavedRackUser());
        assertEquals("testList", dataController.getLastSavedRackList());

        dataController.changeRackListName("testList2");

        assertEquals("testList2", dataController.getLastSavedRackList());
    }

    /**
     * Ensure that a stored rack can be invalidated correctly
     */
    @Test
    public void testInvalidateRackSuccess() {
        ProductsList productsList = new ProductsList("testList", "testUser");
        productsList.addProduct(new Product("testProduct", "testList", "testUser"));

        Rack rack = new Rack(productsList, 2, 2);
        dataController.storeRack(rack);
        
        assertEquals("testUser", dataController.getLastSavedRackUser());
        assertEquals("testList", dataController.getLastSavedRackList());

        dataController.invalidateStoredRack();

        assertArrayEquals(new String[0][0], dataController.getLastSavedRackMatrix());
        assertEquals("", dataController.getLastSavedRackUser());
        assertEquals("", dataController.getLastSavedRackList());
    }


}