package domain.Algorithms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class TSPBacktrackingTest {

    // Test for TSP with max length 3 on a complete graph
    @Test
    public void testTspMaxWithLength() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
        };

        int maxLength = 3;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(65, maxCost);
        assertEquals(Arrays.asList(0, 2, 3, 0), maxPath);
    }

    // Test for TSP with edges having weight -1
    @Test
    public void testTspWithNegativeWeights() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 10, -1, 20},
            {10, 0, 35, -1},
            {-1, 35, 0, 30},
            {20, -1, 30, 0}
        };

        int maxLength = 4;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(95, maxCost); // Expect the maximum cost path without using edges with weight -1
        assertEquals(Arrays.asList(0, 1, 2, 3, 0), maxPath);
    }

    // Test for TSP with no valid path in the graph
    @Test
    public void testTspMaxWithLengthNoPath() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 0, 0, 0},
            {0, 0, 0, 0},
            {0, 0, 0, 0},
            {0, 0, 0, 0}
        };

        int maxLength = 3;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(Integer.MIN_VALUE, maxCost);
        assertTrue(maxPath.isEmpty());
    }

    // Test for TSP with no valid path in the graph
    @Test
    public void testTspMaxWithLength1() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {1, 1, 1, 1},
            {1, 1, 1, 1},
            {1, 1, 1, 1},
            {1, 1, 1, 1}
        };

        int maxLength = 1;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        List<Integer> expectedPath = Arrays.asList(0,0);
        assertEquals(0, maxCost);
        assertEquals(expectedPath,maxPath);
    }

    // Test for TSP with max length equal to the number of nodes in a complete graph
    @Test
    public void testTspMaxWithLengthAllNodes() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
        };

        int maxLength = 4;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(95, maxCost);
        assertEquals(Arrays.asList(0, 1, 2, 3, 0), maxPath);
    }

    //Test for the TSP2Approximation algorithm in maximization mode with invalidoutes.
    @Test
    public void testSolveMaxInvalidRoute() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
                { 0, -10, 15 },
                { -10, 0, 20 },
                { 15, 20, 0 }
        };
        List<Integer> solution =  tsp.tspWithLengthMax(graph, graph.length);
        int maxCost = tsp.getMaxCost();
        assertTrue(solution.isEmpty());
        assertEquals(Integer.MIN_VALUE, maxCost);
    }

    // Test for TSP with max length 2 on a graph with two nodes
    @Test
    public void testTspMaxWithLengthTwoNodes() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 10},
            {10, 0}
        };

        int maxLength = 2;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(20, maxCost);
        assertEquals(Arrays.asList(0, 1, 0), maxPath);
    }

    // Test for TSP with max length 3 on a disconnected graph
    @Test
    public void testTspMaxWithLengthDisconnectedGraph() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 10, 0, 0},
            {10, 0, 0, 0},
            {0, 0, 0, 30},
            {0, 0, 30, 0}
        };

        int maxLength = 3;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(Integer.MIN_VALUE, maxCost);
        assertTrue(maxPath.isEmpty());
    }

    // Test for TSP with max length exceeding the number of nodes in a complete graph
    @Test
    public void testTspMaxWithLengthExceedsNodes() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
        };

        int maxLength = 5;
        List<Integer> maxPath = tsp.tspWithLengthMax(graph, maxLength);
        int maxCost = tsp.getMaxCost();

        assertEquals(95, maxCost);
        assertEquals(Arrays.asList(0, 1, 2, 3, 0), maxPath);
    }

    // Test for TSP with min length on a graph with 9 nodes
    @Test
    public void testTspMin9Nodes() {
        TSPBacktracking tsp = new TSPBacktracking();
        int[][] graph = {
            {  0,29,82,46,68,52,72,42,51},
            { 29, 0,55,46,42,43,43,23,23},
            { 82,55, 0,68,46,55,23,43,41},
            { 46,46,68, 0,82,15,72,31,62},
            { 68,42,46,82, 0,74,23,52,21},
            { 52,43,55,15,74, 0,61,23,55},
            { 72,43,23,72,23,61, 0,42,23},
            { 42,23,43,31,52,23,42, 0,33},
            { 51,23,41,62,21,55,23,33, 0}
        };

        int maxLength = 9;
        tsp.tspWithLengthMin(graph, maxLength);
        int maxCost = tsp.getMinCost();

        assertEquals(246, maxCost); // Expect the minimum cost path
    }
}