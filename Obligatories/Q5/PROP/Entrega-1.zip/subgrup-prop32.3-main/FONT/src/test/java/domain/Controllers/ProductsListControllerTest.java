package domain.Controllers;

import domain.Product.ProductsList;
import domain.Product.Product;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;

public class ProductsListControllerTest {
    private ProductsListController controller;

    @Before
    public void setUp() {
        controller = new ProductsListController();
    }

    @Test
    public void testCreateProductsListSuccess() {
        ProductsList productsList = controller.createProductsList("TestList", "TestUser");
        assertNotNull(productsList);
        assertEquals("TestList", productsList.getName());
        assertEquals("TestUser", productsList.getUser());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductsListNullName() {
        controller.createProductsList(null, "TestUser");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductsListNullUser() {
        controller.createProductsList("TestList", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductsListEmptyName() {
        controller.createProductsList("", "TestUser");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductsListEmptyUser() {
        controller.createProductsList("TestList", "");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddProductProductsListNotSet() {
        controller.addProduct("ProductA");
    }

    @Test
    public void testAddProductSuccess() {
        ProductsList productsList = controller.createProductsList("TestList", "TestUser");
        controller.addProduct("ProductA");
        List<Product> products = productsList.getProducts();
        assertEquals(1, products.size());
        assertEquals("ProductA", products.get(0).getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveProductProductsListNotSet() {
        controller.removeProduct("ProductA");
    }

    @Test
    public void testRemoveProductSuccess() {
        ProductsList productsList = controller.createProductsList("TestList", "TestUser");
        controller.addProduct("ProductA");
        controller.removeProduct("ProductA");
        assertTrue(productsList.getProducts().isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testClearProductsProductsListNotSet() {
        controller.clearProducts();
    }

    @Test
    public void testClearProductsSuccess() {
        ProductsList productsList = controller.createProductsList("TestList", "TestUser");
        controller.addProduct("ProductA");
        controller.addProduct("ProductB");
        controller.clearProducts();
        assertTrue(productsList.getProducts().isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetProductsProductsListNotSet() {
        controller.getProducts();
    }

    @Test
    public void testGetProductsSuccess() {
        controller.createProductsList("TestList", "TestUser");
        controller.addProduct("ProductA");
        List<Product> products = controller.getProducts();
        assertEquals(1, products.size());
        assertEquals("ProductA", products.get(0).getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetProductProductsListNotSet() {
        controller.getProduct(0);
    }

    @Test
    public void testGetProductSuccess() {
        controller.createProductsList("TestList", "TestUser");
        controller.addProduct("ProductA");
        Product product = controller.getProduct(0);
        assertEquals("ProductA", product.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSizeProductsListNotSet() {
        controller.size();
    }

    @Test
    public void testSizeSuccess() {
        controller.createProductsList("TestList", "TestUser");
        controller.addProduct("ProductA");
        controller.addProduct("ProductB");
        assertEquals(2, controller.size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetProductsListNotSet() {
        controller.getProductsList();
    }

    @Test
    public void testGetProductsListSuccess() {
        ProductsList productsList = controller.createProductsList("TestList", "TestUser");
        assertEquals(productsList, controller.getProductsList());
    }
}