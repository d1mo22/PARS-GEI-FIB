package domain.Controllers;

import domain.User.User;
import org.junit.Test;
import static org.junit.Assert.*;

public class UserControllerTest {

    /** Ensure that a user is created successfully. */
    @Test
    public void testCreateUserSuccess() {
        UserController controller = new UserController();
        User user = controller.createUser("testUser", "password123");
        assertNotNull(user);
        assertEquals("testUser", user.getUsername());
        assertTrue(user.verifyPassword("password123"));
    }

    /** Verify that an exception is thrown when the username is null */
    @Test(expected = IllegalArgumentException.class)
    public void testCreateUserNullUsername() {
        UserController controller = new UserController();
        controller.createUser(null, "password123");
    }

    /** Verify that an exception is thrown when the password is null */
    @Test(expected = IllegalArgumentException.class)
    public void testCreateUserNullPassword() {
        UserController controller = new UserController();
        controller.createUser("testUser", null);
    }

    /** Verify that an exception is thrown when the username is empty */
    @Test(expected = IllegalArgumentException.class)
    public void testCreateUserEmptyUsername() {
        UserController controller = new UserController();
        controller.createUser("", "password123");
    }

    /** Verify that an exception is thrown when the password is empty */
    @Test(expected = IllegalArgumentException.class)
    public void testCreateUserEmptyPassword() {
        UserController controller = new UserController();
        controller.createUser("testUser", "");
    }

    @Test
    public void testChangePasswordSuccess() {
        UserController controller = new UserController();
        User user = controller.createUser("testUser", "password123");
        controller.changePassword("newPassword456");
        assertTrue(user.verifyPassword("newPassword456"));
    }

    @Test
    public void testverifyPasswordCorrect() {
        UserController controller = new UserController();
        User user = controller.createUser("testUser", "password123");
        assertTrue(user.verifyPassword("password123"));
    }
}