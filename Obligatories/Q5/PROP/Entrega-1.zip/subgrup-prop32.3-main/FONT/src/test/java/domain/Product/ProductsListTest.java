package domain.Product;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class ProductsListTest {
    private ProductsList productsList;

    @Before
    public void setUp() {
        productsList = new ProductsList("TestList", "TestUser");
    }

    @Test
    public void testProductsListCreation() {
        assertEquals("TestList", productsList.getName());
        assertEquals("TestUser", productsList.getUser());
        assertTrue(productsList.getProducts().isEmpty());
    }

    @Test
    public void testSetName() {
        productsList.setName("NewListName");
        assertEquals("NewListName", productsList.getName());
    }

    @Test
    public void testAddProduct() {
        productsList.addProduct(new Product("ProductA", "TestList", "TestUser"));
        List<Product> products = productsList.getProducts();
        assertEquals(1, products.size());
        assertEquals("ProductA", products.get(0).getName());
    }

    @Test
    public void testRemoveProduct() {
        productsList.addProduct(new Product("ProductA", "TestList", "TestUser"));
        productsList.removeProduct("ProductA");
        assertTrue(productsList.getProducts().isEmpty());
    }

    @Test
    public void testClearProducts() {
        productsList.addProduct(new Product("ProductA", "TestList", "TestUser"));
        productsList.addProduct(new Product("ProductB", "TestList", "TestUser"));
        productsList.clearProducts();
        assertTrue(productsList.getProducts().isEmpty());
    }

    @Test
    public void testGetProductByIndex() {
        productsList.addProduct(new Product("ProductA", "TestList", "TestUser"));
        Product product = productsList.getProductByIndex(0);
        assertEquals("ProductA", product.getName());
    }

    @Test
    public void testSize() {
        productsList.addProduct(new Product("ProductA", "TestList", "TestUser"));
        productsList.addProduct(new Product("ProductB", "TestList", "TestUser"));
        assertEquals(2, productsList.size());
    }
}