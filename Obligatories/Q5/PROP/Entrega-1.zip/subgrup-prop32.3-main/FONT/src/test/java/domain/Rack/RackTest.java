package domain.Rack;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import domain.Product.Product;
import domain.Product.ProductsList;

public class RackTest {

  private Rack rack;

  @Mock
  private Product product1;

  @Mock
  private Product product2;

  @Mock
  private ProductsList productsList;

  @Before
  public void setUp() {
    // Initialize mocks
    MockitoAnnotations.openMocks(this);

    // Configure behaviors of mocked products
    when(product1.getName()).thenReturn("Product1");
    when(product2.getName()).thenReturn("Product2");
    when(product1.getSimilarity("Product2")).thenReturn(10);
    when(product2.getSimilarity("Product1")).thenReturn(10);

    // Configure behavior of mocked ProductsList
    when(productsList.size()).thenReturn(2);
    when(productsList.getProductByIndex(0)).thenReturn(product1);
    when(productsList.getProductByIndex(1)).thenReturn(product2);
    when(productsList.getProducts()).thenReturn(Arrays.asList(product1, product2));

    // Create an instance of Rack with the mocked ProductsList
    rack = new Rack(productsList, 2, 2);
  }

  @Test
  public void testConstructor() {
    assertEquals(2, rack.getRows());
    assertEquals(2, rack.getColumns());
    String[][] expectedMatrix = { { "X", "X" }, { "X", "X" } };
    assertArrayEquals(expectedMatrix, rack.getRackMatrix());
  }

  @Test
  public void testGetRackSpaces() {
    assertEquals(4, rack.getRackSpaces());
  }

  @Test
  public void testSolveTSPHillClimbing() {
    // Execute the algorithm
    rack.solveTSPHillClimbing();

    // Verify the result
    String[][] rackMatrix = rack.getRackMatrix();
    assertNotNull(rackMatrix);
    assertTrue("Product1".equals(rackMatrix[0][0]) ||
        "Product2".equals(rackMatrix[0][0]));
    assertTrue("Product1".equals(rackMatrix[0][1]) ||
        "Product2".equals(rackMatrix[0][1]));
    assertNotEquals(rackMatrix[0][0], rackMatrix[0][1]);
  }

  @Test
  public void testSolveTSPIteratedLocalSearch() {
    // Execute the algorithm
    rack.solveTSPIteratedLocalSearch();

    // Verify the result
    String[][] rackMatrix = rack.getRackMatrix();
    assertNotNull(rackMatrix);
    assertTrue("Product1".equals(rackMatrix[0][0]) ||
        "Product2".equals(rackMatrix[0][0]));
    assertTrue("Product1".equals(rackMatrix[0][1]) ||
        "Product2".equals(rackMatrix[0][1]));
    assertNotEquals(rackMatrix[0][0], rackMatrix[0][1]);
  }

  @Test
  public void testSolveTSPBacktracking() {
    rack.solveTSPBacktracking();
    String[][] rackMatrix = rack.getRackMatrix();

    assertNotNull(rackMatrix);
    assertTrue("Product1".equals(rackMatrix[0][0]) ||
        "Product2".equals(rackMatrix[0][0]));
    assertTrue("Product1".equals(rackMatrix[0][1]) ||
        "Product2".equals(rackMatrix[0][1]));
    assertNotEquals(rackMatrix[0][0], rackMatrix[0][1]);
  }

  @Test
  public void testSolveTSP2Approximation() {
    rack.solveTSPApproximation();

    // Verify the result
    String[][] rackMatrix = rack.getRackMatrix();
    assertNotNull(rackMatrix);
    assertTrue("Product1".equals(rackMatrix[0][0]) ||
        "Product2".equals(rackMatrix[0][0]));
    assertTrue("Product1".equals(rackMatrix[0][1]) ||
        "Product2".equals(rackMatrix[0][1]));
    assertNotEquals(rackMatrix[0][0], rackMatrix[0][1]);
  }

  @Test
  public void testSetProducts() {
    // Create new mocked products
    Product new1 = mock(Product.class);
    Product new2 = mock(Product.class);
    when(new1.getName()).thenReturn("New1");
    when(new2.getName()).thenReturn("New2");

    // Create a new mocked ProductsList with the new products
    ProductsList newProductsList = mock(ProductsList.class);
    when(newProductsList.size()).thenReturn(2);
    when(newProductsList.getProductByIndex(0)).thenReturn(new1);
    when(newProductsList.getProductByIndex(1)).thenReturn(new2);
    when(newProductsList.getProducts()).thenReturn(Arrays.asList(new1, new2));

    // Override the product list in the rack
    rack.setProducts(newProductsList);

    // Verify that the products have been updated correctly
    List<Product> updatedProducts = rack.getProducts();
    assertEquals("New1", updatedProducts.get(0).getName());
    assertEquals("New2", updatedProducts.get(1).getName());
  }

  @Test
  public void testInitializeRackMatrix() {
    String[][] expectedMatrix = { { "X", "X" }, { "X", "X" } };
    assertArrayEquals(expectedMatrix, rack.getRackMatrix());
  }

  @Test
  public void testSetRowsAndColumns() {
    rack.setRows(3);
    rack.setColumns(3);
    assertEquals(3, rack.getRows());
    assertEquals(3, rack.getColumns());

    String[][] expectedMatrix = {
        { "X", "X", "X" },
        { "X", "X", "X" },
        { "X", "X", "X" }
    };
    assertArrayEquals(expectedMatrix, rack.getRackMatrix());
  }

  @Test
  public void testCreateRackWithNoProducts() {
    // Create an empty mocked ProductsList
    ProductsList emptyProductsList = mock(ProductsList.class);
    when(emptyProductsList.size()).thenReturn(0);
    when(emptyProductsList.getProducts()).thenReturn(new ArrayList<>());

    // Create an instance of Rack with the empty list
    Rack emptyRack = new Rack(emptyProductsList, 2, 2);
    assertEquals(0, emptyRack.getProducts().size());
    String[][] expectedMatrix = { { "X", "X" }, { "X", "X" } };
    assertArrayEquals(expectedMatrix, emptyRack.getRackMatrix());
  }

  @Test
  public void testSetRowsUpdatesMatrix() {
    rack.setRows(3);
    assertEquals(3, rack.getRows());
    String[][] expectedMatrix = {
        { "X", "X" },
        { "X", "X" },
        { "X", "X" }
    };
    assertArrayEquals(expectedMatrix, rack.getRackMatrix());
  }

  @Test
  public void testSetProductsUpdatesMatrix() {
    // Create new mocked products
    Product new1 = mock(Product.class);
    Product new2 = mock(Product.class);
    when(new1.getName()).thenReturn("New1");
    when(new2.getName()).thenReturn("New2");

    // Create a new mocked ProductsList
    ProductsList newProductsList = mock(ProductsList.class);
    when(newProductsList.size()).thenReturn(2);
    when(newProductsList.getProductByIndex(0)).thenReturn(new1);
    when(newProductsList.getProductByIndex(1)).thenReturn(new2);
    when(newProductsList.getProducts()).thenReturn(Arrays.asList(new1, new2));

    // Override the product list in the rack
    rack.setProducts(newProductsList);

    // Verify that the products have been updated correctly
    List<Product> updatedProducts = rack.getProducts();
    assertEquals("New1", updatedProducts.get(0).getName());
    assertEquals("New2", updatedProducts.get(1).getName());
  }

  @Test
  public void testSwapProductsNormal() {
    // Manually place products in the rack
    String[][] initialMatrix = {
        { "Product1", "Product2" },
        { "X", "X" }
    };
    rack.setRackMatrix(initialMatrix);

    // Execute swap
    rack.swapProducts(0, 0, 0, 1);

    // Verify that the products were swapped
    String[][] matrix = rack.getRackMatrix();
    assertEquals("Product2", matrix[0][0]);
    assertEquals("Product1", matrix[0][1]);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSwapProductsInvalidCoordinates() {
    rack.swapProducts(-1, 0, 0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSwapProductsOutOfBounds() {
    rack.swapProducts(0, 0, 5, 5);
  }

  @Test
  public void testSwapProductsCost() {
    // Set up the rack with known products
    String[][] initialMatrix = {
        { "Product1", "Product2" },
        { "X", "X" }
    };
    rack.setRackMatrix(initialMatrix);

    // Perform the swap and verify the cost
    rack.swapProducts(0, 0, 0, 1);

  }

  @Test
  public void testMultipleSwaps() {
    // Set up the rack with known products
    String[][] initialMatrix = {
        { "Product1", "Product2" },
        { "X", "X" }
    };
    rack.setRackMatrix(initialMatrix);

    // Perform multiple swaps
    rack.swapProducts(0, 0, 0, 1);
    rack.swapProducts(0, 0, 0, 1);

    // Verify that after two swaps, the products return to their original positions
    String[][] finalMatrix = rack.getRackMatrix();
    assertEquals("Product1", finalMatrix[0][0]);
    assertEquals("Product2", finalMatrix[0][1]);
  }

}