package domain.User;

import static org.junit.Assert.*;
import org.junit.Test;

public class UserTest {

    @Test
    public void testUserCreation() {
        User user = new User("testUser", "password123");
        assertEquals("testUser", user.getUsername());
        assertTrue(user.verifyPassword("password123"));
    }

    @Test
    public void testVerifyPasswordCorrect() {
        User user = new User("testUser", "password123");
        assertTrue(user.verifyPassword("password123"));
    }

    @Test
    public void testVerifyPasswordIncorrect() {
        User user = new User("testUser", "password123");
        assertFalse(user.verifyPassword("wrongPassword"));
    }

    @Test
    public void testSetPassword() {
        User user = new User("testUser", "password123");
        user.setPassword("newPassword456");
        assertTrue(user.verifyPassword("newPassword456"));
        assertFalse(user.verifyPassword("password123"));
    }
}