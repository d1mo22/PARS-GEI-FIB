package data;

import java.util.*;
import domain.Product.Product;
import domain.Product.ProductsList;
import domain.Rack.Rack;
import domain.User.User;

/**
 * DataController class that manages user, list, and product data.
 *
 * @author Marc Escribano, David Morais
 */
public class DataController {
  /**
   * UserGestor instance to manage user data
   */
  private UserGestor userGestor;

  /**
   * ProductGestor instance to manage product data
   */
  private ProductGestor productGestor;
  /**
   * ListGestor instance to manage list data
   */
  private ListGestor listGestor;

  /**
   * Stores the last calculated rack matrix
   */
  private String[][] rackMatrix;

  /**
   * Stores the user for the last calculated rack
   */
  private String rackUser;

  /**
   * Stores the list name for the last calculated rack
   */
  private String rackList;

  /**
   * Constructor for the DataController class.
   */
  public DataController() {
    userGestor = new UserGestor();
    productGestor = new ProductGestor();
    listGestor = new ListGestor();
    rackMatrix = new String[0][0];
    rackUser = "";
    rackList = "";
  }

  // METHODS FOR USER DATA

  /**
   * Adds a user to the system
   *
   * @param username Username of the user to be added
   * @param password Password of the user to be added
   */
  public void addUser(String username, String password) {
    userGestor.addUser(new User(username, password));
  }

  /**
   * Gets a user from the system
   *
   * @param username Username of the user to be retrieved
   * @return User instance with the username and password of the user or null if
   *         it does not exist
   */
  public User getUser(String username) {
    return userGestor.getUser(username);
  }

  /**
   * Checks if a user exists in the system
   *
   * @param username Username of the user to check if it exists
   * @return True if the user exists, false otherwise
   */
  public boolean checkUserByUsername(String username) {
    return userGestor.checkUserByUsername(username);
  }

  // METHODS FOR LIST DATA

  /**
   * Adds a list to the system
   *
   * @param username Username of the user to be added
   * @param listName Name of the list to be added
   */
  public void addList(String username, String listName) {
    listGestor.addList(username, listName);
  }

  /**
   * Gets a list from the system
   *
   * @param username Username of the user to be retrieved
   * @param listName Name of the list to be retrieved
   * @return ProductsList instance with the list data or null if it does not exist
   */
  public ProductsList getList(String username, String listName) {
    return listGestor.getList(username, listName);
  }

  /**
   * Gets all lists for a user from the system
   *
   * @param username Username of the user to get lists for
   * @return HashSet of list names
   */
  public HashSet<String> getLists(String username) {
    return listGestor.getLists(username);
  }

  /**
   * Checks if a list exists in the system
   *
   * @param username Username of the user to check if the list exists
   * @param listName Name of the list to check if it exists
   * @return True if the list exists, false otherwise
   */
  public boolean checkListByName(String username, String listName) {
    return listGestor.checkListByName(username, listName);
  }

  /**
   * Stores a list to the system
   *
   * @param list ProductsList instance to store
   */
  public void storeList(ProductsList list) {
    listGestor.storeList(list);
  }

  /**
   * Removes a list from the system
   *
   * @param username Username of the user to remove the list from
   * @param listName Name of the list to be removed
   */
  public void removeList(String username, String listName) {
    if (checkListByName(username, listName)) {
      ProductsList list = getList(username, listName);
      for (Product product : list.getProducts()) {
        removeProduct(product.getName(), username, listName);
      }
      listGestor.removeList(username, listName);
    }
  }

  // METHODS FOR RACKS

  /**
   * Gets the last saved rack matrix from the system
   *
   * @return The last saved rack matrix
   */
  public String[][] getLastSavedRackMatrix() {
    return rackMatrix;
  }

  /**
   * Gets the user for the last saved rack
   *
   * @return The user for the last saved rack
   */
  public String getLastSavedRackUser() {
    return rackUser;
  }

  /**
   * Gets the list name for the last saved rack
   *
   * @return The list name for the last saved rack
   */
  public String getLastSavedRackList() {
    return rackList;
  }

  /**
   * Stores a rack matrix to the system
   *
   * @param rack Instance of the rack to store
   */
  public void storeRack(Rack rack) {
    rackMatrix = rack.getRackMatrix();
    rackUser = rack.getUser();
    rackList = rack.getListName();
  }

  /**
   * Change the stored rack product list name
   *
   * @param listName New list name for the stored rack
   */
  public void changeRackListName(String listName) {
    rackList = listName;
  }

  /**
   * Removes the stored rack
   */
  public void invalidateStoredRack() {
    rackMatrix = new String[0][0];
    rackUser = "";
    rackList = "";
  }

  // METHODS FOR PRODUCTS

  /**
   * Stores a product to the system
   *
   * @param product Product instance to store
   */
  public void storeProduct(Product product) {
    productGestor.storeProduct(product);
    ProductsList list = getList(product.getUser(), product.getListName());
    if (list != null) {
      list.removeProduct(product.getName());
      list.addProduct(product);
      storeList(list);
    }
  }

  /**
   * Gets a product from the system
   *
   * @param productName Name of the product to be retrieved
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   * @return Product instance with the product data or null if it does not exist
   */
  public Product getProduct(String productName, String username, String listName) {
    return productGestor.getProduct(productName, username, listName);
  }

  /**
   * Checks if a product exists in the system
   *
   * @param productName Name of the product to check if it exists
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   * @return True if the product exists, false otherwise
   */
  public boolean checkProductByName(String productName, String username, String listName) {
    return productGestor.checkProductByName(productName, username, listName);
  }

  /**
   * Removes a product from the system
   *
   * @param productName Name of the product to be removed
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   */
  public void removeProduct(String productName, String username, String listName) {
    ProductsList list = getList(username, listName);

    if (list != null) {
      list.removeProduct(productName);
      storeList(list);
    }

    productGestor.removeProduct(productName, username, listName);

    if (rackList.equals(listName) && rackUser.equals(username)) {
      invalidateStoredRack();
    }
  }
}