package data;

import domain.Product.ProductsList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * List manager that handles persistence using JSON files.
 * It stores the lists in a JSON file and the products in separate JSON files.
 * 
 * @author David Morais
 */
public class ListGestor {
    /**
     * Default file paths.
     */
    private static final String DEFAULT_LISTS_FILE_PATH = "DATA/lists.json";
    /**
     * Default directory to store the lists.
     */
    private static final String DEFAULT_LISTS_DIR = "DATA/lists/";
    /**
     * File path of the lists file.
     */
    private String listsFilePath;
    /**
     * Directory to store the lists.
     */
    private String listsDir;
    /**
     * Gson instance to handle JSON serialization.
     */
    private Gson gson;
    /**
     * Map of user to sets of list names.
     */
    private Map<String, HashSet<String>> userLists;

    /**
     * Default constructor that uses the default file paths.
     */
    public ListGestor() {
        this(DEFAULT_LISTS_FILE_PATH, DEFAULT_LISTS_DIR);
    }

    /**
     * Constructor that allows specifying custom file paths.
     *
     * @param listsFilePath Path of the lists file.
     * @param listsDir      Directory to store the lists.
     */
    public ListGestor(String listsFilePath, String listsDir) {
        this.gson = new Gson();
        this.listsFilePath = listsFilePath;
        this.listsDir = listsDir;
        this.userLists = loadLists();
        createListsDirectory();
    }

    /**
     * Loads the lists from the JSON file.
     *
     * @return Map of user to sets of list names.
     */
    private Map<String, HashSet<String>> loadLists() {
        File file = new File(listsFilePath);
        if (!file.exists()) {
            return new HashMap<>();
        }
        try (FileReader reader = new FileReader(file)) {
            Type type = new TypeToken<Map<String, HashSet<String>>>() {
            }.getType();
            Map<String, HashSet<String>> loadedData = gson.fromJson(reader, type);
            if (loadedData == null) {
                return new HashMap<>();
            }
            return loadedData != null ? loadedData : new HashMap<>();
        } catch (IOException e) {
            System.out.println("Error loading lists.");
            // e.printStackTrace();
            return new HashMap<>();
        }
    }

    /**
     * Saves the lists to the JSON file.
     * @throws IOException If an error occurs while saving the lists.
     */
    private void saveLists() throws IOException {
        try (FileWriter writer = new FileWriter(listsFilePath)) {
            gson.toJson(userLists, writer);
        }
    }

    /**
     * Creates the directory to store the lists if it does not exist.
     */
    private void createListsDirectory() {
        File directory = new File(listsDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

    /**
     * Gets a set of list names for a user.
     *
     * @param username User name.
     * @return Set of list names or null if the user has no lists.
     */
    public HashSet<String> getLists(String username) {
        return userLists.getOrDefault(username, new HashSet<>());
    }

    /**
     * Gets an instance of ProductsList for a user and list name.
     *
     * @param username User name.
     * @param listName List name.
     * @return Instance of ProductsList or null if it does not exist.
     */
    public ProductsList getList(String username, String listName) {
        if (!checkListByName(username, listName)) {
            return null;
        }
        String filePath = listsDir + username + "_" + listName + ".json";
        File file = new File(filePath);

        // Verificación adicional del archivo
        if (!file.exists() || file.length() == 0) {
            return new ProductsList(listName, username); // Crear nueva lista si no existe
        }

        try (FileReader reader = new FileReader(file)) {
            Type type = new TypeToken<ProductsList>() {
            }.getType();
            return gson.fromJson(reader, type);
        } catch (IOException e) {
            System.err.println("Error loading list: " + e.getMessage());
            return new ProductsList(listName, username); // Crear nueva lista en caso de error
        }
    }

    /**
     * Adds a list for a user.
     *
     * @param username Username.
     * @param listName List name.
     */
    public void addList(String username, String listName) {
        userLists.putIfAbsent(username, new HashSet<>());
        userLists.get(username).add(listName);
        try {
            saveLists();
        } catch (IOException e) {
            System.out.println("Error saving lists.");
        }
    }

    /**
     * Stores an instance of ProductsList.
     *
     * @param productList Instance of ProductsList to store.
     */
    public void storeList(ProductsList productList) {
        String username = productList.getUser();
        String listName = productList.getName();
        addList(username, listName);
        String filePath = listsDir + username + "_" + listName + ".json";
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(productList, writer);
        } catch (IOException e) {
            System.out.println("Error saving list.");
        }
    }

    /**
     * Checks if a list exists for a user.
     *
     * @param username User name.
     * @param listName List name.
     * @return True if it exists, false otherwise.
     */
    public boolean checkListByName(String username, String listName) {
        return userLists.containsKey(username) && userLists.get(username).contains(listName);
    }

    /**
     * Removes a list for a user.
     *
     * @param username User name.
     * @param listName List name to remove.
     */
    public void removeList(String username, String listName) {
        if (checkListByName(username, listName)) {
            userLists.get(username).remove(listName);
            if (userLists.get(username).isEmpty()) {
                userLists.remove(username);
            }
            try {
                saveLists();
            } catch (IOException e) {
                System.out.println("Error saving lists.");
            }
            // Delete the list file
            String filePath = listsDir + username + "_" + listName + ".json";
            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }
        }
    }
}