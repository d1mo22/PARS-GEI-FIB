package data;

import domain.Product.Product;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Product manager that handles persistence using JSON files.
 */
public class ProductGestor {
  private String filePath;
  private Gson gson;
  private List<Product> products;

  /**
   * Default constructor that uses the default file path.
   */
  public ProductGestor() {
    this("DATA/products.json");
  }

  /**
   * Constructor that allows specifying custom file paths.
   * 
   * @param filePath Path of the products file.
   */
  public ProductGestor(String filePath) {
    this.filePath = filePath;
    this.gson = new Gson();
    this.products = loadProducts();
  }

  /**
   * Loads the products from the JSON file.
   * 
   * @return List of products.
   */
  private List<Product> loadProducts() {
    try (FileReader reader = new FileReader(filePath)) {
      Type listType = new TypeToken<List<Product>>() {
      }.getType();
      List<Product> list = gson.fromJson(reader, listType);
      return list != null ? list : new ArrayList<>();
    } catch (IOException e) {
      return new ArrayList<>();
    }
  }

  /**
   * Saves the products to the JSON file.
   * 
   * @throws IOException If an error occurs while saving the products.
   */
  private void saveProducts() throws IOException {
    try (FileWriter writer = new FileWriter(filePath)) {
      gson.toJson(products, writer);
    } catch (IOException e) {
      System.out.println("Error saving products");
    }
  }

  /**
   * Stores a product instance to the data
   * 
   * @param product Instance of product to store in the data
   */
  public void storeProduct(Product product) {
    // Buscar y actualizar producto existente
    products.removeIf(p -> p.getName().equalsIgnoreCase(product.getName())
        && p.getUser().equalsIgnoreCase(product.getUser())
        && p.getListName().equalsIgnoreCase(product.getListName()));

    // Añadir el producto (nuevo o actualizado)
    products.add(product);

    try {
      saveProducts();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Removes a product from the data
   * 
   * @param productName Name of the product to remove
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   */
  public void removeProduct(String productName, String username, String listName) {
    products.removeIf(p -> p.getName().equalsIgnoreCase(productName)
        && p.getUser().equalsIgnoreCase(username)
        && p.getListName().equalsIgnoreCase(listName));
    try {
      saveProducts();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Gets a product instance by identifier from the data or null if it does
   * not exist
   * 
   * @param productName Name of the product to get from the data
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   * @return Product instance from the data or null if it does not exist
   */
  public Product getProduct(String productName, String username, String listName) {
    return products.stream()
        .filter(p -> p.getName().equalsIgnoreCase(productName)
            && p.getUser().equalsIgnoreCase(username)
            && p.getListName().equalsIgnoreCase(listName))
        .findFirst()
        .orElse(null);
  }

  /**
   * Checks if a product exists in the data
   * 
   * @param productName Name of the product to check if it exists
   * @param username    Username of the user that has the product
   * @param listName    Name of the list that has the product
   * @return True if the product exists, false otherwise
   */
  public boolean checkProductByName(String productName, String username, String listName) {
    return products.stream()
        .anyMatch(p -> p.getName().equalsIgnoreCase(productName)
            && p.getUser().equalsIgnoreCase(username)
            && p.getListName().equalsIgnoreCase(listName));
  }

  /**
   * Gets all the products from the data
   * 
   * @return List of products from the data
   */
  public List<Product> getProducts() {
    return products;
  }
}