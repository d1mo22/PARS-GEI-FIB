package data;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import domain.User.User;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;

public class UserGestor {
    private HashMap<String, User> users;
    private static final Gson gson = new Gson();
    private static final String FILE_PATH = "./DATA/users/userData.json";

    public UserGestor() {
        users = new HashMap<String, User>();
        loadUsersFromJson();
    }

    /**
     * Loads users from a JSON file.
     */
    private void loadUsersFromJson() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs(); // Crear directorios si no existen
                file.createNewFile(); // Crear el archivo si no existe
            } catch (IOException e) {
                System.out.println("Error creating file: " + FILE_PATH);
                e.printStackTrace();
            }
            users = new HashMap<>();
            return;
        }
        if (file.length() == 0) {
            users = new HashMap<>();
            return;
        }
        try (FileReader reader = new FileReader(FILE_PATH)) {
            Type userMapType = new TypeToken<HashMap<String, User>>() {}.getType();
            users = gson.fromJson(reader, userMapType);
        } catch (IOException e) {
            users = new HashMap<>();
            System.out.println("Error reading file: " + FILE_PATH);
            e.printStackTrace();
        }
    }

    /**
     * Saves users to a JSON file.
     */
    private void saveUsersToJson() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs(); // Crear directorios si no existen
                file.createNewFile(); // Crear el archivo si no existe
            } catch (IOException e) {
                System.out.println("Error creating file: " + FILE_PATH);
                e.printStackTrace();
            }
            users = new HashMap<>();
            return;
        }
        try (FileWriter writer = new FileWriter(FILE_PATH)) {
            gson.toJson(users, writer);
        }
        catch (IOException e) {
            System.out.println("Error writing file: " + FILE_PATH);
            e.printStackTrace();
        }
    }

    /**
     * Gets a user by their username.
     * 
     * @param username The username of the user to retrieve.
     * @return The user corresponding to the username, or null if not found.
     */
    public User getUser(String username) {
        if (!users.containsKey(username)) {
            System.out.println("User not found: " + username);
            return null;
        }
        return users.get(username);
    }

    /**
     * Checks if a user exists by their username.
     * 
     * @param username The username to check.
     * @return True if the user exists, otherwise false.
     */
    public boolean checkUserByUsername(String username) {
        return users.containsKey(username);
    }

    /**
     * Adds a user to the gestor.
     * 
     * @param user The user to add.
     */
    public void addUser(User user) {
        users.put(user.getUsername(), user);
        saveUsersToJson();
    }

    /**
     * Gets all users from the gestor.
     * 
     * @return A HashMap containing all users.
     */
    public HashMap<String, User> getAllUsers() {
        return users;
    }

    /**
     * Clears all users from the gestor and the JSON file.
     */
    public void clearAllUsers() {
        users.clear();
        saveUsersToJson();
    }
}