package domain.Algorithms;

import java.util.*;

/**
 * Implements the 2-approximation algorithm for the Traveling Salesman Problem (TSP).
 * @author Marc Escribano
 */
public class TSP2Approximation {

    /**
     * The weight of the last calculated Hamiltonian cycle.
     */
    private int lastWeight;
    /**
     * The last calculated Hamiltonian path.
     */
    private List<Integer> lastPath;

    /**
     * This constructor initializes the last calculated weight and path.
     */
    public TSP2Approximation() {
        lastWeight = 0;
        lastPath = new ArrayList<>();
    }

    // Function to calculate the TSP using 2-approximation algorithm (Maximum Spanning Tree)
    /**
     * This function calculates the Traveling Salesman Problem (TSP) using the 2-approximation algorithm.
     * @param graph The adjacency matrix representing the graph.
     * @param maxLength The maximum length of the path.
     * @return The weight of the calculated Hamiltonian cycle.
     */
    public int calculateTSP2ApproximationMax(int[][] graph, int maxLength) {
        int numVertices = graph.length;
        if (numVertices <= 0 || maxLength <= 0 || graph == null) {
            lastWeight = Integer.MIN_VALUE;
            lastPath = new ArrayList<>();
            return lastWeight;
        }
        if (maxLength == 1) {
            lastWeight = 0;
            lastPath = new ArrayList<>(Collections.nCopies(2, 0));
            return lastWeight;
        }
        if (maxLength > numVertices) {
            maxLength = numVertices;
        }
        if (!isConnected(numVertices, graph)) {
            lastWeight = Integer.MIN_VALUE;
            lastPath = new ArrayList<>();
            return lastWeight;
        }

        int[] parent = primMSTMax(maxLength, graph);

        // Step 1: Create a directed graph from the MST
        List<List<Integer>> directedGraph = new ArrayList<>();
        for (int i = 0; i < maxLength; i++) {
            directedGraph.add(new ArrayList<>());
        }
        for (int i = 1; i < maxLength; i++) {
            directedGraph.get(parent[i]).add(i);
            directedGraph.get(i).add(parent[i]);
        }

        // Step 2: Find an Eulerian cycle in the directed graph
        List<Integer> eulerianCycle = findEulerianCycle(directedGraph, maxLength);

        // Step 3: Remove duplicates to form a Hamiltonian cycle
        Set<Integer> visitedSet = new HashSet<>();
        List<Integer> hamiltonianCycle = new ArrayList<>();
        for (int vertex : eulerianCycle) {
            if (!visitedSet.contains(vertex)) {
                visitedSet.add(vertex);
                hamiltonianCycle.add(vertex);
            }
        }
        hamiltonianCycle.add(hamiltonianCycle.get(0)); // Complete the cycle

        // Step 4: Calculate the weight of the Hamiltonian cycle
        int weight = 0;
        for (int i = 0; i < hamiltonianCycle.size() - 1; i++) {
            if (graph[hamiltonianCycle.get(i)][hamiltonianCycle.get(i + 1)] < 0) {
                lastWeight = Integer.MIN_VALUE;
                lastPath = new ArrayList<>();
                return lastWeight;
            }
            weight += graph[hamiltonianCycle.get(i)][hamiltonianCycle.get(i + 1)];
        }

        // Store the result
        lastWeight = weight;
        lastPath = hamiltonianCycle;
        return lastWeight;
    }

    // Function to calculate the TSP using 2-approximation algorithm (minimum weight)
    /**
     * This function calculates the Traveling Salesman Problem (TSP) using the 2-approximation algorithm.
     * @param graph The adjacency matrix representing the graph.
     * @param maxLength The maximum length of the path.
     * @return The weight of the calculated Hamiltonian cycle.
     */
    public int calculateTSP2ApproximationMin(int[][] graph, int maxLength) {
        int numVertices = graph.length;
        if (numVertices <= 0 || maxLength <= 0 || graph == null) {
            lastWeight = Integer.MIN_VALUE;
            lastPath = new ArrayList<>();
            return lastWeight;
        }
        if (maxLength == 1) {
            lastWeight = 0;
            lastPath = new ArrayList<>(Collections.nCopies(2, 0));
            return lastWeight;
        }
        if (maxLength > numVertices) {
            maxLength = numVertices;
        }
        if (!isConnected(numVertices, graph)) {
            lastWeight = Integer.MIN_VALUE;
            lastPath = new ArrayList<>();
            return lastWeight;
        }

        int[] parent = primMSTMin(maxLength, graph);

        // Step 1: Create a directed graph from the MST
        List<List<Integer>> directedGraph = new ArrayList<>();
        for (int i = 0; i < maxLength; i++) {
            directedGraph.add(new ArrayList<>());
        }
        for (int i = 1; i < maxLength; i++) {
            directedGraph.get(parent[i]).add(i);
            directedGraph.get(i).add(parent[i]);
        }

        // Step 2: Find an Eulerian cycle in the directed graph
        List<Integer> eulerianCycle = findEulerianCycle(directedGraph, maxLength);

        // Step 3: Remove duplicates to form a Hamiltonian cycle
        Set<Integer> visitedSet = new HashSet<>();
        List<Integer> hamiltonianCycle = new ArrayList<>();
        for (int vertex : eulerianCycle) {
            if (!visitedSet.contains(vertex)) {
                visitedSet.add(vertex);
                hamiltonianCycle.add(vertex);
            }
        }
        hamiltonianCycle.add(hamiltonianCycle.get(0)); // Complete the cycle

        // Step 4: Calculate the weight of the Hamiltonian cycle
        int weight = 0;
        for (int i = 0; i < hamiltonianCycle.size() - 1; i++) {
            if (graph[hamiltonianCycle.get(i)][hamiltonianCycle.get(i + 1)] < 0) {
                lastWeight = Integer.MIN_VALUE;
                lastPath = new ArrayList<>();
                return lastWeight;
            }
            weight += graph[hamiltonianCycle.get(i)][hamiltonianCycle.get(i + 1)];
        }

        // Store the result
        lastWeight = weight;
        lastPath = hamiltonianCycle;
        return lastWeight;
    }

    // Function to implement Prim's algorithm to find the maximum spanning tree (MST)
    /**
     * This function implements Prim's algorithm to find the maximum spanning tree (MST) in a graph.
     * @param numVertices The number of vertices in the graph.
     * @param graph The adjacency matrix representing the graph.
     * @return An array representing the MST, where parent[i] is the parent of vertex i in the MST.
     */
    public int[] primMSTMax(int numVertices, int[][] graph) {
        int[] parent = new int[numVertices];
        int[] key = new int[numVertices];
        boolean[] mstSet = new boolean[numVertices];

        Arrays.fill(key, Integer.MIN_VALUE);
        key[0] = Integer.MAX_VALUE;
        parent[0] = -1;

        for (int count = 0; count < numVertices - 1; count++) {
            int u = maxKey(key, mstSet, numVertices);
            if (u == -1) {
                return new int[0]; // Return an empty array if no valid MST exists
            }
            mstSet[u] = true;

            for (int v = 0; v < numVertices; v++) {
                if (graph[u][v] > 0 && !mstSet[v] && graph[u][v] > key[v]) {
                    parent[v] = u;
                    key[v] = graph[u][v];
                }
            }
        }

        return parent;
    }

    // Function to implement Prim's algorithm to find the minimum spanning tree (MST)
    /**
     * This function implements Prim's algorithm to find the minimum spanning tree (MST) in a graph.
     * @param numVertices The number of vertices in the graph.
     * @param graph The adjacency matrix representing the graph.
     * @return An array representing the MST, where parent[i] is the parent of vertex i in the MST.
     */
    private int[] primMSTMin(int numVertices, int[][] graph) {
        int[] parent = new int[numVertices];
        int[] key = new int[numVertices];
        boolean[] mstSet = new boolean[numVertices];

        Arrays.fill(key, Integer.MAX_VALUE);
        key[0] = 0;
        parent[0] = -1;

        for (int count = 0; count < numVertices - 1; count++) {
            int u = minKey(key, mstSet, numVertices);
            if (u == -1) {
                return new int[0]; // Return an empty array if no valid MST exists
            }
            mstSet[u] = true;

            for (int v = 0; v < numVertices; v++) {
                if (graph[u][v] > 0 && !mstSet[v] && graph[u][v] < key[v]) {
                    parent[v] = u;
                    key[v] = graph[u][v];
                }
            }
        }

        return parent;
    }

    // Function to find the vertex with the maximum key value
    /**
     * This function finds the vertex with the maximum key value.
     * @param key Array of key values.
     * @param mstSet Boolean array indicating whether a vertex is included in the MST.
     * @param numVertices The number of vertices in the graph.
     * @return The index of the vertex with the maximum key value.
     */
    private int maxKey(int[] key, boolean[] mstSet, int numVertices) {
        int max = Integer.MIN_VALUE, maxIndex = -1;

        for (int v = 0; v < numVertices; v++) {
            if (!mstSet[v] && key[v] > max) {
                max = key[v];
                maxIndex = v;
            }
        }

        return maxIndex;
    }

    // Function to find the vertex with the minimum key value
    /**
     * This function finds the vertex with the minimum key value.
     * @param key Array of key values.
     * @param mstSet Boolean array indicating whether a vertex is included in the MST.
     * @param numVertices The number of vertices in the graph.
     * @return The index of the vertex with the minimum key value.
     */
    private int minKey(int[] key, boolean[] mstSet, int numVertices) {
        int min = Integer.MAX_VALUE, minIndex = -1;

        for (int v = 0; v < numVertices; v++) {
            if (!mstSet[v] && key[v] < min) {
                min = key[v];
                minIndex = v;
            }
        }

        return minIndex;
    }

    // Function to find an Eulerian cycle in a directed graph
    /**
     * This function finds an Eulerian cycle in a directed graph.
     * @param directedGraph The adjacency list representing the directed graph.
     * @param numVertices The number of vertices in the graph.
     * @return A list of vertices representing the Eulerian cycle.
     */
    public List<Integer> findEulerianCycle(List<List<Integer>> directedGraph, int numVertices) {
        List<Integer> cycle = new ArrayList<>();
        Stack<Integer> stack = new Stack<>();
        int[] currentEdge = new int[numVertices];
        stack.push(0);

        while (!stack.isEmpty()) {
            int node = stack.peek();
            if (currentEdge[node] < directedGraph.get(node).size()) {
                stack.push(directedGraph.get(node).get(currentEdge[node]++));
            } else {
                cycle.add(stack.pop());
            }
        }

        Collections.reverse(cycle);
        return cycle;
    }

    // Function to check if a graph is connected
    /**
     * This function checks if the graph is connected.
     * @param numVertices The number of vertices in the graph.
     * @param graph The adjacency matrix representing the graph.
     * @return true if the graph is connected, false otherwise.
     */
    private boolean isConnected(int numVertices, int[][] graph) {
        boolean[] visited = new boolean[numVertices];
        dfs(0, visited, graph);

        for (boolean v : visited) {
            if (!v) {
                return false;
            }
        }
        return true;
    }

    // Depth-First Search (DFS) helper function
    /**
     * This helper function performs a Depth-First Search (DFS) on the graph.
     * @param v The current vertex.
     * @param visited Boolean array indicating whether a vertex has been visited.
     * @param graph Adjacency matrix representing the graph.
     */
    private void dfs(int v, boolean[] visited, int[][] graph) {
        visited[v] = true;
        for (int i = 0; i < graph.length; i++) {
            if (graph[v][i] != 0 && !visited[i]) {
                dfs(i, visited, graph);
            }
        }
    }

    /**
    * This function returns the weight of the last calculated Hamiltonian cycle.
    * @return Weight of the last Hamiltonian cycle.
    */
    public int getLastWeight() {
        return lastWeight;
    }

    /**
    * This function returns the last calculated Hamiltonian path.
    * @return List of vertices representing the last Hamiltonian path.
    */
    public List<Integer> getLastPath() {
        return lastPath;
    }
}