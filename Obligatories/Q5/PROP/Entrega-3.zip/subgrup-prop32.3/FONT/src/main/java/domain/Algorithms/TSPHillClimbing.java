package domain.Algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Implements the hill Climbing algorithm to solve the Traveling Salesman
 * Problem (TSP)
 * 
 * @author David Morais
 */
public class TSPHillClimbing {
  /**
   * Matrix of relations between products
   */
  private final int[][] relations;
  /**
   * Number of products
   */
  private final int numberOfProducts;
  /**
   * Number of spaces in the rack
   */
  private final int rackSpaces;
  /**
   * Best solution found
   */
  private List<Integer> bestSolution;
  /**
   * Cost of the best solution found
   */
  private int bestCost;
  /**
   * Maximum number of restarts
   */
  private final int maxRestarts;
  /**
   * Maximum number of iterations without improvement
   */
  private final int maxIterationsWithoutImprovement;

  /**
   * Constructor of the class TSPHillClimbing
   *
   * @param relations                       matrix of relations between products
   * @param maxRestarts                     maximum number of restarts
   * @param rackSpaces                      number of spaces in the rack
   * @param maxIterationsWithoutImprovement maximum number of iterations without
   *                                        improvement
   */
  public TSPHillClimbing(int[][] relations, int maxRestarts, int rackSpaces, int maxIterationsWithoutImprovement) {
    this.relations = relations;
    this.numberOfProducts = relations.length;
    this.maxRestarts = maxRestarts;
    this.rackSpaces = rackSpaces;
    this.maxIterationsWithoutImprovement = maxIterationsWithoutImprovement;
    this.bestSolution = new ArrayList<>();
    this.bestCost = Integer.MAX_VALUE;
  }

  /**
   * Constructor of the class TSPHillClimbing
   *
   * @param relations  matrix of relations between products
   * @param rackSpaces number of spaces in the rack
   * @param iterated   true if the algorithm is used for iterated local search,
   *                   false otherwise
   */
  public TSPHillClimbing(int[][] relations, int rackSpaces, boolean iterated) {
    this.relations = relations;
    this.numberOfProducts = relations.length;
    if (iterated) {
      this.maxRestarts = 1;
      this.maxIterationsWithoutImprovement = 1;
    } else {
      this.maxRestarts = Math.max(relations.length / 3, 1);
      this.maxIterationsWithoutImprovement = 10;

    }
    this.rackSpaces = rackSpaces;
    this.bestSolution = new ArrayList<>();
    this.bestCost = Integer.MAX_VALUE;
  }

  /**
   * Establece una solución inicial para comenzar la búsqueda local
   *
   * @param initialSolution Solución inicial
   */
  public void setInitialSolution(List<Integer> initialSolution) {
    this.bestSolution = new ArrayList<>(initialSolution);
    this.bestCost = calculateCostMin(initialSolution); // O calculateCostMax según corresponda
  }

  /**
   * Generate an initial solution
   *
   * @return list of products
   */
  private List<Integer> generateInitialSolution() {
    List<Integer> solution = new ArrayList<>();
    for (int i = 0; i < numberOfProducts; i++) {
      solution.add(i);
    }
    Collections.shuffle(solution);
    int toIndex = Math.min(rackSpaces, solution.size());
    return new ArrayList<>(solution.subList(0, toIndex));
  }

  /**
   * Calculate the cost of a solution (minimize the cost)
   *
   * @param solution list of products
   * @return cost of the solution
   */
  private int calculateCostMax(List<Integer> solution) {
    if (rackSpaces == 0) {
      return Integer.MIN_VALUE;
    }
    int cost = 0;
    // Calcular la distancia total entre los productos en la solución
    for (int i = 0; i < solution.size() - 1; i++) {
      int distance = relations[solution.get(i)][solution.get(i + 1)];
      if (distance == -1) {
        return Integer.MIN_VALUE; // Ruta inválida
      }
      cost += distance;
    }

    // Verificar si se debe sumar la distancia de retorno
    if (solution.size() == rackSpaces) {
      // Determinar el último espacio en el rack
      int lastSpace = rackSpaces - 1;
      int returnDistance = relations[solution.get(lastSpace)][solution.getFirst()];

      if (returnDistance == -1) {
        return 0; // Ruta inválida
      }
      cost += returnDistance;
    }
    return cost;
  }

  /**
   * Calculate the cost of a solution (minimize the cost)
   *
   * @param solution list of products
   * @return cost of the solution
   */
  private int calculateCostMin(List<Integer> solution) {
    if (rackSpaces == 0) {
      return Integer.MAX_VALUE;
    }

    int cost = 0;
    for (int i = 0; i < solution.size() - 1; i++) {
      int distance = relations[solution.get(i)][solution.get(i + 1)];
      if (distance == -1) {
        return Integer.MAX_VALUE; // Invalid route
      }
      cost += distance;
    }
    // Determine the last space in the rack
    // If the number of products is less than the number of spaces in the rack, the
    // last space is the last product
    int returnDistance = relations[solution.getLast()][solution.getFirst()];
    if (returnDistance == -1) {
      return Integer.MAX_VALUE; // Invalid route
    }
    cost += returnDistance;
    return cost;
  }

  /**
   * Get a neighbor of a solution with 2-Opt Swap
   *
   * @param solution list of products
   * @return neighbor of the solution
   */
  private List<Integer> getBestNeighborMin(List<Integer> solution) {
    List<Integer> bestNeighbor = null;
    int bestNeighborCost = Integer.MAX_VALUE; // To minimize Integer.MAX_VALUE, to maximize 0

    // Explore all neighbors using 2-Opt Swap
    for (int i = 0; i < rackSpaces - 1; i++) {
      for (int j = i + 1; j < rackSpaces; j++) {
        List<Integer> neighbor = new ArrayList<>(solution);
        // Perform 2-Opt Swap
        Collections.reverse(neighbor.subList(i, j + 1));
        int neighborCost = calculateCostMin(neighbor);
        if (neighborCost < bestNeighborCost) { // To minimize '<', to maximize '>'
          bestNeighborCost = neighborCost;
          bestNeighbor = neighbor;
        }
      }
    }
    return bestNeighbor;
  }

  /**
   * Get a neighbor of a solution with 2-Opt Swap
   *
   * @param solution list of products
   * @return neighbor of the solution
   */
  private List<Integer> getBestNeighborMax(List<Integer> solution) {
    List<Integer> bestNeighbor = null;
    int bestNeighborCost = Integer.MIN_VALUE; // Inicializar a 0 para maximizar

    int limit = Math.min(rackSpaces, solution.size());
    // Explorar todos los vecinos usando 2-Opt Swap
    for (int i = 0; i < limit - 1; i++) {
      for (int j = i + 1; j < limit; j++) {
        List<Integer> neighbor = new ArrayList<>(solution);
        // Realizar 2-Opt Swap
        Collections.reverse(neighbor.subList(i, j + 1));
        int neighborCost = calculateCostMax(neighbor);
        if (neighborCost > bestNeighborCost) { // Para maximizar '>'
          bestNeighborCost = neighborCost;
          bestNeighbor = neighbor;
        }
      }
    }

    // Intercambiar un producto dentro del subconjunto con uno fuera
    for (int i = 0; i < limit; i++) {
      for (int j = 0; j < numberOfProducts; j++) {
        if (!solution.contains(j)) {
          List<Integer> neighbor = new ArrayList<>(solution);
          neighbor.set(i, j); // Reemplazar el producto en la posición i con j
          int neighborCost = calculateCostMax(neighbor);
          if (neighborCost > bestNeighborCost) {
            bestNeighborCost = neighborCost;
            bestNeighbor = neighbor;
          }
        }
      }
    }
    return bestNeighbor;
  }

  /**
   * Hill climbing algorithm to minimize the cost
   */
  private void hillClimbingMin() {
    List<Integer> currentSolution = generateInitialSolution();
    int currentCost = calculateCostMin(currentSolution);
    boolean improvement = true;
    int iterationsWithoutImprovement = 0;

    while (improvement && iterationsWithoutImprovement < maxIterationsWithoutImprovement) {
      List<Integer> neighbor = getBestNeighborMin(currentSolution);
      if (neighbor == null) {
        break;
      }
      int neighborCost = calculateCostMin(neighbor);
      if (neighborCost < currentCost) { // Para minimizar '<', para maximizar '>'
        currentSolution = neighbor;
        currentCost = neighborCost;
        improvement = true;
        iterationsWithoutImprovement = 0;
      } else {
        improvement = false;
        iterationsWithoutImprovement++;
      }
    }

    if (currentCost < bestCost) { // Para minimizar '<', para maximizar '>'
      bestSolution = currentSolution;
      bestCost = currentCost;
    }
  }

  /**
   * Hill climbing algorithm to maximize the cost
   */
  private void hillClimbingMax() {
    List<Integer> currentSolution = generateInitialSolution();
    int currentCost = calculateCostMax(currentSolution);
    boolean improvement = true;
    int iterationsWithoutImprovement = 0;

    while (improvement && iterationsWithoutImprovement < maxIterationsWithoutImprovement) {
      List<Integer> neighbor = getBestNeighborMax(currentSolution);
      if (neighbor == null) {
        break;
      }
      int neighborCost = calculateCostMax(neighbor);
      if (neighborCost > currentCost) { // Para maximizar '>'
        currentSolution = neighbor;
        currentCost = neighborCost;
        improvement = true;
        iterationsWithoutImprovement = 0;
      } else {
        improvement = false;
        iterationsWithoutImprovement++;
      }
    }

    if (currentCost > bestCost && currentCost != Integer.MIN_VALUE) { // Para maximizar '>'
      bestSolution = currentSolution;
      bestCost = currentCost;
    }
  }

  /**
   * Solve the problem using the hill climbing algorithm to minimize the cost
   */
  public void solveMin() {
    for (int i = 0; i < maxRestarts; i++) {
      hillClimbingMin();
    }
  }

  /**
   * Solve the problem using the hill climbing algorithm to maximize the cost
   *
   * @return the best cost found, or Integer.MIN_VALUE if no valid solution is
   *         found
   */
  public int solveMax() {
    bestCost = Integer.MIN_VALUE;
    for (int i = 0; i < maxRestarts; i++) {
      hillClimbingMax();
    }
    return bestCost;
  }

  /**
   * Get the solution of the problem
   *
   * @return list of cities
   */
  public List<Integer> getSolution() {
    return bestSolution;
  }

  /**
   * Get the cost of the solution
   *
   * @return cost of the solution
   */
  public int getCost() {
    return bestCost;
  }
}
