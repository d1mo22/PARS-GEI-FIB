package domain.Controllers;

import java.util.HashMap;

import domain.Product.Product;

/**
 * Controller for the Product class.
 * @author Edgar Bosque
 */
public class ProductController {
    /**
     * Product object to be used in the controller.
     */
    private Product product;

    /**
     * Constructor for the ProductController.
     */
    public ProductController() {
        product = null;
    }

    /**
     * Checks if the product has been set.
     *
     * @return True if the product has not been set, false otherwise.
     */
    public boolean productNotSet() {
        return product == null;
      }

    /**
     * Creates a new instance of Product.
     *
     * @param name Name of the product.
     * @param listName Name of the list the product belongs to.
     * @param username Username associated with the product.
     * @return New Product object.
     * @throws IllegalArgumentException if the parameters are invalid.
     */
    public Product createProduct(String name, String listName, String username) {
        if (name == null || listName == null || username == null) {
            throw new IllegalArgumentException("Name, listName, and username cannot be null");
        } else if (name.isEmpty() || listName.isEmpty() || username.isEmpty()) {
            throw new IllegalArgumentException("Name, listName, and username cannot be empty");
        }
        return new Product(name, listName, username);
    }

    /**
     * Adds a similarity between two products.
     *
     * @param product2    Name of the product to add a similarity with.
     * @param similarity  Similarity value between 0 and 100.
     * @throws IllegalArgumentException if the product has not been set.
     * @throws IllegalArgumentException if the similarity is invalid.
     * @throws IllegalArgumentException if the similarity already exists.
     */
    public void addSimilarity(String product2, int similarity) {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        if (similarity < 1 || similarity > 100) {
            throw new IllegalArgumentException("Similarity must be between 1 and 100");
        }
        if (!product.addSimilarity(product2, similarity)) {
            throw new IllegalArgumentException("Similarity already exists");
        }
    }

    /**
     * Removes the similarity value for a given product name.
     *
     * @param productName The name of the product to remove the similarity for.
     */
    public void removeSimilarity(String productName) {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        if (!product.removeSimilarity(productName)) {
            throw new IllegalArgumentException("Similarity does not exist");
        }
    }

    /**
     * Edits the similarity value for a given product name.
     *
     * @param productName Name of the product to edit the similarity for.
     * @param similarity New similarity value.
     */
    public void editSimilarity(String productName, int similarity) {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        product.removeSimilarity(productName);
        product.addSimilarity(productName, similarity);
    }

    /**
     * Adds a restriction between two products.
     *
     * @param productName Name of the product to add a restriction with.
     * @throws IllegalArgumentException if the product has not been set.
     * @throws IllegalArgumentException if the restriction already exists.
     */
    public void addRestriction(String productName) {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        if(!product.addRestriction(productName)) {
            throw new IllegalArgumentException("Restriction already exists");
        }
    }

    /**
     * Removes the restriction value for a given product name.
     *
     * @param productName The name of the product to remove the restriction for.
     */
    public void removeRestriction(String productName) {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        if (!product.removeRestriction(productName)) {
            throw new IllegalArgumentException("Restriction does not exist");
        }
    }

    /**
     * Changes the list name of the product.
     * @param listName New list name.
     * @throws IllegalArgumentException if there is no product set.
     * @throws IllegalArgumentException if the list name is invalid.
     */
    public void changeListName(String listName) {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        if (listName == null || listName == "") {
            throw new IllegalArgumentException("The list name cannot be null or empty");
        }
        product.setListName(listName);
    }

    /** Getter for the similarity with a product
     *
     * @param productName the product name
     * @return the similarity with the product
     */
    public int getSimilarity(String productName) {
        return product.getSimilarity(productName);
    }

    /**
     * Getter for the product name
     *
     * @return the product name
     */
    public String getName() {
        return product.getName();
    }

    /**
     * Getter for the list name
     *
     * @return the list name
     */
    public String getListName() {
        return product.getListName();
    }

    /** Getter for the similarities
     *
     * @return the similarities
     * @throws IllegalArgumentException if the product has not been set
     */
    public HashMap<String, Integer> getSimilarities() {
        if (productNotSet()) {
            throw new IllegalArgumentException("Product has not been set");
        }
        return product.getSimilarities();
    }

    /**
     * Returns the product being used in the controller.
     *
     * @return Product being used.
     * @throws IllegalArgumentException if the product has not been set.
     */
    public Product getProduct() {
        if (product == null) {
            throw new IllegalArgumentException("Product has not been set");
        }
        return product;
    }

    /**
     * Sets the product to be used in the controller.
     *
     * @param product Product to be set.
     */
    public void setProduct(Product product) {
        this.product = product;
    }

}
