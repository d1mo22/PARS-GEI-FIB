package domain.Controllers;

import domain.User.User;

/**
 * Controller for the User class.
 *
 * @author David Morais
 */
public class UserController {
    /**
     * User object to be used in the controller.
     */
    private User user;

    /**
     * Constructor for the UserController class.
     */
    public UserController() {
        user = null;
    }

    /**
     * Checks if the user has been set.
     * 
     * @return True if the user has not been set, false otherwise.
     */
    public boolean userNotSet() {
        return user == null;
    }

    /**
     * Creates a new instance of User.
     * 
     * @param username Username.
     * @param password Password.
     * @return New User object.
     * @throws IllegalArgumentException if the parameters are invalid.
     */
    public User createUser(String username, String password) {
        if (username == null || password == null) {
            throw new IllegalArgumentException("Username and password cannot be null");
        } else if (username.isEmpty() || password.isEmpty()) {
            throw new IllegalArgumentException("Username and password cannot be empty");
        }
        user = new User(username, password);
        return user;
    }

    /**
     * Changes the user's password.
     * 
     * @param newPassword The new password.
     * @throws IllegalArgumentException if the user has not been set.
     */
    public void changePassword(String newPassword) {
        if (userNotSet()) {
            throw new IllegalArgumentException("User has not been set");
        }
        user.setPassword(newPassword);
    }

    /**
     * Verifies if the input password matches the user's password.
     * 
     * @param password The password to verify.
     * @return True if the password matches, false otherwise.
     * @throws IllegalArgumentException if the user has not been set.
     */
    public boolean verifyPassword(String password) {
        if (userNotSet()) {
            throw new IllegalArgumentException("User has not been set");
        }
        return user.verifyPassword(password);
    }

    /**
     * Removes the active user
     * 
     * @throws IllegalArgumentException if the user has not been set.
     */
    public void removeActiveUser() {
        if (userNotSet()) {
            throw new IllegalArgumentException("User has not been set");
        }
        user = null;
    }

    /**
     * Gets the active user
     * 
     * @return The active user
     * @throws IllegalArgumentException if the user has not been set.
     */
    public User getActiveUser() {
        if (userNotSet()) {
            throw new IllegalArgumentException("User has not been set");
        }
        return user;
    }

    /**
     * Sets the active user
     * 
     * @param user The user to set as active.
     */
    public void setActiveUser(User user) {
        this.user = user;
    }

}
