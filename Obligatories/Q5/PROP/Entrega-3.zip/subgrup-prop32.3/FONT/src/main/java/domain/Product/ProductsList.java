// src/main/java/domain/Product/ProductsList.java
package domain.Product;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;
import java.io.Reader;
import java.io.FileReader;

/**
 * Represents a list of products in the system.
 * 
 * @author Edgar Bosque
 */
public class ProductsList {
    /**
     * Name of the list
     */
    private String name;
    /**
     * Name of the user that owns the list
     */
    private final String user;
    /**
     * List of products
     */
    private List<Product> products;

    /**
     * Constructor for the product list.
     *
     * @param name Name of the list
     * @param user Name of the user that owns the list
     */
    public ProductsList(String name, String user) {
        this.name = name;
        this.user = user;
        this.products = new ArrayList<>();
    }

    /**
     * Getter for the name
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for the user
     *
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * Setter for the name
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Add a product to the list
     * 
     * @param product Product to add
     */
    public void addProduct(Product product) {
        products.add(product);
    }

    /**
     * Remove a product from the list
     * 
     * @param productName Name of the product to remove
     */
    public void removeProduct(String productName) {
        int index = -1;
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getName().equals(productName) &&
                    products.get(i).getListName().equals(this.name)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            products.remove(index);
        }
    }

    /**
     * Clear all products from the list
     */
    public void clearProducts() {
        products.clear();
    }

    /**
     * Get the index of a product by name
     * 
     * @param productName Name of the product to get the index of
     * @return the index of the product
     */
    public Product getProductByName(String productName) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getName().equals(productName)) {
                return products.get(i);
            }
        }
        return null; // Return -1 if product is not found
    }

    // Getter for products
    /**
     * Getter for the products
     *
     * @return the products
     */
    public List<Product> getProducts() {
        return products;
    }

    /**
     * Getter for a product by index
     *
     * @param index the index of the product
     * @return the product
     */
    public Product getProductByIndex(int index) {
        return products.get(index);
    }

    /**
     * Getter for the list size
     *
     * @return the size of the list
     */
    public int size() {
        return products.size();
    }

    /**
     * Exports the product list to a JSON file
     * It is saved in the same directory with the name of the list
     * 
     * @param path Path to save the JSON file
     */
    public void export(String path) {
        try (FileWriter writer = new FileWriter(path + ".json")) {
            Gson gson = new Gson();
            gson.toJson(this.products, writer);
            System.out.println("List successfully exported to " + path);
        } catch (IOException e) {
            throw new RuntimeException("Error exporting the list: " + e.getMessage());
        }
    }

    /**
     * Imports the product list from a JSON file
     * 
     * @param path Path to the JSON file
     */
    public void importList(String path) {
        try (Reader reader = new FileReader(path)) {
            System.out.println("Importing list from " + path);
            Gson gson = new Gson();
            Type listType = new TypeToken<List<Product>>() {
            }.getType();
            List<Product> productsList = gson.fromJson(reader, listType);
            this.products = productsList;
            System.out.println("List successfully imported from " + path);
        } catch (IOException e) {
            throw new IllegalArgumentException("Error importing the list: " + e.getMessage());
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Error importing the list: " + e.getMessage());
        }
    }
}