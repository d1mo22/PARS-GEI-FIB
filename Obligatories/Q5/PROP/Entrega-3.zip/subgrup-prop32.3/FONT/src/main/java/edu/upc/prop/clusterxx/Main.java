package edu.upc.prop.clusterxx;

import presentation.Controllers.PresentationController;

/**
 * Main class for the application.
 */
public class Main {
  /**
   * Constructor for the Main class.
   */
  public Main() {
  }

  /**
   * Main method for the application.
   *
   * @param args Command line arguments.
   */
  public static void main(String[] args) {
    javax.swing.SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        PresentationController presentationController = new PresentationController();
        presentationController.initPresentation();
      }
    });
  }
}