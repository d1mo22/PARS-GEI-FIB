package presentation.Controllers;

import domain.Controllers.DomainController;
import java.util.HashMap;
import presentation.Views.LoginView;
import presentation.Views.MainView;
import presentation.Views.ListView;
import java.util.HashSet;
import java.util.List;
import presentation.Views.ProductView;

public class PresentationController {
    private DomainController domainController;
    private LoginView loginView;
    private MainView mainView;
    private ListView listView;
    private ProductView prodView;
    private int selectedAlgorithm;

    /**
     * Constructor for PresentationController class
     */
    public PresentationController() {
        domainController = new DomainController();
        loginView = new LoginView(this);
    }

    /**
     * Initializes the presentation by setting the login view visible.
     */
    public void initPresentation() {
        loginView.setVisible(true);
    }
    
    /**
     * Synchronizes the login view to the main view.
     */
    public void syncronizeLoginToMain() {
        loginView.setVisible(false);
        if (mainView == null) {
            mainView = new MainView(this);
        }
        mainView.loadCurrentUser();
        mainView.setLocation(loginView.getLocation());
        mainView.setVisible(true);
    }
    
    /**
     * Synchronizes the main view to the login view.
     */
    public void syncronizeMainToLogin() {
        mainView.setVisible(false);
        loginView.setLocation(mainView.getLocation());
        loginView.setVisible(true);
        loginView.reset();
    }
    
    /**
     * Synchronizes the main view to the lists view.
     */
    public void syncronizeMainToLists() {
        if (listView == null) {
            listView = new ListView(this);
        }
        mainView.setEnabled(false);
        listView.loadUserLists();
        listView.setVisible(true);
    }
    
    public void syncronizeMainToProd() {
        if (prodView == null) {
            prodView = new ProductView(this);
        }
        mainView.setEnabled(false);
        prodView.loadCurrentProducts();
        prodView.setVisible(true);
    }
    
    /**
     * Synchronizes the lists view to the main view.
     */
    public void syncronizeListsToMain() {
        listView.setVisible(false);
        mainView.reloadLists();
        mainView.setEnabled(true);
    }
    
    public void syncronizeProdToMain() {
        prodView.setVisible(false);
        mainView.loadCurrentList();
        mainView.setEnabled(true);
    }
    
    /**
     * Creates a new user with the specified username and password.
     * 
     * @param username The username of the new user.
     * @param password The password of the new user.
     */
    public void createUser(String username, String password) {
        domainController.createUser(username, password);
    }
    
    /**
     * Logs out the current user.
     */
    public void logoutUser() {
        domainController.logoutUser();
    }

    /**
     * Logs in a user with the specified username and password.
     * 
     * @param username The username of the user.
     * @param password The password of the user.
     */
    public void loginUser(String username, String password) {
        domainController.loginUser(username, password);
    }

    /**
     * Changes the password of the specified user.
     * 
     * @param username The username of the user.
     * @param password The new password of the user.
     */
    public void changeUserPassword(String username, String password) {
        domainController.changeUserPassword(username, password);
    }
    
    /**
     * Gets the active product lists for the current user.
     * 
     * @return A set of active product lists.
     */
    public HashSet<String> getActiveUserProductLists() {
        return domainController.getActiveUserProductLists();
    }
    
    /**
     * Creates an empty products list with the specified name and sets it as active.
     * 
     * @param listName The name of the new products list.
     */
    public void createEmptyProductsList(String listName) {
        domainController.addProductList(listName);
        domainController.setActiveList(listName);
    }
    
    /**
     * Removes the products list with the specified name.
     * 
     * @param listName The name of the products list to remove.
     */
    public void removeProductsList(String listName) {
        domainController.removeProductList(listName);
    }
    
    /**
     * Changes the name of a products list.
     * 
     * @param currentName The current name of the products list.
     * @param newName The new name of the products list.
     */
    public void changeListName(String currentName, String newName) {
        domainController.modifyProductListName(currentName, newName);
    }
    
    /**
     * Imports a products list from a file and sets it as active.
     * 
     * @param listName The name of the products list.
     * @param path The path to the file.
     */
    public void importList(String listName, String path) {
        domainController.importList(listName, path);
        domainController.setActiveList(listName);
    }
    
    /**
     * Exports a products list to a file.
     * 
     * @param listName The name of the products list.
     * @param path The path to the file.
     */
    public void exportList(String listName, String path) {
        domainController.exportList(listName, path);
    }
    
    /**
     * Sets the active products list.
     * 
     * @param listName The name of the products list to set as active.
     */
    public void setActiveProductsList(String listName) {
        domainController.setActiveList(listName);
    }
    
    /**
     * Gets the products in the active list.
     * 
     * @return A list of products in the active list.
     */
    public List<String> getActiveListProducts() {
        return domainController.getActiveListProducts();
    }
    
    /**
     * Adds a product to the active list.
     * 
     * @param prodName The name of the product to add.
     */
    public boolean addProduct(String prodName) {
        return domainController.addProduct(prodName);
    }
    
    /**
     * Removes a product from the active list.
     * 
     * @param prodName The name of the product to remove.
     */
    public void removeProduct(String prodName) {
        domainController.removeProduct(prodName);
    }

    /**
     * Sets the selected algorithm for organizing the rack.
     * 
     * @param alg The algorithm to be selected (1 for Backtracking, 2 for Hill Climbing, 3 for 2-Approximation, 4 for Iterated Local Search).
     */
    public void setSelectedAlgorithm(int alg) {
        selectedAlgorithm = alg;
    }
    
    public int getSelectedAlgorithm() {
        return selectedAlgorithm;
    }
    
    /**
     * Executes the selected algorithm to organize the rack.
     */
    public void executeAlgorithm() {
        if (selectedAlgorithm == 1) domainController.solveBacktracking();
        else if (selectedAlgorithm == 2) domainController.solveHillClimbing();
        else if (selectedAlgorithm == 3) domainController.solveAproximation();
        else domainController.solveIteratedLocalSearch();
    }

    /**
     * Retrieves the current rack matrix.
     * 
     * @return A 2D array representing the rack matrix.
     */
    public String[][] getRack() {
        return domainController.getRackMatrix();
    }

    /**
     * Creates a new rack with the specified number of rows and columns.
     * 
     * @param rows The number of rows in the rack.
     * @param columns The number of columns in the rack.
     */
    public void createRack(int rows, int columns) {
        domainController.createRack(rows, columns);
    }

    /**
     * Moves a product from one position to another in the rack.
     * 
     * @param row The row of the product to move.
     * @param column The column of the product to move.
     * @param row2 The row to move the product to.
     * @param column2 The column to move the product to.
     */
    public void moveProduct(int row, int column, int row2, int column2) {
        domainController.moveProduct(row, column, row2, column2);
    }
    
    /**
     * Gets product similarities
     * @param productName
     * @return 
     */
    public HashMap<String,Integer> getSimilarities(String productName) {
        return domainController.getProductSimilarities(productName);
    }
    
    /**
     * Adds a similarity value between two products.
     * @param prod1 The first product.
     * @param prod2 The second product.
     * @param simVal The similarity value.
     */
    public void addProductSimilarity(String prod1, String prod2, int simVal) {
        domainController.addProductSimilarity(prod1, prod2, simVal);
    }

    /**
     * Removes the similarity value between two products.
     * @param prod1 The first product.
     * @param prod2 The second product.
     */
    public void removeProductSimilarity(String prod1, String prod2) {
        domainController.removeProductSimilarity(prod1, prod2);
    }

    /**
     * Adds a restriction between two products.
     * @param prod1 The first product.
     * @param prod2 The second product.
     */
    public void addProductRestriction(String prod1, String prod2) {
        domainController.addProductRestriction(prod1, prod2);
    }

    /**
     * Removes the restriction between two products.
     * @param prod1 The first product.
     * @param prod2 The second product.
     */
    public void removeProductRestriction(String prod1, String prod2) {
        domainController.removeProductRestriction(prod1, prod2);
    }
}