/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentation.Views;

import javax.swing.*;

/**
 *
 * @author Sergi Metcalf
 */
public class DialogView {

    // Constructor for DialogView class
    public DialogView() {
    }
    
    /**
     * Sets up and displays a dialog with the specified title, text, buttons, and type.
     * 
     * @param strTitle The title of the dialog.
     * @param strText The text to display in the dialog.
     * @param strButtons The array of button labels.
     * @param iType The type of message to be displayed (0: ERROR, 1: INFORMATION, 2: WARNING, 3: QUESTION, 4: PLAIN).
     * @return The index of the button that was clicked.
     */
    public int setDialog (String strTitle, String strText, String[]strButtons, int iType) {
        int oType = 1;
        switch (iType) {
            case 0: oType = JOptionPane.ERROR_MESSAGE; break;
            case 1: oType = JOptionPane.INFORMATION_MESSAGE; break;
            case 2: oType = JOptionPane.WARNING_MESSAGE; break;
            case 3: oType = JOptionPane.QUESTION_MESSAGE; break;
            case 4: oType = JOptionPane.PLAIN_MESSAGE; break;
        }

        JOptionPane optionPane = new JOptionPane(strText, oType);
        optionPane.setOptions(strButtons);
        JDialog dialogOptionPane = optionPane.createDialog(new JFrame(),strTitle);
        dialogOptionPane.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        dialogOptionPane.pack();
        dialogOptionPane.setVisible(true);

        String vsel = (String) optionPane.getValue();
        int isel;
        for (isel = 0; isel < strButtons.length; isel++) {
            if (strButtons[isel].equals(vsel)) {
                break;
            }
        }
        return isel;
    }
}