/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package presentation.Views;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import presentation.Controllers.PresentationController;
import java.util.HashSet;
import java.util.List;

import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sergi Metcalf, Marc Escribano
 */
public class MainView extends javax.swing.JFrame {
    
    private final PresentationController presentationController;
    private int actualRows, actualColumns;
    private boolean organized;
    
    /**
     * Creates new form MainView
     */
    public MainView(PresentationController presentationController) {
        this.presentationController = presentationController;
        initComponents();
        menuBar = new javax.swing.JMenuBar();
        menuBar.setMinimumSize(new java.awt.Dimension(43, 30));
        menuBar.add(Box.createHorizontalGlue());
        ImageIcon imageIcon = new ImageIcon(getClass().getResource("/Images/user.png"));
        userMenu.setIcon(imageIcon);
        menuBar.add(userMenu);
        setJMenuBar(menuBar);
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e)
            {
                windowOnClose();
            }
        });
    }
    
    /**
     * Method to close the window
     */
    private void windowOnClose() {
        System.exit(0);
    }
    
    /**
     * Makes the view visible
     */
    public void makeVisible() {
        setVisible(true);
    }
    
    /**
     * Loads the current user
     */
    public void loadCurrentUser() {
        HashSet<String> lists;
        
        try {
            lists = presentationController.getActiveUserProductLists();
            listSelectionBox.removeAllItems();
            listSelectionBox.addItem("- Select List -");
            if (!lists.isEmpty()) {
                for (String list : lists) {
                    listSelectionBox.addItem(list);
                } 
                listSelectionBox.setEnabled(true);
            }
            else {
                listSelectionBox.setEnabled(false);
            }
        } catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error retrieving lists", e.getMessage(), buttons, 0);
        }
    }
    
    /**
     * Loads the current list
     */
    public void loadCurrentList() {
        List<String> products;
        
        try {
           products = presentationController.getActiveListProducts();
           
           DefaultListModel model = new DefaultListModel();
           model.clear();
           prodAddButton.setEnabled(true);
           if (!products.isEmpty()) {
               prodRemoveButton.setEnabled(true);
               prodManageButton.setEnabled(true);
               for (String prod : products) {
                   model.addElement(prod);
               }
               prodProdList.setEnabled(true);
           }
           else {
               prodRemoveButton.setEnabled(false);
               prodManageButton.setEnabled(false);
               prodProdList.setEnabled(false);
           }
           prodProdList.setModel(model);
        } catch (IllegalArgumentException e)  {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error retrieving products", e.getMessage(), buttons, 0);
        }
    }
    
    /**
     * Reloads the lists
     */
    public void reloadLists() {
        HashSet<String> lists;
        
        try {
           String selected = (String)listSelectionBox.getSelectedItem();
           lists = presentationController.getActiveUserProductLists();
           listSelectionBox.removeAllItems();
           listSelectionBox.addItem("- Select List -");
           if (!lists.isEmpty()) {
                for (String list : lists) {
                    listSelectionBox.addItem(list);
                } 
                listSelectionBox.setEnabled(true);
                
                if (!lists.contains(selected)) {
                    listSelectionBox.setSelectedIndex(0);
                }
                else {
                    listSelectionBox.setSelectedItem(selected);
                    presentationController.setActiveProductsList(selected);
                    loadCurrentList();
                }
            }
            else {
                listSelectionBox.setEnabled(false);
                prodAddButton.setEnabled(false);
                prodRemoveButton.setEnabled(false);
                prodManageButton.setEnabled(false);
                prodProdList.setEnabled(false);
            }
        } catch (IllegalArgumentException e)  {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error reloading lists", e.getMessage(), buttons, 0);
        }
    }

    /**
     * Method to get a valid integer input
     * @param message
     * @return 
     */
    private int getValidIntInput(String message) {
        String input = JOptionPane.showInputDialog(message);
        if (input == null) return -1;
        else if (input.isBlank()) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Input error", "Input cannot be empty", buttons, 0);
            return -1;
        }
        int value;
        try {
            value = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Input error", "Input must be a number", buttons, 0);
            return -1;
        }
        return value;
    }

    /**
     * Method to actualize the rack
     */
    private void actualizeRack() {
        String[][] rackMatrix = presentationController.getRack();
        DefaultTableModel model = new DefaultTableModel(rackMatrix, new String[rackMatrix[0].length]);
        rackTable.setModel(model);
        for (int i = 0; i < rackMatrix[0].length; i++) {
            rackTable.getColumnModel().getColumn(i).setPreferredWidth(100);
            //rackTable.getColumnModel().getColumn(i).setResizable(false);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        centerPanel = new javax.swing.JPanel();
        rackPanel = new javax.swing.JPanel();
        filler3 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0));
        filler4 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0));
        jScrollPane1 = new javax.swing.JScrollPane();
        rackTable = new javax.swing.JTable();
        buttonsPanel = new javax.swing.JPanel();
        listPanel = new javax.swing.JPanel();
        listListLabel = new javax.swing.JLabel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        listSelectionBox = new javax.swing.JComboBox<>();
        listNewButton = new javax.swing.JButton();
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        listManageButton = new javax.swing.JButton();
        prodPanel = new javax.swing.JPanel();
        prodScrollPane = new javax.swing.JScrollPane();
        prodProdList = new javax.swing.JList<>();
        prodProductsLabel = new javax.swing.JLabel();
        prodAddButton = new javax.swing.JButton();
        prodRemoveButton = new javax.swing.JButton();
        prodManageButton = new javax.swing.JButton();
        orgPanel = new javax.swing.JPanel();
        orgAlgotithmLable = new javax.swing.JLabel();
        filler5 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        createRackButton = new javax.swing.JButton();
        orgOrganizeButton = new javax.swing.JButton();
        orgAlgorithmBox = new javax.swing.JComboBox<>();
        orgMoveButton = new javax.swing.JButton();
        filler7 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0));
        jLabel1 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        userMenu = new javax.swing.JMenu();
        userLogoutItem = new javax.swing.JMenuItem();
        userExitItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CerebroComercial");
        setMinimumSize(new java.awt.Dimension(1180, 700));
        setSize(new java.awt.Dimension(1200, 800));

        centerPanel.setLayout(new java.awt.GridLayout(1, 2));

        rackPanel.setLayout(new java.awt.BorderLayout());
        rackPanel.add(filler3, java.awt.BorderLayout.LINE_END);
        rackPanel.add(filler4, java.awt.BorderLayout.LINE_START);

        rackTable.setAutoCreateRowSorter(true);
        rackTable.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        rackTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        rackTable.setToolTipText("");
        rackTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        rackTable.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        rackTable.setEnabled(false);
        rackTable.setRowHeight(40);
        rackTable.setRowSelectionAllowed(false);
        rackTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(rackTable);

        rackPanel.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        centerPanel.add(rackPanel);

        listPanel.setLayout(new java.awt.GridLayout(3, 2));

        listListLabel.setText("Current list:");
        listPanel.add(listListLabel);
        listPanel.add(filler1);

        listSelectionBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Select List -" }));
        listSelectionBox.setEnabled(false);
        listSelectionBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listSelectionBoxActionPerformed(evt);
            }
        });
        listPanel.add(listSelectionBox);

        listNewButton.setBackground(new java.awt.Color(51, 153, 255));
        listNewButton.setText("New List");
        listNewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listNewButtonActionPerformed(evt);
            }
        });
        listPanel.add(listNewButton);
        listPanel.add(filler2);

        listManageButton.setBackground(new java.awt.Color(153, 153, 153));
        listManageButton.setText("Manage Lists");
        listManageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listManageButtonActionPerformed(evt);
            }
        });
        listPanel.add(listManageButton);

        prodProdList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        prodProdList.setEnabled(false);
        prodScrollPane.setViewportView(prodProdList);

        prodProductsLabel.setText("Products in list:");

        prodAddButton.setBackground(new java.awt.Color(51, 153, 255));
        prodAddButton.setText("Add Product");
        prodAddButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        prodAddButton.setEnabled(false);
        prodAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prodAddButtonActionPerformed(evt);
            }
        });

        prodRemoveButton.setBackground(new java.awt.Color(255, 102, 51));
        prodRemoveButton.setText("Remove Product");
        prodRemoveButton.setEnabled(false);
        prodRemoveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prodRemoveButtonActionPerformed(evt);
            }
        });

        prodManageButton.setBackground(new java.awt.Color(153, 153, 153));
        prodManageButton.setText("Manage Products");
        prodManageButton.setEnabled(false);
        prodManageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prodManageButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout prodPanelLayout = new javax.swing.GroupLayout(prodPanel);
        prodPanel.setLayout(prodPanelLayout);
        prodPanelLayout.setHorizontalGroup(
            prodPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(prodPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(prodPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(prodPanelLayout.createSequentialGroup()
                        .addComponent(prodProductsLabel)
                        .addContainerGap(472, Short.MAX_VALUE))
                    .addGroup(prodPanelLayout.createSequentialGroup()
                        .addComponent(prodScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addGroup(prodPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(prodAddButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(prodRemoveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(prodManageButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
        );
        prodPanelLayout.setVerticalGroup(
            prodPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, prodPanelLayout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addComponent(prodProductsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(prodPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(prodScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(prodPanelLayout.createSequentialGroup()
                        .addComponent(prodAddButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(prodRemoveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(prodManageButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(19, 19, 19))
        );

        orgPanel.setLayout(new java.awt.GridLayout(3, 2));

        orgAlgotithmLable.setText("Organization Algorithm:");
        orgPanel.add(orgAlgotithmLable);
        orgPanel.add(filler5);

        createRackButton.setBackground(new java.awt.Color(51, 153, 255));
        createRackButton.setText("Create Rack");
        createRackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createRackButtonActionPerformed(evt);
            }
        });
        orgPanel.add(createRackButton);

        orgOrganizeButton.setBackground(new java.awt.Color(51, 153, 255));
        orgOrganizeButton.setText("Organize Rack");
        orgOrganizeButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        orgOrganizeButton.setEnabled(false);
        orgOrganizeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orgOrganizeButtonActionPerformed(evt);
            }
        });
        orgPanel.add(orgOrganizeButton);

        orgAlgorithmBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Select Algorithm -", "Backtracking", "Hill Climbing", "2-Approximation", "Iterated Local Search" }));
        orgAlgorithmBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orgAlgorithmBoxActionPerformed(evt);
            }
        });
        orgPanel.add(orgAlgorithmBox);

        orgMoveButton.setBackground(new java.awt.Color(153, 153, 153));
        orgMoveButton.setText("Move Product");
        orgMoveButton.setEnabled(false);
        orgMoveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orgMoveButtonActionPerformed(evt);
            }
        });
        orgPanel.add(orgMoveButton);

        javax.swing.GroupLayout buttonsPanelLayout = new javax.swing.GroupLayout(buttonsPanel);
        buttonsPanel.setLayout(buttonsPanelLayout);
        buttonsPanelLayout.setHorizontalGroup(
            buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(orgPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 559, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, buttonsPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(listPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 559, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(buttonsPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(prodPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        buttonsPanelLayout.setVerticalGroup(
            buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, buttonsPanelLayout.createSequentialGroup()
                .addContainerGap(391, Short.MAX_VALUE)
                .addComponent(orgPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, buttonsPanelLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(listPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(392, Short.MAX_VALUE)))
            .addGroup(buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, buttonsPanelLayout.createSequentialGroup()
                    .addContainerGap(153, Short.MAX_VALUE)
                    .addComponent(prodPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(133, Short.MAX_VALUE)))
        );

        centerPanel.add(buttonsPanel);

        jLabel1.setText(" Rack:");

        menuBar.setMinimumSize(new java.awt.Dimension(43, 30));

        userMenu.setText("User");
        userMenu.setFont(new java.awt.Font("Liberation Sans", 1, 13)); // NOI18N
        userMenu.setRequestFocusEnabled(false);
        userMenu.setRolloverEnabled(false);

        userLogoutItem.setText("Log Out");
        userLogoutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userLogoutItemActionPerformed(evt);
            }
        });
        userMenu.add(userLogoutItem);

        userExitItem.setText("Exit");
        userExitItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userExitItemActionPerformed(evt);
            }
        });
        userMenu.add(userExitItem);

        menuBar.add(userMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(centerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(centerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Action performed when the new list button is clicked.
     * Prompts the user to choose between creating an empty list or importing a list.
     * Executes the chosen action.
     * @param evt The action event.
     */
    private void listNewButtonActionPerformed(java.awt.event.ActionEvent evt) {
        // Create options for the dialog
        String[] options = {"Create Empty List", "Import List"};
        int choice = JOptionPane.showOptionDialog(this,
                "Do you want to create an empty list or import a list?",
                "New List",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (choice == JOptionPane.YES_OPTION) {
            // Create empty list
            String listName = JOptionPane.showInputDialog(this, "Enter the name of the new list:");
            if (listName != null && !listName.trim().isEmpty()) {
                try {
                    presentationController.createEmptyProductsList(listName);
                    if (!listSelectionBox.isEnabled()) {
                        listSelectionBox.setEnabled(true);
                    }
                    listSelectionBox.addItem(listName);
                    listSelectionBox.setSelectedItem(listName);
                    loadCurrentList();
                } catch (IllegalArgumentException e) {
                    DialogView dialog = new DialogView();
                    String[] buttons = {"OK"};
                    dialog.setDialog("Error creating list", e.getMessage(), buttons, 0);
                }
            }
        } else if (choice == JOptionPane.NO_OPTION) {
            // Import list
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setAcceptAllFileFilterUsed(false); // Disable "All files" option
            fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
                @Override
                public boolean accept(java.io.File f) {
                    return f.isDirectory() || f.getName().toLowerCase().endsWith(".json");
                }

                @Override
                public String getDescription() {
                    return "JSON Files (*.json)";
                }
            });
            int returnValue = fileChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                String path = fileChooser.getSelectedFile().getAbsolutePath();
                String listName = JOptionPane.showInputDialog(this, "Enter the name of the list to import:");
                if (listName != null && !listName.trim().isEmpty()) {
                    try {
                        presentationController.importList(listName, path);
                        if (!listSelectionBox.isEnabled()) {
                            listSelectionBox.setEnabled(true);
                        }
                        listSelectionBox.addItem(listName);
                        listSelectionBox.setSelectedItem(listName);
                        loadCurrentList();
                    } catch (IllegalArgumentException e) {
                        DialogView dialog = new DialogView();
                        String[] buttons = {"OK"};
                        dialog.setDialog("Error importing list", "Incorrect file", buttons, 0);
                    }
                }
            }
        }
    }

    /**
     * Action performed when the product remove button is clicked
     * @param evt 
     */
    private void prodRemoveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prodRemoveButtonActionPerformed
        String product = (String)prodProdList.getSelectedValue();
        if (product == null) return;
        try {
            presentationController.removeProduct(product);
            DefaultListModel model = (DefaultListModel) prodProdList.getModel();
            model.removeElement(product);
            if (model.isEmpty()) {
                prodRemoveButton.setEnabled(false);
                prodManageButton.setEnabled(false);
                prodProdList.setEnabled(false);
            }
        } catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error removing product", e.getMessage(), buttons, 0);
        }
    }//GEN-LAST:event_prodRemoveButtonActionPerformed

    /**
     * Action performed when the product add button is clicked
     * @param evt 
     */
    private void prodAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prodAddButtonActionPerformed
        String productName = JOptionPane.showInputDialog("Enter product name");
        if (productName == null) return;
        else if (productName.isBlank()) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Input error", "Product name cannot be empty", buttons, 0);
            return;
        }
        try {
            if (presentationController.addProduct(productName)) {
                DefaultListModel model = (DefaultListModel) prodProdList.getModel();
                model.addElement(productName);
            }
            else {
                DialogView dialog = new DialogView();
                String[] buttons = {"OK"};
                dialog.setDialog("Error adding product", "Product already in list", buttons, 0);
            }
            if (!prodProdList.isEnabled()) {
                prodRemoveButton.setEnabled(true);
                prodManageButton.setEnabled(true);
                prodProdList.setEnabled(true);
            }
        } catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error adding product", e.getMessage(), buttons, 0);
        }
    }//GEN-LAST:event_prodAddButtonActionPerformed

    /**
     * Action performed when the list selection box is clicked
     * @param evt
     */
    private void listSelectionBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listSelectionBoxActionPerformed
        if (listSelectionBox.getSelectedIndex() <= 0) {
            if (listSelectionBox.getItemCount() == 1) {
                listSelectionBox.setEnabled(false);
            }
            prodAddButton.setEnabled(false);
            prodRemoveButton.setEnabled(false);
            prodManageButton.setEnabled(false);
            prodProdList.setEnabled(false);
        }
        else {
            String list = (String)listSelectionBox.getSelectedItem();
            try {
                presentationController.setActiveProductsList(list);
                loadCurrentList();
            }
            catch (IllegalArgumentException e) {
                DialogView dialog = new DialogView();
                String[] buttons = {"OK"};
                dialog.setDialog("Error creating list", e.getMessage(), buttons, 0);
            }
            
        }
    }//GEN-LAST:event_listSelectionBoxActionPerformed

    /**
     * Action performed when the user logout item is clicked
     * @param evt 
     */
    private void userLogoutItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userLogoutItemActionPerformed
        try {
            presentationController.logoutUser();
            listSelectionBox.removeAllItems();
            listSelectionBox.setSelectedIndex(-1);
            DefaultListModel model = new DefaultListModel();
            model.clear();
            prodProdList.setModel(model);
            prodAddButton.setEnabled(false);
            prodRemoveButton.setEnabled(false);
            prodManageButton.setEnabled(false);
            prodProdList.setEnabled(false);
            presentationController.syncronizeMainToLogin();
        } catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error logging out", e.getMessage(), buttons, 0);
        }
        
    }//GEN-LAST:event_userLogoutItemActionPerformed

    /**
     * Action performed when the list manage button is clicked
     * @param evt 
     */
    private void listManageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listManageButtonActionPerformed
        presentationController.syncronizeMainToLists();
    }//GEN-LAST:event_listManageButtonActionPerformed

    /**
     * Action performed when the organization algorithm box is clicked
     * @param evt 
     */
    private void orgAlgorithmBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orgAlgorithmBoxActionPerformed
        int alg = orgAlgorithmBox.getSelectedIndex();
        presentationController.setSelectedAlgorithm(alg);
        if (alg == 0) orgOrganizeButton.setEnabled(false);
        else orgOrganizeButton.setEnabled(true);
    }//GEN-LAST:event_orgAlgorithmBoxActionPerformed

    /**
     * Action performed when the move button is clicked
     * @param evt 
     */
    private void orgMoveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orgMoveButtonActionPerformed
        // Show a message to the user explaining the coordinate system
        JOptionPane.showMessageDialog(this, 
            "The coordinate system works as follows:\n" +
            " - The coordinates (0,0) are at the top left corner.",
            "Coordinate System Information",
            JOptionPane.INFORMATION_MESSAGE);

        int row1 = getValidIntInput("Enter row of the product to move");
        if (row1 == -1) return;

        int column1 = getValidIntInput("Enter column of the product to move");
        if (column1 == -1) return;

        int row2 = getValidIntInput("Enter the destination row");
        if (row2 == -1) return;

        int column2 = getValidIntInput("Enter the destination column");
        if (column2 == -1) return;

        try {
            presentationController.moveProduct(row1, column1, row2, column2);
            actualizeRack();

        } catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error moving product", e.getMessage(), buttons, 0);
        }
    }//GEN-LAST:event_orgMoveButtonActionPerformed

    /**
     * Action performed when the create rack button is clicked
     * @param evt 
     */
    private void createRackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createRackButtonActionPerformed
                // Prompt the user to enter the number of rows
        if (organized == true) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK", "Cancel"};
            int response = dialog.setDialog("This action cannot be undone", "Organization will be lost", buttons, 2);
            if (response == 1) return;
        }

        int rows = getValidIntInput("Enter number of rows");
        if (rows == -1) return;
        else if (rows == 0) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Input error", "Number of rows must be greater than 0", buttons, 0);
            return;
        }

        // Prompt the user to enter the number of columns
        int columns = getValidIntInput("Enter number of columns");
        if (columns == -1) return;
        else if (columns == 0) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Input error", "Number of columns must be greater than 0", buttons, 0);
            return;
        }

        // Create the rack with the specified number of rows and columns
        try {
            presentationController.createRack(rows, columns);
            actualRows = rows;
            actualColumns = columns;
            createRackButton.setText("Modify Rack Size");
            actualizeRack();
            organized = false;
        } catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error creating rack", e.getMessage(), buttons, 0);
        }
    }//GEN-LAST:event_createRackButtonActionPerformed

    /**
     * Action performed when the organize button is clicked
     * @param evt 
     */
    private void orgOrganizeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orgOrganizeButtonActionPerformed
        int alg = orgAlgorithmBox.getSelectedIndex();
        if (alg == 0) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error organizing rack", "Select an algorithm", buttons, 0);
            return;
        }
        if (presentationController.getSelectedAlgorithm() == 1) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK", "CANCEL"};
            if (dialog.setDialog("WARNING", "Calculating a backtracking solution for large racks may take a long time. Are you sure you want to continue?", buttons, 2) == 1) {
                return;
            }
        }
        try {
            presentationController.createRack(actualRows, actualColumns);
            presentationController.executeAlgorithm();
            actualizeRack();
            orgMoveButton.setEnabled(true);
            organized = true;
        }
        catch (IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Error organizing rack: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (IllegalArgumentException e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error", e.getMessage(), buttons, 0);
        }
        catch (Exception e) {
            DialogView dialog = new DialogView();
            String[] buttons = {"OK"};
            dialog.setDialog("Error", "Error organizing rack: No valid solution found.", buttons, 0);
        }
    }//GEN-LAST:event_orgOrganizeButtonActionPerformed

    /**
     * Action performed when the manage products button is clicked
     * @param evt 
     */
    private void prodManageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prodManageButtonActionPerformed
        presentationController.syncronizeMainToProd();
    }//GEN-LAST:event_prodManageButtonActionPerformed

    /**
     * Action performed when the exit menu item is clicked
     * @param evt 
     */
    private void userExitItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userExitItemActionPerformed
        windowOnClose();
    }//GEN-LAST:event_userExitItemActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel buttonsPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton createRackButton;
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.Box.Filler filler3;
    private javax.swing.Box.Filler filler4;
    private javax.swing.Box.Filler filler5;
    private javax.swing.Box.Filler filler7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel listListLabel;
    private javax.swing.JButton listManageButton;
    private javax.swing.JButton listNewButton;
    private javax.swing.JPanel listPanel;
    private javax.swing.JComboBox<String> listSelectionBox;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JComboBox<String> orgAlgorithmBox;
    private javax.swing.JLabel orgAlgotithmLable;
    private javax.swing.JButton orgMoveButton;
    private javax.swing.JButton orgOrganizeButton;
    private javax.swing.JPanel orgPanel;
    private javax.swing.JButton prodAddButton;
    private javax.swing.JButton prodManageButton;
    private javax.swing.JPanel prodPanel;
    private javax.swing.JList<String> prodProdList;
    private javax.swing.JLabel prodProductsLabel;
    private javax.swing.JButton prodRemoveButton;
    private javax.swing.JScrollPane prodScrollPane;
    private javax.swing.JPanel rackPanel;
    private javax.swing.JTable rackTable;
    private javax.swing.JMenuItem userExitItem;
    private javax.swing.JMenuItem userLogoutItem;
    private javax.swing.JMenu userMenu;
    // End of variables declaration//GEN-END:variables
}