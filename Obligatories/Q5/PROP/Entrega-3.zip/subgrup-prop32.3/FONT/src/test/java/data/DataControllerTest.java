package data;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import domain.Product.Product;
import domain.User.User;
import java.io.File;
import java.io.IOException;

public class DataControllerTest {
    private DataController dataController;
    private static final String TEST_DIR = "test_data/";

    @Before
    public void setUp() {
        dataController = new DataController();
        createTestDirectory();
    }

    @After
    public void tearDown() {
        deleteTestDirectory();
    }

    // Tests de Productos
    @Test
    public void testGetUserNull() {
        User user = dataController.getUser("testUser2");
        assertNull(user);
    }

    /**
     * Ensure that a check for a User that exists returns true
     */
    @Test
    public void testUserExistsTrue() {
        dataController.addUser("testUser", "testPassword");
        assertTrue(dataController.checkUserByUsername("testUser"));
    }

    /**
     * Ensure that a check for a User that does not exist returns false
     */
    @Test
    public void testUserExistsFalse() {
        assertFalse(dataController.checkUserByUsername("testUser3"));
    }

    // BLOQUE DE PRUEVAS DE LA CLASE DataController (Parte ListData)

    /**
     * Ensure that a list can be added and returned correctly
     */
    @Test
    public void testAddListSuccess() {
        dataController.addList("testUser", "testList");

        Product product = new Product("testProduct", "testList", "testUser");
        dataController.storeProduct(product);

        Product retrieved = dataController.getProduct("testProduct", "testUser", "testList");
        assertNotNull(retrieved);
        assertEquals("testProduct", retrieved.getName());
    }

    @Test
    public void testRemoveProduct() {
        dataController.addUser("testUser", "testPass");
        dataController.addList("testUser", "testList");

        Product product = new Product("testProduct", "testList", "testUser");
        dataController.storeProduct(product);
        dataController.removeProduct("testProduct", "testUser", "testList");

        assertNull(dataController.getProduct("testProduct", "testUser", "testList"));
    }

    @Test
    public void testUpdateProduct() {
        dataController.addUser("testUser", "testPass");
        dataController.addList("testUser", "testList");

        Product product = new Product("testProduct", "testList", "testUser");
        dataController.storeProduct(product);

        product.addSimilarity("otroProducto", 5);
        dataController.storeProduct(product);

        Product updated = dataController.getProduct("testProduct", "testUser", "testList");
        assertEquals(5, updated.getSimilarity("otroProducto"));
    }

    // Tests casos extremos
    @Test
    public void testGetProductNonExistentUser() {
        assertNull(dataController.getProduct("testProduct", "nonExistentUser", "testList"));
    }

    @Test
    public void testGetProductNonExistentList() {
        dataController.addUser("testUser", "testPass");
        assertNull(dataController.getProduct("testProduct", "testUser", "nonExistentList"));
    }

    @Test
    public void testPersistenceAcrossInstances() {
        // Crear y guardar datos
        dataController.addUser("testUser", "testPass");
        dataController.addList("testUser", "testList");
        Product product = new Product("testProduct", "testList", "testUser");
        dataController.storeProduct(product);

        // Crear nueva instancia y verificar datos
        DataController newController = new DataController();
        Product retrieved = newController.getProduct("testProduct", "testUser", "testList");
        assertNotNull(retrieved);
        assertEquals("testProduct", retrieved.getName());
    }

    private void createTestDirectory() {
        File directory = new File(TEST_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

    private void deleteTestDirectory() {
        File directory = new File(TEST_DIR);
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
            directory.delete();
        }
    }
}