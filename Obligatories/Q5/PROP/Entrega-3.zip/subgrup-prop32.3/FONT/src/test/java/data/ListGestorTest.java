package data;

import domain.Product.ProductsList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.HashSet;

import static org.junit.Assert.*;

public class ListGestorTest {

    private ListGestor listGestor;
    private static final String TEST_LISTS_FILE_PATH = "data/test_lists.json";
    private static final String TEST_LISTS_DIR = "data/test_lists/";

    @Before
    public void setUp() {
        listGestor = new ListGestor(TEST_LISTS_FILE_PATH, TEST_LISTS_DIR);
        File file = new File(TEST_LISTS_FILE_PATH);
        if (file.exists()) {
            file.delete();
        }
        File dir = new File(TEST_LISTS_DIR);
        if (dir.exists()) {
            deleteDirectory(dir);
        }
        dir.mkdirs();
    }

    @After
    public void tearDown() {
        File file = new File(TEST_LISTS_FILE_PATH);
        if (file.exists()) {
            file.delete();
        }
        File dir = new File(TEST_LISTS_DIR);
        if (dir.exists()) {
            deleteDirectory(dir);
        }
    }

    /**
     * Helper method to recursively delete directories.
     *
     * @param dir Directory to delete.
     */
    private void deleteDirectory(File dir) {
        if (dir.isDirectory()) {
            for (File sub : dir.listFiles()) {
                deleteDirectory(sub);
            }
        }
        dir.delete();
    }

    @Test
    public void testAddList() {
        String username = "Usuario1";
        String listName = "Lista1";
        listGestor.addList(username, listName);

        HashSet<String> lists = listGestor.getLists(username);
        assertNotNull(lists);
        assertTrue(lists.contains(listName));
    }

    @Test
    public void testRemoveList() {
        String username = "Usuario2";
        String listName = "Lista2";
        listGestor.addList(username, listName);
        listGestor.removeList(username, listName);

        HashSet<String> lists = listGestor.getLists(username);
        assertTrue(lists.isEmpty());
        // assertNull(lists);

        File listFile = new File(TEST_LISTS_DIR + username + "_" + listName + ".json");
        assertFalse(listFile.exists());
    }

    @Test
    public void testGetList() {
        String username = "Usuario3";
        String listName = "Lista3";
        ProductsList productList = new ProductsList(listName, username);
        listGestor.storeList(productList);

        ProductsList retrieved = listGestor.getList(username, listName);
        assertNotNull(retrieved);
        assertEquals(username, retrieved.getUser());
        assertEquals(listName, retrieved.getName());
    }

    @Test
    public void testCheckListByNameExists() {
        String username = "Usuario4";
        String listName = "Lista4";
        listGestor.addList(username, listName);

        assertTrue(listGestor.checkListByName(username, listName));
    }

    @Test
    public void testCheckListByNameNotExists() {
        String username = "Usuario5";
        String listName = "Lista5";

        assertFalse(listGestor.checkListByName(username, listName));
    }

    @Test
    public void testGetLists() {
        String username = "Usuario6";
        String listName1 = "Lista6a";
        String listName2 = "Lista6b";
        listGestor.addList(username, listName1);
        listGestor.addList(username, listName2);

        HashSet<String> lists = listGestor.getLists(username);
        assertNotNull(lists);
        assertEquals(2, lists.size());
        assertTrue(lists.contains(listName1));
        assertTrue(lists.contains(listName2));
    }

    @Test
    public void testStoreList() {
        String username = "Usuario7";
        String listName = "Lista7";
        ProductsList productList = new ProductsList(listName, username);
        listGestor.storeList(productList);

        HashSet<String> lists = listGestor.getLists(username);
        assertNotNull(lists);
        assertTrue(lists.contains(listName));

        ProductsList retrieved = listGestor.getList(username, listName);
        assertNotNull(retrieved);
        assertEquals(username, retrieved.getUser());
        assertEquals(listName, retrieved.getName());
    }

    @Test
    public void testRemoveNonExistingList() {
        String username = "Usuario8";
        String listName = "Lista8";

        listGestor.removeList(username, listName);

        HashSet<String> lists = listGestor.getLists(username);
        assertTrue(lists.isEmpty());
    }
}