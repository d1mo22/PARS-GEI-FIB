package data;

import domain.Product.Product;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.List;

import static org.junit.Assert.*;

public class ProductGestorTest {

  private ProductGestor productGestor;
  private static final String TEST_FILE_PATH = "data/test_products.json";

  @Before
  public void setUp() {
    // Inicializar ProductGestor con un archivo de prueba
    productGestor = new ProductGestor(TEST_FILE_PATH);
    // Limpiar el archivo de prueba antes de cada test
    File file = new File(TEST_FILE_PATH);
    if (file.exists()) {
      file.delete();
    }
  }

  @After
  public void tearDown() {
    // Eliminar el archivo de prueba después de cada test
    File file = new File(TEST_FILE_PATH);
    if (file.exists()) {
      file.delete();
    }
  }

  @Test
  public void testStoreProduct() {
    Product product = new Product("Producto1", "Lista1", "Usuario1");
    productGestor.storeProduct(product);
    Product retrieved = productGestor.getProduct("Producto1", "Usuario1", "Lista1");
    assertNotNull(retrieved);
    assertEquals("Producto1", retrieved.getName());
  }

  @Test
  public void testRemoveProduct() {
    Product product = new Product("Producto2", "Usuario2", "Lista2");
    productGestor.storeProduct(product);
    productGestor.removeProduct("Producto2", "Usuario2", "Lista2");
    Product retrieved = productGestor.getProduct("Producto2", "Usuario2", "Lista2");
    assertNull(retrieved);
  }

  @Test
  public void testGetProductNotExist() {
    Product retrieved = productGestor.getProduct("NoExistente", "UsuarioX", "ListaX");
    assertNull(retrieved);
  }

  @Test
  public void testStoreDuplicateProduct() {
    Product product1 = new Product("Producto3", "Lista3", "Usuario3");
    Product product2 = new Product("Producto3", "Lista3", "Usuario3");
    productGestor.storeProduct(product1);
    productGestor.storeProduct(product2);
    List<Product> productos = productGestor.getProducts();
    assertEquals(1, productos.size());
  }

  @Test
  public void testRemoveNonExistingProduct() {
    // Intentar eliminar un producto que no existe
    productGestor.removeProduct("Inexistente", "UsuarioY", "ListaY");
    List<Product> productos = productGestor.getProducts();
    assertTrue(productos.isEmpty());
  }

  @Test
  public void testCheckProductByNameExists() {
    Product product = new Product("Producto4", "Lista4", "Usuario4");
    productGestor.storeProduct(product);
    boolean exists = productGestor.checkProductByName("Producto4", "Usuario4", "Lista4");
    assertTrue(exists);
  }

  @Test
  public void testCheckProductByNameNotExists() {
    boolean exists = productGestor.checkProductByName("Producto5", "Usuario5", "Lista5");
    assertFalse(exists);
  }

}