package data;

import domain.User.User;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import java.util.HashMap;

public class UserGestorTest {

    private UserGestor userGestor;
    private User testUser, testUser2, testUser3;

    /**
     * Set up the test environment.
     */
    @Before
    public void setUp() {
        userGestor = new UserGestor();
        testUser = new User("testUser", "password"); // Crear una instancia real de User
        testUser2 = new User("testUser2", "password"); 
        testUser3 = new User("testUser3", "password"); 
    }

    /**
     * Ensure that a User can be added and returned correctly
     */
    @Test
    public void testAddUser() {
        userGestor.addUser(testUser);
        assertTrue(userGestor.checkUserByUsername("testUser"));
        userGestor.clearAllUsers();
    }

    /**
     * Ensure that a User can get retrieved correctly
     */
    @Test
    public void testGetUser() {
        userGestor.addUser(testUser);
        User retrievedUser = userGestor.getUser("testUser");
        assertNotNull(retrievedUser);
        assertEquals("testUser", retrievedUser.getUsername());
        userGestor.clearAllUsers();
    }

    /**
     * Ensure that checks for existing and non-existing users work correctly
     */
    @Test
    public void testCheckUserByUsername() {
        userGestor.addUser(testUser);
        assertTrue(userGestor.checkUserByUsername("testUser"));
        assertFalse(userGestor.checkUserByUsername("nonExistentUser"));
        userGestor.clearAllUsers();
    }

    /**
     * Ensure that all users can be retrieved correctly
     */
    @Test
    public void testGetAllUsers() {
        userGestor.addUser(testUser);
        userGestor.addUser(testUser2);
        userGestor.addUser(testUser3);
        HashMap<String, User> allUsers = userGestor.getAllUsers();
        assertEquals(3, allUsers.size());
        assertTrue(allUsers.containsKey("testUser"));
        assertTrue(allUsers.containsKey("testUser2"));
        assertTrue(allUsers.containsKey("testUser3"));
        userGestor.clearAllUsers();
    }
}
