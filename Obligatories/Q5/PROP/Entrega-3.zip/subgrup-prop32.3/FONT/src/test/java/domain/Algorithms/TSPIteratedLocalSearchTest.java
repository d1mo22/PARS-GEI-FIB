package domain.Algorithms;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * Tests for the TSPIteratedLocalSearch class
 */
public class TSPIteratedLocalSearchTest {

    @Mock
    private TSPHillClimbing mockHillClimbing;

    private TSPIteratedLocalSearch iteratedLocalSearch;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        iteratedLocalSearch = new TSPIteratedLocalSearch(mockHillClimbing);
    }

    @Test
    public void testSolveMin() {
        List<Integer> initialSolution = Arrays.asList(1, 2, 3, 4);
        List<Integer> betterSolution = Arrays.asList(1, 3, 2, 4);

        // Configure mock behavior
        when(mockHillClimbing.getSolution()).thenReturn(initialSolution, betterSolution);
        when(mockHillClimbing.getCost()).thenReturn(100, 90);

        // Execute the method to test
        iteratedLocalSearch.solveMin();

        // Verify that the necessary methods were called
        verify(mockHillClimbing, atLeastOnce()).solveMin();
        verify(mockHillClimbing, atLeastOnce()).setInitialSolution(any());

        // Verify result
        assertEquals(90, iteratedLocalSearch.getBestCost());
        assertEquals(betterSolution, iteratedLocalSearch.getBestSolution());
    }

    @Test
    public void testSolveMax() {
        List<Integer> initialSolution = Arrays.asList(1, 2, 3, 4);
        List<Integer> betterSolution = Arrays.asList(4, 2, 3, 1);

        // Configure mock behavior
        when(mockHillClimbing.getSolution()).thenReturn(initialSolution, betterSolution);
        when(mockHillClimbing.getCost()).thenReturn(100, 110);

        // Execute the method to test
        iteratedLocalSearch.solveMax();

        // Verify that the necessary methods were called
        verify(mockHillClimbing, atLeastOnce()).solveMax();
        verify(mockHillClimbing, atLeastOnce()).setInitialSolution(any());

        // Verify result
        assertEquals(110, iteratedLocalSearch.getBestCost());
        assertEquals(betterSolution, iteratedLocalSearch.getBestSolution());
    }

    @Test
    public void testInitialState() {
        List<Integer> solution = iteratedLocalSearch.getBestSolution();
        assertTrue(solution.isEmpty());
        assertEquals(Integer.MAX_VALUE, iteratedLocalSearch.getBestCost());
    }

    @Test
    public void testSolveMinImprovesSolution() {
        List<Integer> initialSolution = Arrays.asList(1, 2, 3, 4);
        List<Integer> intermediateSolution = Arrays.asList(1, 3, 2, 4);
        List<Integer> finalSolution = Arrays.asList(1, 2, 4, 3);

        // Simulate that Hill Climbing finds increasingly better solutions
        when(mockHillClimbing.getSolution())
                .thenReturn(initialSolution) // First solution
                .thenReturn(intermediateSolution) // Second iteration
                .thenReturn(finalSolution); // Third iteration

        when(mockHillClimbing.getCost())
                .thenReturn(100) // Initial cost
                .thenReturn(90) // Better cost in second iteration
                .thenReturn(80); // Better cost in third iteration

        iteratedLocalSearch.solveMin();

        // Verify that the best solution found was saved
        assertEquals(80, iteratedLocalSearch.getBestCost());
        assertEquals(finalSolution, iteratedLocalSearch.getBestSolution());

        // Verify that multiple iterations were performed
        verify(mockHillClimbing, atLeast(3)).solveMin();
    }

    @Test
    public void testSolveMaxImprovesSolution() {
        List<Integer> initialSolution = Arrays.asList(1, 2, 3, 4);
        List<Integer> intermediateSolution = Arrays.asList(4, 2, 3, 1);
        List<Integer> finalSolution = Arrays.asList(4, 3, 2, 1);

        // Simulate that Hill Climbing finds increasingly better solutions
        when(mockHillClimbing.getSolution())
                .thenReturn(initialSolution) // First solution
                .thenReturn(intermediateSolution) // Second iteration
                .thenReturn(finalSolution); // Third iteration

        when(mockHillClimbing.getCost())
                .thenReturn(100) // Initial cost
                .thenReturn(120) // Better cost in second iteration
                .thenReturn(150); // Better cost in third iteration

        iteratedLocalSearch.solveMax();

        // Verify that the best solution found was saved
        assertEquals(150, iteratedLocalSearch.getBestCost());
        assertEquals(finalSolution, iteratedLocalSearch.getBestSolution());

        // Verify that multiple iterations were performed
        verify(mockHillClimbing, atLeast(3)).solveMax();
    }
}
