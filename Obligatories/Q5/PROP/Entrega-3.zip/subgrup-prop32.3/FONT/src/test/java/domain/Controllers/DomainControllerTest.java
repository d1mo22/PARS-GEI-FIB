package domain.Controllers;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.Assert;

import domain.User.User;
import data.DataController;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import domain.Product.Product;
import domain.Product.ProductsList;
import domain.Rack.Rack;

import java.io.IOException;
import java.util.*;

public class DomainControllerTest {

  @Mock
  private UserController userController;

  @Mock
  private DataController dataController;

  @Mock
  private ProductsListController productsListController;

  @Mock
  private ProductController productController;

  @Mock
  private RackController rackController;

  @InjectMocks
  private DomainController domainController;

  @Before
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  // BLOQUE DE PRUEBAS DE LA CLASE DomainController (Parte Product List)

  /**
   * Ensure that active product lists are returned correctly
   */
  @Test
  public void testGetActiveProductListsSuccess() {
    HashSet<String> mockLists = new HashSet<String>(Arrays.asList("testList", "testList2"));
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.getLists("testUser")).thenReturn(mockLists);
    HashSet<String> activeLists = domainController.getActiveUserProductLists();
    assertNotNull(activeLists);
    assertEquals(2, activeLists.size());
    assertEquals(mockLists, activeLists);
  }

  /**
   * Ensure that an exception is thrown when trying to get active product lists
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetActiveProductListsNotAuthenticated() {
    domainController.getActiveUserProductLists();
  }

  /**
   * Ensure that the active product list is set correctly
   */
  @Test
  public void testSetActiveProductListSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");
    assertEquals("testList", domainController.getActiveList());
  }

  /**
   * Ensure that an exception is thrown when trying to set an active product list
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testSetActiveProductListNotAuthenticated() throws IOException {
    domainController.setActiveList("testList");
  }

  /**
   * Ensure that an exception is thrown when trying to set an active product list
   * that does not exist
   */

  @Test(expected = IllegalArgumentException.class)
  public void testSetActiveProductListDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(false);
    domainController.setActiveList("testList");
  }

  /**
   * Ensure that the active product list is returned correctly
   */
  @Test
  public void testGetActiveProductListSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");
    assertEquals("testList", domainController.getActiveList());
  }

  /**
   * Ensure that an exception is thrown when trying to get the active product list
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetActiveProductListNotAuthenticated() {
    domainController.getActiveList();
  }

  /**
   * Ensure that an exception is thrown when trying to get the active product list
   * when no list is set
   */

  @Test(expected = IllegalArgumentException.class)
  public void testGetActiveProductListNotSet() {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.getActiveList();
  }

  /**
   * Ensure that a product list is added correctly
   */
  @Test
  public void testAddProductListSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(false);
    domainController.addProductList("testList");
    verify(dataController).addList("testUser", "testList");
  }

  /**
   * Ensure that an exception is thrown when trying to add a product list while
   * not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddProductListNotAuthenticated() throws IOException {
    domainController.addProductList("testList");
  }

  /**
   * Ensure that an exception is thrown when trying to add a product list that
   * already exists
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddProductListAlreadyExists() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.addProductList("testList");
  }

  /**
   * Ensure that a product list is removed correctly
   */
  @Test
  public void testRemoveProductListSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    when(dataController.getLastSavedRackList()).thenReturn("testList");
    domainController.removeProductList("testList");
    verify(dataController).removeList("testUser", "testList");
    verify(dataController).invalidateStoredRack();
  }

  /**
   * Ensure that an exception is thrown when trying to remove a product list while
   * not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveProductListNotAuthenticated() throws IOException {
    domainController.removeProductList("testList");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a product list that
   * does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveProductListDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(false);
    domainController.removeProductList("testList");
  }

  /**
   * Ensure that a product list name is modified correctly
   */
  @Test
  public void testUpdateProductListNameSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    ProductsList mockProducts = new ProductsList("testList", "testUser");
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);
    when(dataController.getList("testUser", "newList")).thenReturn(mockProducts);
    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    when(productsListController.getProductsList()).thenReturn(mockProducts);
    when(productsListController.getProducts()).thenReturn(new ArrayList<>());
    when(dataController.getLastSavedRackList()).thenReturn("testList");
    domainController.modifyProductListName("testList", "newList");
    verify(dataController).addList("testUser", "newList");
    verify(dataController).storeList(mockProducts);
    verify(dataController).removeList("testUser", "testList");
    verify(dataController).changeRackListName("newList");
  }

  /**
   * Ensure that an exception is thrown when trying to modify a product list name
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testUpdateProductListNameNotAuthenticated() throws IOException {
    domainController.modifyProductListName("testList", "newList");
  }

  /**
   * Ensure that an exception is thrown when trying to modify a product list name
   * that does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testUpdateProductListNameDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(false);
    domainController.modifyProductListName("testList", "newList");
  }

  // BLOQUE DE PRUEBAS DE LA CLASE DomainController (Parte Rack)

  /**
   * Ensure that current rack is checked correctly
   */
  @Test
  public void testCheckCurrentRackSuccess() {
    when(dataController.getLastSavedRackUser()).thenReturn("testUser");
    assertTrue(domainController.checkUserHasSavedRack("testUser"));
  }

  /**
   * Ensure that current rack check fails when the user does not have a saved rack
   */
  @Test
  public void testCheckCurrentRackNoRack() {
    when(dataController.getLastSavedRackUser()).thenReturn("otherUser");
    assertFalse(domainController.checkUserHasSavedRack("testUser"));
  }

  /**
   * Ensure that getting the current saved rack works correctly
   */
  @Test
  public void testGetCurrentSavedRackSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    String[][] mockRack = new String[2][2];
    ProductsList mockProducts = new ProductsList("testList", "testUser");
    when(dataController.getLastSavedRackMatrix()).thenReturn(mockRack);
    when(dataController.getLastSavedRackUser()).thenReturn("testUser");
    when(dataController.getLastSavedRackList()).thenReturn("testList");
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);

    Rack mockRackInstance = new Rack(mockProducts, 2, 2);
    when(rackController.getActiveRack()).thenReturn(mockRackInstance);

    Rack returnedRack = domainController.getSavedRack();
    assertNotNull(returnedRack);
    assertEquals(mockRackInstance, returnedRack);
    verify(rackController).createRack(mockProducts, 2, 2);
    verify(rackController).setRackMatrix(mockRack);
  }

  /**
   * Ensure that an exception is thrown when trying to get the current saved rack
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetCurrentSavedRackNotAuthenticated() throws IOException {
    domainController.getSavedRack();
  }

  /**
   * Ensure that an exception is thrown when trying to get the current saved rack
   * when no rack is saved
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetCurrentSavedRackNoRack() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.getLastSavedRackUser()).thenReturn("otherUser");
    domainController.getSavedRack();
  }

  /**
   * Ensure that the current rack matrix is returned correctly
   */
  @Test
  public void testGetCurrentRackMatrixSuccess() {
    String[][] mockRack = new String[2][2];
    when(rackController.getRackMatrix()).thenReturn(mockRack);
    when(rackController.rackNotSet()).thenReturn(false);
    assertArrayEquals(mockRack, domainController.getRackMatrix());
  }

  /**
   * Ensure that an exception is thrown when trying to get the current rack matrix
   * when no rack is set
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetCurrentRackMatrixNoRack() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.getRackMatrix();
  }

  /**
   * Ensure that a rack is created correctly
   */
  @Test
  public void testCreateRackSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    ProductsList mockProducts = new ProductsList("testList", "testUser");
    Rack mockRack = new Rack(mockProducts, 2, 2);
    when(rackController.getActiveRack()).thenReturn(mockRack);
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);
    domainController.createRack(2, 2);
    verify(rackController).createRack(mockProducts, 2, 2);
    verify(dataController).storeRack(mockRack);
  }

  /**
   * Ensure that an exception is thrown when trying to create a rack while not
   * authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCreateRackNotAuthenticated() throws IOException {
    domainController.createRack(2, 2);
  }

  /**
   * Ensure that an exception is thrown when trying to create a rack with invalid
   * dimensions
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCreateRackInvalidDimensions() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.createRack(0, 2);
  }

  /**
   * Ensure that an exception is thrown when trying to create a rack
   * if there is no active product list
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCreateRackNoActiveList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.createRack(2, 2);
  }

  /**
   * Ensure that a rack is calculated correctly when using hill climbing,
   */

  @Test
  public void testCalculateRackHCSuccess() {
    // Setup usuario autenticado
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    // Setup lista activa
    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    // Setup resto del test
    ProductsList mockProducts = new ProductsList("testList", "testUser");
    mockProducts.addProduct(new Product("testProduct", "testList", "testUser"));
    mockProducts.addProduct(new Product("testProduct2", "testList", "testUser"));
    Rack mockRack = new Rack(mockProducts, 2, 2);
    when(rackController.rackNotSet()).thenReturn(false);
    when(rackController.getActiveRack()).thenReturn(mockRack);
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);

    domainController.solveHillClimbing();
    verify(rackController).solveTSPHillClimbing();
    verify(dataController).storeRack(mockRack);
  }

  @Test
  public void testCalculateRackAproximationSuccess() {
    // Setup usuario autenticado
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    // Setup lista activa
    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    // Setup resto del test
    ProductsList mockProducts = new ProductsList("testList", "testUser");
    mockProducts.addProduct(new Product("testProduct", "testList", "testUser"));
    mockProducts.addProduct(new Product("testProduct2", "testList", "testUser"));
    Rack mockRack = new Rack(mockProducts, 2, 2);
    when(rackController.rackNotSet()).thenReturn(false);
    when(rackController.getActiveRack()).thenReturn(mockRack);
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);

    domainController.solveAproximation();
    verify(rackController).solveTSPApproximation();
    verify(dataController).storeRack(mockRack);
  }

  @Test
  public void testCalculateRackBacktrackingSuccess() {
    // Setup usuario autenticado
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    // Setup lista activa
    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    // Setup resto del test
    ProductsList mockProducts = new ProductsList("testList", "testUser");
    mockProducts.addProduct(new Product("testProduct", "testList", "testUser"));
    mockProducts.addProduct(new Product("testProduct2", "testList", "testUser"));
    Rack mockRack = new Rack(mockProducts, 2, 2);
    when(rackController.rackNotSet()).thenReturn(false);
    when(rackController.getActiveRack()).thenReturn(mockRack);
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);

    domainController.solveBacktracking();
    verify(rackController).solveTSPBacktracking();
    verify(dataController).storeRack(mockRack);
  }

  /**
   * Ensure that an exception is thrown when trying to calculate a rack
   * by TSPHillCLimbing if there is no set rack
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCalculateRackNoRackHillClimbing() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.solveHillClimbing();
  }

  /**
   * Ensure that an exception is thrown when trying to calculate a rack
   * by TSPAproximation if there is no set rack
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCalculateRackNoRackAproximation() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.solveAproximation();
  }

  /**
   * Ensure that an exception is thrown when trying to calculate a rack
   * by TSPBacktracking if there is no set rack
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCalculateRackNoRackBacktracking() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.solveBacktracking();
  }

  /**
   * Ensure that rack rows and columns are set correctly
   */
  @Test
  public void testSetRackRowsAndColumnsSuccess() {
    when(rackController.rackNotSet()).thenReturn(false);
    domainController.setRowsAndColumns(2, 2);
    verify(rackController).setRowsAndColumns(2, 2);
  }

  /**
   * Ensure that an exception is thrown when trying to set rack rows and columns
   * if there is no set rack
   */
  @Test(expected = IllegalArgumentException.class)
  public void testSetRackRowsAndColumnsNoRack() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.setRowsAndColumns(2, 2);
  }

  /**
   * Ensure that an exception is thrown when trying to get the rack columns
   * if there is no set rack
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetRackColumnsNoRack() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.getRackColumns();
  }

  /**
   * Ensure that an exception is thrown when trying to get the rack rows
   * if there is no set rack
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetRackRowsNoRack() {
    when(rackController.rackNotSet()).thenReturn(true);
    domainController.getRackRows();
  }

  // BLOQUE DE PRUEBAS DE LA CLASE DomainController (Parte User)

  /**
   * Ensure that a user is created correctly when the username does not exist
   */
  @Test
  public void testCreateUserSuccess() {
    User mockUser = new User("testUser", "password123");
    when(dataController.checkUserByUsername("testUser")).thenReturn(false);
    when(userController.createUser("testUser", "password123")).thenReturn(mockUser);

    User returnUser = domainController.createUser("testUser", "password123");
    verify(dataController).addUser("testUser", "password123");
    assertEquals(mockUser, returnUser);
  }

  /**
   * Ensure that an exception is thrown when trying to create a user with null
   * username and password
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCreateUserNullUsernamePassword() {
    when(dataController.checkUserByUsername("testUser")).thenReturn(false);
    domainController.createUser(null, null);
  }

  /**
   * Ensure that an exception is thrown when the username already exists
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCreateUserAlreadyExists() {
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.createUser("testUser", "newPassword");
  }

  /**
   * Ensure that a user can log in correctly with valid credentials
   */
  @Test
  public void testLoginUserSuccess() {

    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    User mockUser = new User("testUser", "password123");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password123")).thenReturn(true);

    User returnedUser = domainController.loginUser("testUser", "password123");
    assertTrue(domainController.isUserLoggedIn());
    assertEquals(domainController.getCurrentUser(), mockUser);
    assertEquals(mockUser, returnedUser);
  }

  /**
   * Ensure that an exception is thrown if a user is already logged in
   */
  @Test(expected = IllegalArgumentException.class)
  public void testLoginUserAlreadyLoggedIn() {
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    User mockUser = mock(User.class);
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(mockUser.verifyPassword("password123")).thenReturn(true);

    domainController.loginUser("testUser", "password123");
    domainController.loginUser("testUser", "password123");
  }

  /**
   * Ensure that an exception is thrown when the username is invalid
   */
  @Test(expected = IllegalArgumentException.class)
  public void testLoginUserInvalidUsername() {
    when(dataController.checkUserByUsername("invalidUser")).thenReturn(false);
    domainController.loginUser("invalidUser", "password123");
  }

  /** Verify that an exception is thrown when the password is incorrect */
  @Test(expected = IllegalArgumentException.class)
  public void testLoginUserInvalidPassword() {
    User mockUser = mock(User.class);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("wrongPassword")).thenReturn(false);

    domainController.loginUser("testUser", "wrongPassword");
  }

  /**
   * Ensure that a user can log out correctly
   */
  @Test
  public void testLogoutUserSuccess() {
    new User("testUser", "password123");
    when(userController.verifyPassword("password123")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);

    domainController.loginUser("testUser", "password123");
    assertTrue(domainController.isUserLoggedIn());

    domainController.logoutUser();
    assertFalse(domainController.isUserLoggedIn());
    verify(userController).removeActiveUser();
  }

  /** Test logout when no user is authenticated */
  @Test(expected = IllegalArgumentException.class)
  public void testLogoutUserNotAuthenticated() {
    domainController.logoutUser();
  }

  /**
   * Ensure that the current user is returned correctly
   */
  @Test
  public void testGetCurrentUserSuccess() {
    User mockUser = new User("testUser", "password123");
    when(userController.verifyPassword("password123")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);

    when(dataController.getUser("testUser")).thenReturn(mockUser);
    domainController.loginUser("testUser", "password123");
    User currentUser = domainController.getCurrentUser();
    assertNotNull(currentUser);
    assertEquals(mockUser, currentUser);
  }

  /**
   * Ensure that an exception is thrown when trying to get the current user
   * when not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetCurrentUserNotAuthenticated() {
    domainController.getCurrentUser();
  }

  /**
   * Ensure that the user's password is changed correctly
   */
  @Test
  public void testChangePasswordSuccess() {
    User mockUser = new User("testUser", "password123");
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);

    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.getActiveUser()).thenReturn(mockUser);
    domainController.changeUserPassword("testUser", "newPassword");
    verify(userController).changePassword("newPassword");
    verify(dataController).addUser("testUser", "newPassword");
  }

  /**
   * Ensure that an exception is thrown when trying to change the password
   * when the user does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testChangePasswordUserDoesNotExist() {
    when(dataController.checkUserByUsername("testUser")).thenReturn(false);
    domainController.changeUserPassword("testUser", "newPassword");
  }

  // BLOQUE DE PRUEBAS DE LA CLASE DomainController (Parte Product)

  /**
   * Ensure that all products in the active list are returned correctly
   */
  @Test
  public void testGetProductsInActiveListSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    ProductsList mockProducts = new ProductsList("testList", "testUser");
    mockProducts.addProduct(new Product("testProduct", "testList", "testUser"));
    mockProducts.addProduct(new Product("testProduct2", "testList", "testUser"));
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);
    when(productsListController.getProducts()).thenReturn(mockProducts.getProducts());

    List<String> mockProductsList = new ArrayList<>(Arrays.asList("testProduct", "testProduct2"));
    List<String> products = domainController.getActiveListProducts();
    assertNotNull(products);
    assertArrayEquals(mockProductsList.toArray(), products.toArray());
  }

  /**
   * Ensure that an exception is thrown when trying to get products in the active
   * list
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetProductsInActiveListNotAuthenticated() throws IOException {
    domainController.getActiveListProducts();
  }

  /**
   * Ensure that an exception is thrown when trying to get products in the active
   * list
   * when no list is set
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetProductsInActiveListNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.getActiveListProducts();
  }

  /**
   * Ensure that product similarities are returned correctly
   */
  @Test
  public void testGetProductSimilaritiesSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    mockProduct.addSimilarity("product2", 0);
    mockProduct.addSimilarity("product3", 0);

    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(mockProduct);
    when(productController.getSimilarities()).thenReturn(mockProduct.getSimilarities());
    HashMap<String, Integer> similarities = domainController.getProductSimilarities("testProduct");
    assertNotNull(similarities);
    verify(productController).setProduct(mockProduct);
    assertEquals(2, similarities.size());
    assertEquals(0, similarities.get("product2").intValue());
    assertEquals(0, similarities.get("product3").intValue());
  }

  /**
   * Ensure that an exception is thrown when trying to get product similarities
   * while not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetProductSimilaritiesNotAuthenticated() throws IOException {
    domainController.getProductSimilarities("testProduct");
  }

  /**
   * Ensure that an exception is thrown when trying to get product similarities
   * when no list is set
   */

  @Test(expected = IllegalArgumentException.class)
  public void testGetProductSimilaritiesNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(userController.verifyPassword("password")).thenReturn(true);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.getProductSimilarities("testProduct");
  }

  /**
   * Ensure that a product is added correctly
   */

  @Test
  public void testAddProductSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    ProductsList mockProducts = new ProductsList("testList", "testUser");
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);
    when(dataController.checkProductByName("testProduct", "testUser", "testList")).thenReturn(false);

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    when(productController.createProduct("testProduct", "testList", "testUser")).thenReturn(mockProduct);

    when(dataController.getLastSavedRackList()).thenReturn("testList");

    boolean added = domainController.addProduct("testProduct");
    verify(dataController).storeProduct(mockProduct);
    assertTrue(added);
    verify(dataController).invalidateStoredRack();
  }

  /**
   * Ensure that an exception is thrown when trying to add a product while not
   * authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddProductNotAuthenticated() throws IOException {
    domainController.addProduct("testProduct");
  }

  /**
   * Ensure that a product that already exists is not added
   */
  @Test
  public void testAddProductAlreadyExists() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    when(dataController.checkProductByName("testProduct", "testUser", "testList")).thenReturn(true);
    boolean added = domainController.addProduct("testProduct");
    assertFalse(added);
  }

  /**
   * Ensure that an exception is thrown when trying to add a product with a null
   * name
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddProductNullName() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    domainController.addProduct(null);
  }

  /**
   * Ensure that an exception is thrown when trying to add a product with an empty
   * name
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddProductEmptyName() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    domainController.addProduct("");
  }

  /**
   * Ensure that an exception is thrown when trying to add a product with no
   * active list
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddProductNoActiveList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.addProduct("testProduct");
  }

  /**
   * Ensure that a product is removed correctly
   */
  @Test
  public void testRemoveProductSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    ProductsList mockProducts = new ProductsList("testList", "testUser");
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);
    when(dataController.checkProductByName("testProduct", "testUser", "testList")).thenReturn(true);
    when(dataController.getLastSavedRackList()).thenReturn("testList");

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    Product mockProduct2 = new Product("testProduct2", "testList", "testUser");
    mockProduct.addSimilarity("testProduct2", 0);
    mockProduct2.addSimilarity("testProduct", 0);
    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(mockProduct);
    when(productController.getSimilarities()).thenReturn(mockProduct.getSimilarities());
    when(dataController.getProduct("testProduct2", "testUser", "testList")).thenReturn(mockProduct);
    when(productController.getSimilarities()).thenReturn(mockProduct.getSimilarities());
    when(productController.getProduct()).thenReturn(mockProduct2);

    boolean removed = domainController.removeProduct("testProduct");
    assertTrue(removed);
    verify(productController).removeSimilarity("testProduct");
    verify(dataController).storeProduct(mockProduct2);
    verify(dataController).removeProduct("testProduct", "testUser", "testList");
    verify(dataController).invalidateStoredRack();
  }

  /**
   * Ensure that an exception is thrown when trying to remove a product while not
   * authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveProductNotAuthenticated() throws IOException {
    domainController.removeProduct("testProduct");
  }

  /**
   * Enusre that a product is not removed if it does not exist
   */
  @Test
  public void testRemoveProductDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    ProductsList mockProducts = new ProductsList("testList", "testUser");
    when(dataController.getList("testUser", "testList")).thenReturn(mockProducts);
    when(dataController.checkProductByName("testProduct", "testUser", "testList")).thenReturn(false);
    boolean removed = domainController.removeProduct("testProduct");
    assertFalse(removed);
  }

  /**
   * Ensure that an exception is thrown when trying to remove a product if no list
   * is set
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveProductNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.removeProduct("testProduct");
  }

  // BLOQUE DE PRUEBAS DE LA CLASE DomainController (Parte Similarity)

  /**
   * Ensure that a similarity is added correctly
   */
  @Test
  public void testAddSimilaritySuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    Product mockProduct2 = new Product("testProduct2", "testList", "testUser");
    mockProduct.addSimilarity("testProduct2", 0);
    mockProduct2.addSimilarity("testProduct", 0);
    when(dataController.getProduct("testProduct", "testUser", "testList"))
        .thenReturn(new Product("testProduct", "testList", "testUser"));
    when(dataController.getProduct("testProduct2", "testUser", "testList"))
        .thenReturn(new Product("testProduct2", "testList", "testUser"));

    domainController.addProductSimilarity("testProduct", "testProduct2", 0);

    verify(productController).addSimilarity("testProduct2", 0);
    verify(productController).addSimilarity("testProduct", 0);
  }

  /**
   * Ensure that an exception is thrown when trying to add a similarity while not
   * authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddSimilarityNotAuthenticated() throws IOException {
    domainController.addProductSimilarity("testProduct", "testProduct2", 0);
  }

  /**
   * Ensure that an exception is thrown when trying to add a product with no
   * active list
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddSimilarityNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.addProductSimilarity("testProduct", "testProduct2", 0);
  }

  /**
   * Ensure that an exception is thrown when trying to add a similarity if either
   * product does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddSimilarityProductDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(null);
    domainController.addProductSimilarity("testProduct", "testProduct2", 0);
  }

  /**
   * Ensure that a similarity is removed correctly
   */
  @Test
  public void testRemoveSimilaritySuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    Product mockProduct2 = new Product("testProduct2", "testList", "testUser");
    mockProduct.addSimilarity("testProduct2", 0);
    mockProduct2.addSimilarity("testProduct", 0);
    mockProduct.addSimilarity("testProduct2", 0);
    mockProduct2.addSimilarity("testProduct", 0);
    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(mockProduct);
    when(dataController.getProduct("testProduct2", "testUser", "testList")).thenReturn(mockProduct2);

    domainController.removeProductSimilarity("testProduct", "testProduct2");

    verify(productController).removeSimilarity("testProduct2");
    verify(productController).removeSimilarity("testProduct");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a similarity while
   * not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveSimilarityNotAuthenticated() throws IOException {
    domainController.removeProductSimilarity("testProduct", "testProduct2");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a product with no
   * active list
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveSimilarityNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.removeProductSimilarity("testProduct", "testProduct2");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a similarity if
   * either product does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveSimilarityProductDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(null);
    domainController.removeProductSimilarity("testProduct", "testProduct2");
  }

  // BLOQUE DE PRUEBAS DE LA CLASE DomainController (Parte Restricciones)

  /**
   * Ensure that a restriction is added correctly
   */
  @Test
  public void testAddRestrictionSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    Product mockProduct2 = new Product("testProduct2", "testList", "testUser");
    mockProduct.addRestriction("testProduct2");
    mockProduct2.addRestriction("testProduct");
    when(dataController.getProduct("testProduct", "testUser", "testList"))
        .thenReturn(new Product("testProduct", "testList", "testUser"));
    when(dataController.getProduct("testProduct2", "testUser", "testList"))
        .thenReturn(new Product("testProduct2", "testList", "testUser"));

    domainController.addProductRestriction("testProduct", "testProduct2");

    verify(productController).addRestriction("testProduct2");
    verify(productController).addRestriction("testProduct");
  }

  /**
   * Ensure that an exception is thrown when trying to add a restriction while not
   * authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddRestrictionNotAuthenticated() throws IOException {
    domainController.addProductRestriction("testProduct", "testProduct2");
  }

  /**
   * Ensure that an exception is thrown when trying to add a product with no
   * active list
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddRestrictionNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.addProductRestriction("testProduct", "testProduct2");
  }

  /**
   * Ensure that an exception is thrown when trying to add a restriction if either
   * product does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddRestrictionProductDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(null);
    domainController.addProductRestriction("testProduct", "testProduct2");
  }

  /**
   * Ensure that a restriction is removed correctly
   */
  @Test
  public void testRemoveRestrictionSuccess() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    Product mockProduct = new Product("testProduct", "testList", "testUser");
    Product mockProduct2 = new Product("testProduct2", "testList", "testUser");
    mockProduct.addRestriction("testProduct2");
    mockProduct2.addRestriction("testProduct");
    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(mockProduct);
    when(dataController.getProduct("testProduct2", "testUser", "testList")).thenReturn(mockProduct2);

    domainController.removeProductRestriction("testProduct", "testProduct2");

    verify(productController).removeRestriction("testProduct2");
    verify(productController).removeRestriction("testProduct");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a restriction while
   * not authenticated
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveRestrictionNotAuthenticated() throws IOException {
    domainController.removeProductRestriction("testProduct", "testProduct2");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a product with no
   * active list
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveRestrictionNoList() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    domainController.removeProductRestriction("testProduct", "testProduct2");
  }

  /**
   * Ensure that an exception is thrown when trying to remove a restriction if
   * either product does not exist
   */
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveRestrictionProductDoesNotExist() throws IOException {
    User mockUser = new User("testUser", "password");
    when(dataController.getUser("testUser")).thenReturn(mockUser);
    when(dataController.checkUserByUsername("testUser")).thenReturn(true);
    when(userController.verifyPassword("password")).thenReturn(true);
    domainController.loginUser("testUser", "password");

    when(dataController.checkListByName("testUser", "testList")).thenReturn(true);
    domainController.setActiveList("testList");

    when(dataController.getProduct("testProduct", "testUser", "testList")).thenReturn(null);
    domainController.removeProductRestriction("testProduct", "testProduct2");
  }

}
