package domain.Controllers;

import domain.Product.Product;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProductControllerTest {
    private ProductController controller;

    @Before
    public void setUp() {
        controller = new ProductController();
    }

    @Test
    public void testCreateProductSuccess() {
        Product product = controller.createProduct("TestProduct", "TestList", "TestUser");
        assertNotNull(product);
        assertEquals("TestProduct", product.getName());
        assertEquals("TestList", product.getListName());
        assertEquals("TestUser", product.getUser());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductNullName() {
        controller.createProduct(null, "TestList", "TestUser");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductNullListName() {
        controller.createProduct("TestProduct", null, "TestUser");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductNullUsername() {
        controller.createProduct("TestProduct", "TestList", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductEmptyName() {
        controller.createProduct("", "TestList", "TestUser");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductEmptyListName() {
        controller.createProduct("TestProduct", "", "TestUser");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateProductEmptyUsername() {
        controller.createProduct("TestProduct", "TestList", "");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddSimilarityProductNotSet() {
        controller.addSimilarity("ProductA", 50);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddSimilarityInvalidValue() {
        controller.setProduct(new Product("TestProduct", "TestList", "TestUser"));
        controller.addSimilarity("ProductA", -1);
    }

    @Test
    public void testAddSimilaritySuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.addSimilarity("ProductA", 50);
        assertEquals(50, product.getSimilarity("ProductA"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveSimilarityProductNotSet() {
        controller.removeSimilarity("ProductA");
    }

    @Test
    public void testRemoveSimilaritySuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.addSimilarity("ProductA", 50);
        controller.removeSimilarity("ProductA");
        assertEquals(1, product.getSimilarity("ProductA"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEditSimilarityProductNotSet() {
        controller.editSimilarity("ProductA", 50);
    }

    @Test
    public void testEditSimilaritySuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.addSimilarity("ProductA", 50);
        controller.editSimilarity("ProductA", 75);
        assertEquals(75, product.getSimilarity("ProductA"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddRestrictionProductNotSet() {
        controller.addRestriction("ProductA");
    }

    @Test
    public void testAddRestrictionSuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.addRestriction("ProductA");
        assertTrue(product.hasRestriction("ProductA"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveRestrictionProductNotSet() {
        controller.removeRestriction("ProductA");
    }

    @Test
    public void testRemoveRestrictionSuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.addRestriction("ProductA");
        controller.removeRestriction("ProductA");
        assertFalse(product.hasRestriction("ProductA"));
    }

    @Test (expected = IllegalArgumentException.class)
    public void testchangeListNameProductNotSet() {
        controller.changeListName("TestList");
    }

    @Test (expected = IllegalArgumentException.class)
    public void testchangeListNameEmptyListName() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.changeListName("");
    }

    @Test (expected = IllegalArgumentException.class)
    public void testchangeListNameNullListName() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.changeListName(null);
    }

    @Test
    public void testchangeListNameSuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        controller.changeListName("NewList");
        assertEquals("NewList", product.getListName());
    }


    @Test(expected = IllegalArgumentException.class)
    public void testGetProductNotSet() {
        controller.getProduct();
    }

    @Test
    public void testGetProductSuccess() {
        Product product = new Product("TestProduct", "TestList", "TestUser");
        controller.setProduct(product);
        assertEquals(product, controller.getProduct());
    }
}