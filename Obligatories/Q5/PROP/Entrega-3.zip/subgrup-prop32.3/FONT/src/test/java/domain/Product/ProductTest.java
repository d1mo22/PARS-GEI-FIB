package domain.Product;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ProductTest {
    private Product product;

    @Before
    public void setUp() {
        product = new Product("TestProduct", "TestList", "TestUser");
    }

    @Test
    public void testProductCreation() {
        assertEquals("TestProduct", product.getName());
        assertEquals("TestList", product.getListName());
        assertEquals("TestUser", product.getUser());
        assertTrue(product.getSimilarities().isEmpty());
    }

    @Test
    public void testSetName() {
        product.setName("NewName");
        assertEquals("NewName", product.getName());
    }

    @Test
    public void testSetListName() {
        product.setListName("NewListName");
        assertEquals("NewListName", product.getListName());
    }

    @Test
    public void testAddSimilarity() {
        product.addSimilarity("ProductA", 50);
        assertEquals(50, product.getSimilarity("ProductA"));
    }

    @Test
    public void testRemoveSimilarity() {
        product.addSimilarity("ProductA", 50);
        product.removeSimilarity("ProductA");
        assertEquals(1, product.getSimilarity("ProductA"));
    }

    @Test
    public void testAddRestriction() {
        product.addRestriction("ProductB");
        assertTrue(product.hasRestriction("ProductB"));
    }

    @Test
    public void testRemoveRestriction() {
        product.addRestriction("ProductB");
        product.removeRestriction("ProductB");
        assertFalse(product.hasRestriction("ProductB"));
    }

    @Test
    public void testGetSimilarity() {
        product.addSimilarity("ProductA", 50);
        assertEquals(50, product.getSimilarity("ProductA"));
        assertEquals(1, product.getSimilarity("NonExistentProduct"));
    }

    @Test
    public void testHasRestriction() {
        product.addRestriction("ProductB");
        assertTrue(product.hasRestriction("ProductB"));
        assertFalse(product.hasRestriction("ProductC"));
    }
}