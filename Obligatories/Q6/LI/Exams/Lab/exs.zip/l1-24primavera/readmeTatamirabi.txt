    puzzle         time      SATvars      clauses    infile.cnf
=============== ========== ============ =========== ============
puzzle4x5         < 1s          150        ~15K       < 200KB
puzzle7x7         < 3s          784       ~600K       < 8MB

puzzle3x4_UNSAT   < 1s           60         ~2K       < 20KB
puzzle7x9_UNSAT   < 10s        1260         ~2M       < 25MB
